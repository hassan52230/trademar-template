<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package tecz
 */

function get_header_style($style){
    if ( $style == 'header_2'  ) {
        get_template_part( 'template-parts/header/header-2' );
    }elseif ( $style == 'header_3'  ) {
        get_template_part( 'template-parts/header/header-3' );
    }elseif ( $style == 'header_4' ) {
        get_template_part( 'template-parts/header/header-4' );
    }elseif ( $style == 'header_5' ) {
        get_template_part( 'template-parts/header/header-5' );
    }else{
        get_template_part( 'template-parts/header/header-1');
    }
}

function tecz_check_header() {
    $tp_header_tabs = function_exists('tpmeta_field')? tpmeta_field('tecz_header_tabs') : false;
    $tp_header_style_meta = function_exists('tpmeta_field')? tpmeta_field('tecz_header_style') : '';
    $elementor_header_template_meta = function_exists('tpmeta_field')? tpmeta_field('tecz_header_templates') : false;

    $tecz_header_option_switch = get_theme_mod('tecz_header_elementor_switch', false);
    $header_default_style_kirki = get_theme_mod( 'header_layout_custom', 'header_1' );
    $elementor_header_templates_kirki = get_theme_mod( 'tecz_header_templates' );
    
    if($tp_header_tabs == 'default'){
        if($tecz_header_option_switch){
            if($elementor_header_templates_kirki){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_templates_kirki);
            }
        }else{ 
            if($header_default_style_kirki){
                get_header_style($header_default_style_kirki);
            }else{
                get_template_part( 'template-parts/header/header-1' );
            }
        }
    }elseif($tp_header_tabs == 'custom'){
        if ($tp_header_style_meta) {
            get_header_style($tp_header_style_meta);
        }else{
            get_header_style($header_default_style_kirki);
        }  
    }elseif($tp_header_tabs == 'elementor'){
        if($elementor_header_template_meta){
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_template_meta);
        }else{
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_templates_kirki);
        }
    }else{
        if($tecz_header_option_switch){

            if($elementor_header_templates_kirki){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_templates_kirki);
            }else{
                get_template_part( 'template-parts/header/header-1' );
            }
        }else{
            get_header_style($header_default_style_kirki);

        }
        
    }

}
add_action( 'tecz_header_style', 'tecz_check_header', 10 );



/**
 * [tecz_header_lang description]
 * @return [type] [description]
 */

function tecz_header_lang_defualt() {
    $tecz_header_lang = get_theme_mod( 'tecz_header_lang', false );
    if ( $tecz_header_lang ): ?>

    <ul>
        <li><a href="javascript:void(0)"><?php print esc_html__( 'English', 'tecz' );?> <i class="fal fa-angle-down"></i></a>
        <?php do_action( 'tecz_language' );?>
        </li>
    </ul>

    <?php endif;?>
<?php
}

/**
 * [tecz_language_list description]
 * @return [type] [description]
 */
function _tecz_language( $mar ) {
    return $mar;
}
function tecz_language_list() {

    $mar = '';
    $languages = apply_filters( 'wpml_active_languages', NULL, 'orderby=id&order=desc' );
    if ( !empty( $languages ) ) {
        $mar = '<ul>';
        foreach ( $languages as $lan ) {
            $active = $lan['active'] == 1 ? 'active' : '';
            $mar .= '<li class="' . $active . '"><a href="' . $lan['url'] . '">' . $lan['translated_name'] . '</a></li>';
        }
        $mar .= '</ul>';
    } else {
        //remove this code when send themeforest reviewer team
        $mar .= '<ul>';
        $mar .= '<li><a href="#">' . esc_html__( 'English', 'tecz' ) . '</a></li>';
        $mar .= '<li><a href="#">' . esc_html__( 'Bangla', 'tecz' ) . '</a></li>';
        $mar .= '<li><a href="#">' . esc_html__( 'French', 'tecz' ) . '</a></li>';
        $mar .= '<li><a href="#">' . esc_html__( 'Hindi', 'tecz' ) . '</a></li>';
        $mar .= ' </ul>';
    }
    print _tecz_language( $mar );
}
add_action( 'tecz_language', 'tecz_language_list' );


// header logo 
function tecz_header_logo() { ?>
      <?php
        $tecz_logo_on = function_exists( 'tpmeta_field' ) ? tpmeta_field( 'tecz_en_secondary_logo' ) : null;
        $tecz_black_logo = get_template_directory_uri() . '/assets/img/logo/logo-5.svg';
        $tecz_white_logo = get_template_directory_uri() . '/assets/img/logo/logo.png';

        $tecz_site_logo = get_theme_mod( 'header_logo', $tecz_black_logo );
        $tecz_secondary_logo = get_theme_mod( 'header_secondary_logo', $tecz_white_logo ); 
      ?>

      <?php if ( $tecz_logo_on == 'on' ) : ?>
         <a class="secondary-logo" href="<?php print esc_url( home_url( '/' ) );?>">
             <img src="<?php print esc_url( $tecz_secondary_logo );?>" alt="<?php print esc_attr__( 'logo', 'tecz' );?>" />
         </a>
      <?php else : ?>
         <a class="standard-logo" href="<?php print esc_url( home_url( '/' ) );?>">
             <img src="<?php print esc_url( $tecz_site_logo );?>" alt="<?php print esc_attr__( 'logo', 'tecz' );?>" />
         </a>
      <?php endif; ?>
   <?php
}
// header logo
function tecz_header_black_logo() { ?>
    <?php 
        $tecz_logo = get_template_directory_uri() . '/assets/img/logo/logo-black.png';

        $tecz_black_logo = get_theme_mod( 'header_logo', $tecz_logo );
    ?>

    <a href="<?php print esc_url( home_url( '/' ) );?>">
        <img src="<?php print esc_url( $tecz_black_logo );?>" alt="<?php print esc_attr__( 'logo', 'tecz' );?>" />
    </a>
<?php
}
/**
 * [tecz_header_social_profiles description]
 * @return [type] [description]
 */
function tecz_header_social_profiles() {
    $tecz_topbar_fb_url = get_theme_mod( 'tecz_topbar_fb_url', __( '#', 'tecz' ) );
    $tecz_topbar_twitter_url = get_theme_mod( 'tecz_topbar_twitter_url', __( '#', 'tecz' ) );
    $tecz_topbar_instagram_url = get_theme_mod( 'tecz_topbar_instagram_url', __( '#', 'tecz' ) );
    $tecz_topbar_linkedin_url = get_theme_mod( 'tecz_topbar_linkedin_url', __( '#', 'tecz' ) );
    $tecz_topbar_youtube_url = get_theme_mod( 'tecz_topbar_youtube_url', __( '#', 'tecz' ) );
    ?>
        
        <?php if ( !empty( $tecz_topbar_fb_url ) ): ?>
        <a href="<?php print esc_url( $tecz_topbar_fb_url );?>"><i class="fab fa-facebook-f"></i></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_twitter_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_twitter_url );?>"><i class="fab fa-twitter"></i></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_instagram_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_instagram_url );?>"><i class="fab fa-instagram"></i></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_linkedin_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_linkedin_url );?>"><i class="fab fa-linkedin"></i></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_youtube_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_youtube_url );?>"><i class="fab fa-youtube"></i></a>
        <?php endif;?>
        

<?php
}
// blog single social share
function tecz_blog_social_share(){

    $tecz_singleblog_social = get_theme_mod( 'tecz_singleblog_social', false );
    $post_url = get_the_permalink();
    $end_class = has_tag() ? 'text-lg-end' : 'text-lg-start';

    if(!empty($tecz_singleblog_social)) : ?>
    <div class="col-xl-6 col-lg-6">
        <div class="postbox-social text-lg-end mb-20 <?php echo esc_attr($end_class); ?>">
                <span>Share:</span>
                <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url($post_url);?>"
                    target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
                <a class="social-fb"  href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
                <a class="social-pin" href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-pinterest-p"></i></a>
                <a class="social-link" href="https://twitter.com/share?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-twitter"></i></a>
        
        </div>
    </div>
<?php endif ; 

}

// tecz_header_social_profiles_side
function tecz_header_social_profiles_side() {
    $tecz_topbar_fb_url = get_theme_mod( 'tecz_topbar_fb_url', __( '#', 'tecz' ) );
    $tecz_topbar_twitter_url = get_theme_mod( 'tecz_topbar_twitter_url', __( '#', 'tecz' ) );
    $tecz_topbar_instagram_url = get_theme_mod( 'tecz_topbar_instagram_url', __( '#', 'tecz' ) );
    $tecz_topbar_linkedin_url = get_theme_mod( 'tecz_topbar_linkedin_url', __( '#', 'tecz' ) );
    $tecz_topbar_youtube_url = get_theme_mod( 'tecz_topbar_youtube_url', __( '#', 'tecz' ) );
    ?>
        
        <?php if ( !empty( $tecz_topbar_fb_url ) ): ?>
          <a href="<?php print esc_url( $tecz_topbar_fb_url );?>"><span><i class="fab fa-facebook-f"></i></span></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_twitter_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_twitter_url );?>"><span><i class="fab fa-twitter"></i></span></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_instagram_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_instagram_url );?>"><span><i class="fab fa-instagram"></i></span></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_linkedin_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_linkedin_url );?>"><span><i class="fab fa-linkedin"></i></span></a>
        <?php endif;?>

        <?php if ( !empty( $tecz_topbar_youtube_url ) ): ?>
            <a href="<?php print esc_url( $tecz_topbar_youtube_url );?>"><span><i class="fab fa-youtube"></i></span></a>
        <?php endif;?>
 

<?php
}

// tecz_footer_social_profiles 
function tecz_footer_social_profiles() {
    $tecz_footer_fb_url = get_theme_mod( 'tecz_footer_fb_url', __( '#', 'tecz' ) );
    $tecz_footer_twitter_url = get_theme_mod( 'tecz_footer_twitter_url', __( '#', 'tecz' ) );
    $tecz_footer_instagram_url = get_theme_mod( 'tecz_footer_instagram_url', __( '#', 'tecz' ) );
    $tecz_footer_linkedin_url = get_theme_mod( 'tecz_footer_linkedin_url', __( '#', 'tecz' ) );
    $tecz_footer_youtube_url = get_theme_mod( 'tecz_footer_youtube_url', __( '#', 'tecz' ) );
    ?>


    <?php if ( !empty( $tecz_footer_fb_url ) ): ?>
    <a href="<?php print esc_url( $tecz_footer_fb_url );?>">
        <?php echo esc_html__('Fb.','tecz'); ?>
    </a>
    <?php endif;?>

    <?php if ( !empty( $tecz_footer_twitter_url ) ): ?>
    <a href="<?php print esc_url( $tecz_footer_twitter_url );?>">
        <?php echo esc_html__('Tw.','tecz'); ?>
    </a>
    <?php endif;?>

    <?php if ( !empty( $tecz_footer_instagram_url ) ): ?>
    <a href="<?php print esc_url( $tecz_footer_instagram_url );?>">
        <?php echo esc_html__('In.','tecz'); ?>
    </a>
    <?php endif;?>

    <?php if ( !empty( $tecz_footer_linkedin_url ) ): ?>
    <a href="<?php print esc_url( $tecz_footer_linkedin_url );?>">
        <?php echo esc_html__('Ln.','tecz'); ?>
    </a>
    <?php endif;?>

    <?php if ( !empty( $tecz_footer_youtube_url ) ): ?>
    <a href="<?php print esc_url( $tecz_footer_youtube_url );?>">
        <?php echo esc_html__('Yt.','tecz'); ?>
    </a>
    <?php endif;?>

<?php
}

/**
 * [tecz_header_menu description]
 * @return [type] [description]
 */
function tecz_header_menu() {
    ?>
    <?php
        wp_nav_menu( [
            'theme_location' => 'main-menu',
            'menu_class'     => '',
            'container'      => '',
            'fallback_cb'    => 'tecz_Navwalker_Class::fallback',
            'walker'         => new \TPCore\Widgets\tecz_Navwalker_Class,
        ] );
    ?>
    <?php
}


/**
 * [tecz_footer_menu description]
 * @return [type] [description]
 */
function tecz_footer_menu() {
    wp_nav_menu( [
        'theme_location' => 'footer-menu',
        'menu_class'     => 'm-0',
        'container'      => '',
        'fallback_cb'    => 'tecz_Navwalker_Class::fallback',
        'walker'         => new tecz_Navwalker_Class,
    ] );
}


 /*
 * tecz footer
 */
add_action( 'tecz_footer_style', 'tecz_check_footer', 10 );


function get_footer_style($style){
    if ( $style == 'footer_2'  ) {
        get_template_part( 'template-parts/footer/footer-2' );
    }elseif ( $style == 'footer_3'  ) {
        get_template_part( 'template-parts/footer/footer-3' );
    }elseif ( $style == 'footer_4' ) {
        get_template_part( 'template-parts/footer/footer-4' );
    }else{
        get_template_part( 'template-parts/footer/footer-1');
    }
}

function tecz_check_footer() {
    $tp_footer_tabs = function_exists('tpmeta_field')? tpmeta_field('tecz_footer_tabs') : '';
    $tecz_footer_style = function_exists( 'tpmeta_field' ) ? tpmeta_field( 'tecz_footer_style' ) : NULL;
    $footer_template = function_exists('tpmeta_field')? tpmeta_field('tecz_footer_template') : false;

    $tecz_footer_option_switch = get_theme_mod( 'tecz_footer_elementor_switch', false );
    $elementor_footer_template = get_theme_mod( 'tecz_footer_templates');
    $tecz_default_footer_style = get_theme_mod( 'footer_layout', 'footer_1' );

    if($tp_footer_tabs == 'default'){
        if($tecz_footer_option_switch){
            if($elementor_footer_template){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_footer_template);
            }
        }else{ 
            if($tecz_default_footer_style){
                get_footer_style($tecz_default_footer_style);
            }else{
                get_template_part( 'template-parts/footer/footer-1' );
            }
        }
    }elseif($tp_footer_tabs == 'custom'){
        if ($tecz_footer_style) {
            get_footer_style($tecz_footer_style);
        }else{
            get_footer_style($tecz_default_footer_style);
        }  
    }elseif($tp_footer_tabs == 'elementor'){
        if($footer_template){
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($footer_template);
        }else{
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_footer_template);
        }

    }else{
        if($tecz_footer_option_switch){

            if($elementor_footer_template){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_footer_template);
            }else{
                get_template_part( 'template-parts/footer/footer-1' );
            }
        }else{
            get_footer_style($tecz_default_footer_style);

        }
    }
}

// tecz_copyright_text
function tecz_copyright_text() {
   print get_theme_mod( 'footer_copyright', esc_html__( 'Copyright © 2024 Lawlify All Rights Reserved', 'tecz' ) );
}
/**
 *
 * pagination
 */
if ( !function_exists( 'tecz_pagination' ) ) {

    function _tecz_pagi_callback( $pagination ) {
        return $pagination;
    }

    //page navegation
    function tecz_pagination( $prev, $next, $pages, $args ) {
        global $wp_query, $wp_rewrite;
        $menu = '';
        $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

        if ( $pages == '' ) {
            global $wp_query;
            $pages = $wp_query->max_num_pages;

            if ( !$pages ) {
                $pages = 1;
            }

        }

        $pagination = [
            'base'      => add_query_arg( 'paged', '%#%' ),
            'format'    => '',
            'total'     => $pages,
            'current'   => $current,
            'prev_text' => $prev,
            'next_text' => $next,
            'type'      => 'array',
        ];

        //rewrite permalinks
        if ( $wp_rewrite->using_permalinks() ) {
            $pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ) . 'page/%#%/', 'paged' );
        }

        if ( !empty( $wp_query->query_vars['s'] ) ) {
            $pagination['add_args'] = ['s' => get_query_var( 's' )];
        }

        $pagi = '';
        if ( paginate_links( $pagination ) != '' ) {
            $paginations = paginate_links( $pagination );
            $pagi .= '<ul>';
            foreach ( $paginations as $key => $pg ) {
                $pagi .= '<li>' . $pg . '</li>';
            }
            $pagi .= '</ul>';
        }

        print _tecz_pagi_callback( $pagi );
    }
}

// theme color control
function tecz_custom_color() {
    // color primary
    $theme_color_code = get_theme_mod( 'tecz_color_option', '#DE2021' );
    wp_enqueue_style( 'tecz-custom', TECZ_THEME_CSS_DIR . 'tecz-custom.css', [] );
    if ( !empty($theme_color_code) ) {
        $custom_css = '';
        $custom_css .= ".dox { background-color: " . $theme_color_code . "}";

        $custom_css .= ".dox  { color: " . $theme_color_code . "}";
        $custom_css .= "html:roots{
            --tp-theme-1: " . $theme_color_code . ";
        }";

        $custom_css .= ".dox{ border-color: " . $theme_color_code . "}";

        wp_add_inline_style( 'tecz-custom', $custom_css );

    }    

    // Color Secondary
    $tecz_color_secondary = get_theme_mod( 'tecz_color_secondary', '#2FC0AF' );
    if ( !empty($tecz_color_secondary) ) {
        $custom_css = '';
        $custom_css .= ".dox{ background-color: " . $tecz_color_secondary . "}";

        wp_add_inline_style( 'tecz-custom', $custom_css );
    }    

    // breadcrumb_bg_color
    $color_code = get_theme_mod( 'breadcrumb_bg_color', '#000' );
    if ( !empty($color_code) ) {
        $custom_css = '';
        $custom_css .= "body .tpbreadcrumb-overlay::before { background: " . $color_code . "}";

        wp_add_inline_style( 'tecz-custom', $custom_css );
    }
}
add_action( 'wp_enqueue_scripts', 'tecz_custom_color' );



// tecz_kses_intermediate
function tecz_kses_intermediate( $string = '' ) {
    return wp_kses( $string, tecz_get_allowed_html_tags( 'intermediate' ) );
}

function tecz_get_allowed_html_tags( $level = 'basic' ) {
    $allowed_html = [
        'b'      => [],
        'i'      => [],
        'u'      => [],
        'em'     => [],
        'br'     => [],
        'abbr'   => [
            'title' => [],
        ],
        'span'   => [
            'class' => [],
        ],
        'strong' => [],
        'a'      => [
            'href'  => [],
            'title' => [],
            'class' => [],
            'id'    => [],
        ],
    ];

    if ($level === 'intermediate') {
        $allowed_html['a'] = [
            'href' => [],
            'title' => [],
            'class' => [],
            'id' => [],
        ];
        $allowed_html['div'] = [
            'class' => [],
            'id' => [],
        ];
        $allowed_html['img'] = [
            'src' => [],
            'class' => [],
            'alt' => [],
        ];
        $allowed_html['del'] = [
            'class' => [],
        ];
        $allowed_html['ins'] = [
            'class' => [],
        ];
        $allowed_html['bdi'] = [
            'class' => [],
        ];
        $allowed_html['i'] = [
            'class' => [],
            'data-rating-value' => [],
        ];
    }

    return $allowed_html;
}



// WP kses allowed tags
// ----------------------------------------------------------------------------------------
function tecz_kses($raw){

   $allowed_tags = array(
      'a'                         => array(
         'class'   => array(),
         'href'    => array(),
         'rel'  => array(),
         'title'   => array(),
         'target' => array(),
      ),
      'abbr'                      => array(
         'title' => array(),
      ),
      'b'                         => array(),
      'blockquote'                => array(
         'cite' => array(),
      ),
      'cite'                      => array(
         'title' => array(),
      ),
      'code'                      => array(),
      'del'                    => array(
         'datetime'   => array(),
         'title'      => array(),
      ),
      'dd'                     => array(),
      'div'                    => array(
         'class'   => array(),
         'title'   => array(),
         'style'   => array(),
      ),
      'dl'                     => array(),
      'dt'                     => array(),
      'em'                     => array(),
      'h1'                     => array(),
      'h2'                     => array(),
      'h3'                     => array(),
      'h4'                     => array(),
      'h5'                     => array(),
      'h6'                     => array(),
      'i'                         => array(
         'class' => array(),
      ),
      'img'                    => array(
         'alt'  => array(),
         'class'   => array(),
         'height' => array(),
         'src'  => array(),
         'width'   => array(),
      ),
      'li'                     => array(
         'class' => array(),
      ),
      'ol'                     => array(
         'class' => array(),
      ),
      'p'                         => array(
         'class' => array(),
      ),
      'q'                         => array(
         'cite'    => array(),
         'title'   => array(),
      ),
      'span'                      => array(
         'class'   => array(),
         'title'   => array(),
         'style'   => array(),
      ),
      'iframe'                 => array(
         'width'         => array(),
         'height'     => array(),
         'scrolling'     => array(),
         'frameborder'   => array(),
         'allow'         => array(),
         'src'        => array(),
      ),
      'strike'                 => array(),
      'br'                     => array(),
      'strong'                 => array(),
      'data-wow-duration'            => array(),
      'data-wow-delay'            => array(),
      'data-wallpaper-options'       => array(),
      'data-stellar-background-ratio'   => array(),
      'ul'                     => array(
         'class' => array(),
      ),
      'svg' => array(
           'class' => true,
           'aria-hidden' => true,
           'aria-labelledby' => true,
           'role' => true,
           'xmlns' => true,
           'width' => true,
           'height' => true,
           'viewbox' => true, // <= Must be lower case!
       ),
       'g'     => array( 'fill' => true ),
       'title' => array( 'title' => true ),
       'path'  => array( 'd' => true, 'fill' => true,  ),
      );

   if (function_exists('wp_kses')) { // WP is here
      $allowed = wp_kses($raw, $allowed_tags);
   } else {
      $allowed = $raw;
   }

   return $allowed;
}

// / This code filters the Archive widget to include the post count inside the link /
add_filter( 'get_archives_link', 'tecz_archive_count_span' );
function tecz_archive_count_span( $links ) {
    $links = str_replace('</a>&nbsp;(', '<span > (', $links);
    $links = str_replace(')', ')</span></a> ', $links);
    return $links;
}


// / This code filters the Category widget to include the post count inside the link /
add_filter('wp_list_categories', 'tecz_cat_count_span');
function tecz_cat_count_span($links) {
  $links = str_replace('</a> (', '<span> (', $links);
  $links = str_replace(')', ')</span></a>', $links);
  return $links;
}