<?php


new \Kirki\Panel(
    'panel_id',
    [
        'priority'    => 10,
        'title'       => esc_html__( 'Tecz Panel', 'tecz' ),
        'description' => esc_html__( 'Tecz Panel Description.', 'tecz' ),
    ]
);

// header_top_section
function header_top_section(){
    // header_top_bar section 
    new \Kirki\Section(
        'header_top_section',
        [
            'title'       => esc_html__( 'Header Info', 'tecz' ),
            'description' => esc_html__( 'Header Section Information.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );
    // header_top_bar section 

    new \Kirki\Field\Radio_Image(
        [
            'settings'    => 'header_layout_custom',
            'label'       => esc_html__( 'Chose Header Style', 'tecz' ),
            'section'     => 'header_top_section',
            'priority'    => 10,
            'choices'     => [
                'header_1'   => get_template_directory_uri() . '/inc/img/header/header-1.png',
                'header_2'   => get_template_directory_uri() . '/inc/img/header/header-2.png',
                'header_3'   => get_template_directory_uri() . '/inc/img/header/header-3.png',
                'header_4'   => get_template_directory_uri() . '/inc/img/header/header-4.png',
                'header_5'   => get_template_directory_uri() . '/inc/img/header/header-5.png',
            ],
            'default'     => 'header_1',
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_topbar_switch',
            'label'       => esc_html__( 'Header Topbar Switch', 'tecz' ),
            'description' => esc_html__( 'Header Topbar switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );    

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_right_switch',
            'label'       => esc_html__( 'Header Right Switch', 'tecz' ),
            'description' => esc_html__( 'Header Right switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    ); 

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_preloader_switch',
            'label'       => esc_html__( 'Header Preloader Switch', 'tecz' ),
            'description' => esc_html__( 'Header Preloader switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_search_switch',
            'label'       => esc_html__( 'Header Search Switch', 'tecz' ),
            'description' => esc_html__( 'Header Search switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    ); 
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_shop_switch',
            'label'       => esc_html__( 'Header Shop Switch', 'tecz' ),
            'description' => esc_html__( 'Header Shop switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    ); 
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_header_cart',
            'label'       => esc_html__( 'Header Cart Switch', 'tecz' ),
            'description' => esc_html__( 'Header Cart switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    ); 

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_backtotop_switch',
            'label'       => esc_html__( 'Header Back to Top Switch', 'tecz' ),
            'description' => esc_html__( 'Header Back to Top switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_button_switch',
            'label'       => esc_html__( 'Header button Switch', 'tecz' ),
            'description' => esc_html__( 'Header button switch On/Off', 'tecz' ),
            'section'     => 'header_top_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_button_text',
            'label'    => esc_html__( 'Button Text', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => esc_html__( 'Contact Us', 'tecz' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\URL(
        [
            'settings' => 'header_button_link',
            'label'    => esc_html__( 'Button URL', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_phone',
            'label'    => esc_html__( 'Phone Number', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => esc_html__( '(088) 234 567 899', 'tecz' ),
            'priority' => 10,
        ]
    );    

    new \Kirki\Field\Text(
        [
            'settings' => 'header_email',
            'label'    => esc_html__( 'Email ID', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => esc_html__( 'info@example.com', 'tecz' ),
            'priority' => 10,
        ]
    );    

    new \Kirki\Field\Text(
        [
            'settings' => 'header_address',
            'label'    => esc_html__( 'Address Text', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => esc_html__( 'Moon ave, New York, 2020 NY US', 'tecz' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\URL(
        [
            'settings' => 'header_address_link',
            'label'    => esc_html__( 'Address URL', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_text',
            'label'    => esc_html__( 'Header Top Text', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => esc_html__( 'Free Delivery on orders over $200. Don’t miss discount.', 'tecz' ),
            'priority' => 10,
        ]
    );
      // Top Menu
      new \Kirki\Field\textarea(
        [
            'settings' => 'header_top_menu',
            'label'    => esc_html__( 'Top Menu', 'tecz' ),
            'section'  => 'header_top_section',
            'default'  => esc_html__( '#', 'tecz' ),
            'priority' => 10,
        ]
    );
}
header_top_section();

// header_social_section
function header_social_section(){
    // header_top_bar section 
    new \Kirki\Section(
        'header_social_section',
        [
            'title'       => esc_html__( 'Header Social', 'tecz' ),
            'description' => esc_html__( 'Header Social URL.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );
    // header_top_bar section 

    new \Kirki\Field\URL(
        [
            'settings' => 'header_facebook_link',
            'label'    => esc_html__( 'Facebook URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    ); 

    new \Kirki\Field\URL(
        [
            'settings' => 'header_twitter_link',
            'label'    => esc_html__( 'Twitter URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );  

    new \Kirki\Field\URL(
        [
            'settings' => 'header_linkedin_link',
            'label'    => esc_html__( 'Linkedin URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    ); 

    new \Kirki\Field\URL(
        [
            'settings' => 'header_instagram_link',
            'label'    => esc_html__( 'Instagram URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );  

    new \Kirki\Field\URL(
        [
            'settings' => 'header_youtube_link',
            'label'    => esc_html__( 'Youtube URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );  

    new \Kirki\Field\URL(
        [
            'settings' => 'header_fb_link',
            'label'    => esc_html__( 'Facebook URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );  

    new \Kirki\Field\URL(
        [
            'settings' => 'header_vimeo_link',
            'label'    => esc_html__( 'Vimeo URL', 'tecz' ),
            'section'  => 'header_social_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
        ]
    );

}
header_social_section();

// header_logo_section
function header_logo_section(){
    // header_logo_section section 
    new \Kirki\Section(
        'header_logo_section',
        [
            'title'       => esc_html__( 'Header Logo', 'tecz' ),
            'description' => esc_html__( 'Header Logo Settings.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );

    // header_logo_section section 
    new \Kirki\Field\Image(
        [
            'settings'    => 'header_logo',
            'label'       => esc_html__( 'Header Logo', 'tecz' ),
            'description' => esc_html__( 'Theme Default/Primary Logo Here', 'tecz' ),
            'section'     => 'header_logo_section',
            'default'     => get_template_directory_uri() . '/assets/img/logo/logo-4.png',
        ]
    );
    new \Kirki\Field\Image(
        [
            'settings'    => 'header_secondary_logo',
            'label'       => esc_html__( 'Header Secondary Logo', 'tecz' ),
            'description' => esc_html__( 'Theme Secondary Logo Here', 'tecz' ),
            'section'     => 'header_logo_section',
            'default'     => get_template_directory_uri() . '/assets/img/logo/logo.png',
        ]
    );

}
header_logo_section();

// header_sideinfo_section
function header_sideinfo_section(){
    // header_sideinfo_section section 
    new \Kirki\Section(
        'header_sideinfo_section',
        [
            'title'       => esc_html__( 'Header Side Info', 'tecz' ),
            'description' => esc_html__( 'Header sideinfo settings.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_sideinfo_switch',
            'label'       => esc_html__( 'Side Info Switch', 'tecz' ),
            'description' => esc_html__( 'Header Side Info switch On/Off', 'tecz' ),
            'section'     => 'header_sideinfo_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );

    // header_sideinfo_section section 
    new \Kirki\Field\Image(
        [
            'settings'    => 'header_side_logo',
            'label'       => esc_html__( 'Logo', 'tecz' ),
            'description' => esc_html__( 'Theme Side Info Logo Here', 'tecz' ),
            'section'     => 'header_sideinfo_section',
            'default'     => get_template_directory_uri() . '/assets/img/logo/logo.png',
            'active_callback' => [
                [
                    'setting'  => 'header_sideinfo_switch',
                    'operator' => '==',
                    'value'    => true,
                ]
            ],
        ]
    );

    new \Kirki\Field\TEXT(
        [
            'settings' => 'header_side_title',
            'label'    => esc_html__( 'Contact Info Title', 'tecz' ),
            'section'  => 'header_sideinfo_section',
            'default'  => __('Contact us', 'tecz'),
            'priority' => 10,
            'active_callback' => [
                [
                    'setting'  => 'header_sideinfo_switch',
                    'operator' => '==',
                    'value'    => true,
                ]
            ],
        ]
    );

    // address
    new \Kirki\Field\Text(
        [
            'settings' => 'header_side_address',
            'label'    => esc_html__( 'Address Text', 'tecz' ),
            'section'  => 'header_sideinfo_section',
            'default'  => esc_html__( 'Moon ave, New York', 'tecz' ),
            'priority' => 10,
            'active_callback' => [
                [
                    'setting'  => 'header_sideinfo_switch',
                    'operator' => '==',
                    'value'    => true,
                ]
            ],
        ]
    );

    // subscriber
    new \Kirki\Field\Text(
        [
            'settings' => 'header_side_button',
            'label'    => esc_html__( 'Button Text', 'tecz' ),
            'section'  => 'header_sideinfo_section',
            'default'  => esc_html__( 'Getting Started', 'tecz' ),
            'priority' => 10,
            'active_callback' => [
                [
                    'setting'  => 'header_sideinfo_switch',
                    'operator' => '==',
                    'value'    => true,
                ]
            ],
        ]
    ); 
    new \Kirki\Field\URL(
        [
            'settings' => 'header_side_button_link',
            'label'    => esc_html__( 'Button URL', 'tecz' ),
            'section'  => 'header_sideinfo_section',
            'default'  => 'https://yoururl.com/',
            'priority' => 10,
            'active_callback' => [
                [
                    'setting'  => 'header_sideinfo_switch',
                    'operator' => '==',
                    'value'    => true,
                ]
            ],
        ]
    ); 

}
header_sideinfo_section();


// header_logo_section
function header_breadcrumb_section(){
    // header_logo_section section 
    new \Kirki\Section(
        'header_breadcrumb_section',
        [
            'title'       => esc_html__( 'Breadcrumb', 'tecz' ),
            'description' => esc_html__( 'Breadcrumb Settings.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );

    // header_logo_section section 
    new \Kirki\Field\Image(
        [
            'settings'    => 'breadcrumb_image',
            'label'       => esc_html__( 'Breadcrumb Image', 'tecz' ),
            'description' => esc_html__( 'Breadcrumb Image add/remove', 'tecz' ),
            'section'     => 'header_breadcrumb_section',
        ]
    );
    new \Kirki\Field\Color(
        [
            'settings'    => 'breadcrumb_bg_color',
            'label'       => __( 'Breadcrumb BG Color', 'tecz' ),
            'description' => esc_html__( 'You can change breadcrumb bg color from here.', 'tecz' ),
            'section'     => 'header_breadcrumb_section',
            'default'     => '#000',
        ]
    );

    new \Kirki\Field\Dimensions(
        [
            'settings'    => 'breadcrumb_padding',
            'label'       => esc_html__( 'Dimensions Control', 'tecz' ),
            'description' => esc_html__( 'Description', 'tecz' ),
            'section'     => 'header_breadcrumb_section',
            'default'     => [
                'padding-top'  => '100px',
                'padding-bottom' => '100px',
            ],
        ]
    );

    new \Kirki\Field\Typography(
        [
            'settings'    => 'breadcrumb_typography',
            'label'       => esc_html__( 'Typography Control', 'tecz' ),
            'description' => esc_html__( 'The full set of options.', 'tecz' ),
            'section'     => 'header_breadcrumb_section',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => '',
                'variant'         => '',
                'color'           => '',
                'font-size'       => '',
                'line-height'     => '',
                'text-align'      => '',
            ],
            'output'      => [
                [
                    'element' => '.tpbreadcrumb-title',
                ],
            ],
        ]
    );
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_breadcrumb_shap_switch',
            'label'       => esc_html__( 'Breadcrumb_ Custom/Elementor Switch', 'tecz' ),
            'description' => esc_html__( 'Breadcrumb_ Custom/Elementor On/Off', 'tecz' ),
            'section'     => 'header_breadcrumb_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    ); 

}
header_breadcrumb_section();


// header_logo_section
function footer_layout_section(){
    // header_logo_section section 
    new \Kirki\Section(
        'footer_layout_section',
        [
            'title'       => esc_html__( 'Footer', 'tecz' ),
            'description' => esc_html__( 'Footer Settings.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );

    new \Kirki\Field\Radio_Image(
        [
            'settings'    => 'footer_layout',
            'label'       => esc_html__( 'Footer Layout Control', 'tecz' ),
            'section'     => 'footer_layout_section',
            'priority'    => 10,
            'choices'     => [
                'footer_1'   => get_template_directory_uri() . '/inc/img/footer/footer-1.png',
            ],
            'default'     => 'footer_1',
        ]
    );

    // header_logo_section section 
    new \Kirki\Field\Image(
        [
            'settings'    => 'footer_bg_image',
            'label'       => esc_html__( 'Footer BG Image', 'tecz' ),
            'description' => esc_html__( 'Footer Image add/remove', 'tecz' ),
            'section'     => 'footer_layout_section',
        ]
    );
    new \Kirki\Field\Color(
        [
            'settings'    => 'footer_bg_color',
            'label'       => __( 'Footer BG Color', 'tecz' ),
            'description' => esc_html__( 'You can change footer bg color from here.', 'tecz' ),
            'section'     => 'footer_layout_section',
            'default'     => '',
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'footer_copyright',
            'label'    => esc_html__( 'Footer Copyright', 'tecz' ),
            'section'  => 'footer_layout_section',
            'default'  => esc_html__( 'Copyright &copy; 2023 Theme_Pure. All Rights Reserved', 'tecz' ),
            'priority' => 10,
        ]
    );  

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_footer_bottom_menu_switch',
            'label'       => esc_html__( 'Footer Bottom Menu Switch', 'tecz' ),
            'section'     => 'footer_layout_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    ); 

    // Top Menu
    new \Kirki\Field\textarea(
        [
            'settings' => 'footer_bottom_menu',
            'label'    => esc_html__( 'Footer Bottom Menu', 'tecz' ),
            'section'  => 'footer_layout_section',
            'default'  => esc_html__( '#', 'tecz' ),
            'priority' => 10,
        ]
        );

}
footer_layout_section();

// blog post section
function blog_post_section(){
    new \Kirki\Section(
        'blog_post_section',
        [
            'title'       => esc_html__( 'Blog Post', 'tecz' ),
            'description' => esc_html__( 'Settings control for blog post.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );

    // category
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_blog_cat',
            'label'       => esc_html__( 'Cetagory Switch', 'tecz' ),
            'description' => esc_html__( 'Settings control for blog cetagory', 'tecz' ),
            'section'     => 'blog_post_section',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );

    // author
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_blog_author',
            'label'       => esc_html__( 'Author Switch', 'tecz' ),
            'description' => esc_html__( 'Settings control for blog author', 'tecz' ),
            'section'     => 'blog_post_section',
            'default'     => 'on',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );

    // date
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_blog_date',
            'label'       => esc_html__( 'Date Switch', 'tecz' ),
            'description' => esc_html__( 'Settings control for blog date', 'tecz' ),
            'section'     => 'blog_post_section',
            'default'     => 'on',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );

    // comments
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'tecz_blog_comments',
            'label'       => esc_html__( 'Comments Switch', 'tecz' ),
            'description' => esc_html__( 'Settings control for blog comment', 'tecz' ),
            'section'     => 'blog_post_section',
            'default'     => 'on',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'tecz' ),
                'off' => esc_html__( 'Disable', 'tecz' ),
            ],
        ]
    );
    
    // button
    new \Kirki\Field\Text(
        [
            'settings' => 'tecz_blog_btn',
            'label'    => esc_html__( 'Blog Button Title', 'tecz' ),
            'section'  => 'blog_post_section',
            'default'  => esc_html__( 'Read More', 'tecz' ),
            'priority' => 10,
        ]
    ); 
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings' => 'tecz_singleblog_social',
            'label'    => esc_html__( 'Single Blog Social Share', 'tecz' ),
            'section'  => 'blog_post_section',
            'default'  => false,
            'priority' => 10,
        ]
    );

}
blog_post_section();

// 404
function section_404(){
    new \Kirki\Section(
        'section_404',
        [
            'title'       => esc_html__( '404 Page', 'tecz' ),
            'description' => esc_html__( 'Settings control for blog post.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 160,
        ]
    );
    
    // error title
    new \Kirki\Field\Text(
        [
            'settings' => 'tecz_error_title',
            'label'    => esc_html__( 'Error Title', 'tecz' ),
            'section'  => 'section_404',
            'default'  => esc_html__( 'Page not found', 'tecz' ),
            'priority' => 10,
        ]
    ); 
        // error title
        new \Kirki\Field\Text(
            [
                'settings' => 'tecz_error_sub_title',
                'label'    => esc_html__( 'Error sub Title', 'tecz' ),
                'section'  => 'section_404',
                'default'  => esc_html__( 'Ooops....', 'tecz' ),
                'priority' => 10,
            ]
        ); 
        
    // error description
    new \Kirki\Field\Textarea(
        [
            'settings' => 'tecz_error_desc',
            'label'    => esc_html__( 'Error Description', 'tecz' ),
            'section'  => 'section_404',
            'default'  => esc_html__( 'Oops! The page you are looking for does not exist. It might have been moved or deleted.', 'tecz' ),
            'priority' => 10,
        ]
    ); 
    
    // error home button
    new \Kirki\Field\Text(
        [
            'settings' => 'tecz_error_link_text',
            'label'    => esc_html__( 'Home Button Title', 'tecz' ),
            'section'  => 'section_404',
            'default'  => esc_html__( 'Back To Home', 'tecz' ),
            'priority' => 10,
        ]
    ); 
        // error bg img
        new \Kirki\Field\Image(
            [
                'settings'    => 'tecz_error_bg_image',
                'label'       => esc_html__( 'Error BG Image', 'tecz' ),
                'description' => esc_html__( 'Error Image add/remove', 'tecz' ),
                'section'     => 'section_404',
            ]
        );

}
section_404();

// full_site_typography
function full_site_typography(){
    // header_logo_section section 
    new \Kirki\Section(
        'full_site_typography',
        [
            'title'       => esc_html__( 'Typography', 'tecz' ),
            'description' => esc_html__( 'Typography Settings.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 190,
        ]
    );

    new \Kirki\Field\Typography(
        [
            'settings'    => 'full_site_typography_settings',
            'label'       => esc_html__( 'Typography Control', 'tecz' ),
            'description' => esc_html__( 'The full set of options.', 'tecz' ),
            'section'     => 'full_site_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => '',
                'variant'         => '',
                'color'           => '',
                'font-size'       => '',
                'line-height'     => '',
                'text-align'      => '',
            ],
            'output'      => [
                [
                    'element' => 'body',
                ],
            ],
        ]
    );
}
full_site_typography();

// Slug Section
function theme_slug_settings(){
    // slug section 
    new \Kirki\Section(
        'slug_section',
        [
            'title'       => esc_html__( 'Slug', 'tecz' ),
            'description' => esc_html__( 'Manage slug of post types.', 'tecz' ),
            'panel'       => 'panel_id',
            'priority'    => 190,
        ]
    );

    // services
    new \Kirki\Field\Text(
        [
            'settings' => 'tecz_services_slug',
            'label'    => esc_html__( 'Service Post Type Slug', 'tecz' ),
            'section'  => 'slug_section',
            'default'  => esc_html__( 'tp-services', 'tecz' ),
            'priority' => 10,
        ]
    ); 

}
theme_slug_settings();
