<?php 

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function tecz_widgets_init() {

    $footer_style_2_switch = get_theme_mod( 'footer_layout_2_switch', false );
    $footer_style_3_switch = get_theme_mod( 'footer_layout_2_switch', false );
    $footer_style_4_switch = get_theme_mod( 'footer_layout_2_switch', false );

    /**
     * blog sidebar
     */
    // register_sidebar( [
    //     'name'          => esc_html__( 'Blog Sidebar', 'tecz' ),
    //     'id'            => 'blog-sidebar',
    //     'before_widget' => '<div id="%1$s" class="sidebar-widget sidebar-widget-2 mb-30 %2$s"> <div class="sidebar-widget search-box">',
    //     'after_widget'  => '</div></div>',
    //     'before_title'  => '<h3 class="sidebar-widget_title">',
    //     'after_title'   => '</h3>',
    // ] );    

    /**
     * Services Sidebar
     */
    if(class_exists('TP_Core')) :
    register_sidebar( [
        'name'          => esc_html__( 'Services Sidebar', 'tecz' ),
        'id'            => 'services-sidebar',
        'before_widget' => '<div id="%1$s" class="tp-services-details-wrap mb-40 %2$s"><div class="tp-services-details-services mb-50">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h4 class="tp-services-details-services-title">',
        'after_title'   => '</h4>',
    ] );
    endif;


    $footer_widgets = get_theme_mod( 'footer_widget_number', 4 );

    // footer default
    for ( $num = 1; $num <= $footer_widgets; $num++ ) {
        register_sidebar( [
            'name'          => sprintf( esc_html__( 'Footer %1$s', 'tecz' ), $num ),
            'id'            => 'footer-' . $num,
            'description'   => sprintf( esc_html__( 'Footer Column %1$s', 'tecz' ), $num ),
            'before_widget' => '<div id="%1$s" class="tp-footer-widget tp-footer-col-'.$num.' mb-40 %2$s"><div class="tp-footer-widget-link ">',
            'after_widget'  => '</div></div>',
            'before_title'  => '<h4 class="tp-footer-widget-title mb-30">',
            'after_title'   => '</h4>',
        ] );
    }

}
add_action( 'widgets_init', 'tecz_widgets_init' );