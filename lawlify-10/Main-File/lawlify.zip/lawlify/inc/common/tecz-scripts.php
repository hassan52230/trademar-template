<?php

/**
 * tecz_scripts description
 * @return [type] [description]
 */
function tecz_scripts() {

    /**
     * all css files
    */

    wp_enqueue_style( 'tecz-fonts', tecz_fonts_url(), array(), '1.0.0' );
    wp_enqueue_style( 'tecz-fonts-heading', 'https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap', array(), '1.0.0' );
  
    wp_enqueue_style( 'bootstrap', TECZ_THEME_CSS_DIR.'bootstrap.css', array() );
    wp_enqueue_style( 'tecz-core', TECZ_THEME_CSS_DIR . 'tecz-core.css', [] );
    wp_enqueue_style( 'tecz-unit', TECZ_THEME_CSS_DIR . 'tecz-unit.css', [] );
    wp_enqueue_style( 'woo', TECZ_THEME_CSS_DIR . 'woo.css', [] );
    wp_enqueue_style( 'tecz-style', TECZ_THEME_CSS_DIR . 'style.css', [] );
    wp_enqueue_style( 'meanmenu', TECZ_THEME_CSS_DIR . 'meanmenu.min.css', [] );
    wp_enqueue_style( 'responsive', TECZ_THEME_CSS_DIR . 'responsive.css', [] );
   
    
   

    // all js
    wp_enqueue_script( 'bootstrap', TECZ_THEME_JS_DIR . 'bootstrap.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'popper', TECZ_THEME_JS_DIR . 'popper.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'appear', TECZ_THEME_JS_DIR . 'appear.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'parallax', TECZ_THEME_JS_DIR . 'parallax.min.js', [ 'jquery' ], false, true );
    //wp_enqueue_script( 'tilt', TECZ_THEME_JS_DIR . 'tilt.jquery.min.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'paroller', TECZ_THEME_JS_DIR . 'jquery.paroller.min.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'wow', TECZ_THEME_JS_DIR . 'wow.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'swiper-bundle', TECZ_THEME_JS_DIR . 'swiper.min.js', [ 'jquery' ], false, true );
    //wp_enqueue_script( 'backtotop', TECZ_THEME_JS_DIR . 'backtotop.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'odometer', TECZ_THEME_JS_DIR . 'odometer.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'parallax-scroll', TECZ_THEME_JS_DIR . 'parallax-scroll.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'gsap', TECZ_THEME_JS_DIR . 'gsap.min.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'SplitText', TECZ_THEME_JS_DIR . 'SplitText.min.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'ScrollTrigger', TECZ_THEME_JS_DIR . 'ScrollTrigger.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'ScrollToPlugin', TECZ_THEME_JS_DIR . 'ScrollToPlugin.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'ScrollSmoother', TECZ_THEME_JS_DIR . 'ScrollSmoother.min.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'magnific-popup', TECZ_THEME_JS_DIR . 'magnific-popup.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'meanmenu', TECZ_THEME_JS_DIR . 'jquery.meanmenu.min.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'nav-tool', TECZ_THEME_JS_DIR . 'nav-tool.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'tecz-main', TECZ_THEME_JS_DIR . 'main.js', [ 'jquery' ], false, true );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'tecz_scripts' );

/*
Register Fonts
 */
function tecz_fonts_url() {
    $font_url = '';

    /*
    Translators: If there are characters in your language that are not supported
    by chosen font(s), translate this to 'off'. Do not translate into your own language.
     */
    if ( 'off' !== _x( 'on', 'Google font: on or off', 'tecz' ) ) {
        $font_url = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap';
    }
    return $font_url;
}