<?php
/**
 * Breadcrumbs for tecz theme.
 *
 * @package     tecz
 * @author      Theme_Pure
 * @copyright   Copyright (c) 2022, Theme_Pure
 * @link        https://www.weblearnbd.net
 * @since       tecz 1.0.0
 */


function tecz_breadcrumb_func() {
    global $post;  
    $breadcrumb_class = '';
    $breadcrumb_show = 1;

    if ( is_front_page() && is_home() ) {
        $title = get_theme_mod('breadcrumb_blog_title', __('Blog','tecz'));
        $breadcrumb_class = 'home_front_page';
    }
    elseif ( is_front_page() ) {
        $title = get_theme_mod('breadcrumb_blog_title', __('Blog','tecz'));
        $breadcrumb_show = 0;
    }
    elseif ( is_home() ) {
        if ( get_option( 'page_for_posts' ) ) {
            $title = get_the_title( get_option( 'page_for_posts') );
        }
    }
    elseif ( is_single() && 'post' == get_post_type() ) {
      $title = get_the_title();
    } 
    elseif ( is_single() && 'product' == get_post_type() ) {
        $title = get_theme_mod( 'breadcrumb_product_details', __( 'Shop', 'tecz' ) );
    } 
    elseif ( is_single() && 'courses' == get_post_type() ) {
      $title = esc_html__( 'Course Details', 'tecz' );
    } 
    elseif ( is_search() ) {
        $title = esc_html__( 'Search Results for : ', 'tecz' ) . get_search_query();
    } 
    elseif ( is_404() ) {
        $title = esc_html__( 'Page not Found', 'tecz' );
    } 
    elseif ( is_archive() ) {
        $title = get_the_archive_title();
    } 
    else {
        $title = get_the_title();
    }
 


    $_id = get_the_ID();

    if ( is_single() && 'product' == get_post_type() ) { 
        $_id = $post->ID;
    } 
    elseif ( function_exists("is_shop") AND is_shop()  ) { 
        $_id = wc_get_page_id('shop');
    } 
    elseif ( is_home() && get_option( 'page_for_posts' ) ) {
        $_id = get_option( 'page_for_posts' );
    }

    $is_breadcrumb = function_exists('tpmeta_field')? tpmeta_field('tecz_check_bredcrumb') : 'on';

      if ( !empty( $is_breadcrumb ) && ($is_breadcrumb== 'on') && $breadcrumb_show == 1 ) {
        $bg_img_from_page = function_exists('ççç')? tpmeta_image_field('tecz_breadcrumb_bg') : '';
        $hide_bg_img = function_exists('tpmeta_field')? tpmeta_field('tecz_check_bredcrumb_img') : 'on';

        // get_theme_mod
        $bg_img = get_theme_mod( 'breadcrumb_image' );
        $breadcrumb_padding = get_theme_mod( 'breadcrumb_padding' );

        if ( $breadcrumb_padding === false ) {
            $breadcrumb_padding['padding-top'] = 100;
            $breadcrumb_padding['padding-bottom'] = 100;
        }

        if ( $hide_bg_img == 'off' ) {
            $bg_main_img = '';
        }else{  
            $bg_main_img = !empty( $bg_img_from_page ) ? $bg_img_from_page['url'] : $bg_img;
        }
        $tecz_breadcrumb_shap_switch = get_theme_mod( 'tecz_breadcrumb_shap_switch', false );
        ?>
    <!-- breadcrumb-area-start -->
    <section class="breadcrumb-area breadcrumb-wrap  <?php print esc_attr( $breadcrumb_class );?>"  style="padding-top: <?php print esc_attr( $breadcrumb_padding['padding-top'] );?>;padding-bottom: <?php print esc_attr( $breadcrumb_padding['padding-bottom'] );?>">
            <div class="breadcrumb-bg" data-background="<?php print esc_attr($bg_main_img);?>"></div>
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-12">
                     <div class="tpbreadcrumb">
                     <?php if(function_exists('bcn_display')) : ?>
                        <div class="breadcrumb-link mb-15">
                        <?php if(function_exists('bcn_display')) {
                               bcn_display();
                            } ?>
                        </div>
                        <?php endif; ?>
                        <h2 class="breadcrumb-title"><?php echo tecz_kses( $title ); ?></h2>
                     </div>
                  </div>
               </div>
            </div>
            <?php  if ( !empty( $tecz_breadcrumb_shap_switch ) ): ?>
            <div class="breadcrumb-shape">
               <div class="breadcrumb-shape-1 wow fadeInRight" data-wow-duration="1.8s" data-wow-delay=".4s">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/breadcrumb/breadcrumb-shape-1.png" alt="">
               </div>
               <div class="breadcrumb-shape-4 wow slideInRight"  data-wow-duration="1.2s" data-wow-delay=".1s">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/breadcrumb/breadcrumb-shape-3.png" alt="">
               </div>
               <div class="breadcrumb-shape-5 wow slideInRight"  data-wow-duration="1.4s" data-wow-delay=".3s">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/breadcrumb/breadcrumb-shape-2.png" alt="">
               </div>
            </div>
            <?php endif; ?>
         </section>
         <!-- breadcrumb-area-end -->
        <?php
      }
}

add_action( 'tecz_before_main_content', 'tecz_breadcrumb_func' );

// tecz_search_form
function tecz_search_form() {
    ?>
   <!-- header-search -->
   <div class="tpsearchbar tp-sidebar-area tp-search-area">
      <button class="tpsearchbar__close"><i class="fa-sharp fa-regular fa-xmark"></i></button>
      <div class="search-wrap text-center">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-6 col-md-10 pt-100 pb-100">
                  <h2 class="tpsearchbar__title"><?php print esc_html__( 'What Are You Looking For?', 'tecz' );?></h2>
                  <div class="tpsearchbar__form">
                  <form method="get" action="<?php print esc_url( home_url( '/' ) );?>">
                        <input type="search" name="s" value="<?php print esc_attr( get_search_query() )?>" placeholder="<?php print esc_attr__( 'Search Product...', 'tecz' );?>" >
                        <button class="tpsearchbar__search-btn"><i class="fa-regular fa-magnifying-glass"></i></button>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="search-body-overlay"></div>
   <!-- header-search-end -->
   <?php
}
add_action( 'tecz_before_main_content', 'tecz_search_form' );