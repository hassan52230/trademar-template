<?php

// tp metabox 
add_filter( 'tp_meta_boxes', 'themepure_metabox' );

function themepure_metabox( $meta_boxes ) {
	
	$prefix     = 'tecz';
	
	$meta_boxes[] = array(
		'metabox_id'       => $prefix . '_page_meta_box',
		'title'    => esc_html__( 'TP Page Info', 'tecz' ),
		'post_type'=> 'page',
		'context'  => 'normal',
		'priority' => 'core',
		'fields'   => array( 
			array(
				'label'    => esc_html__( 'Show Breadcrumb?', 'tecz' ),
				'id'      => "{$prefix}_check_bredcrumb",
				'type'    => 'switch',
				'default' => 'on',
				'conditional' => array()
			),		
			array(
				'label'    => esc_html__( 'Show Breadcrumb Image?', 'tecz' ),
				'id'      => "{$prefix}_check_bredcrumb_img",
				'type'    => 'switch',
				'default' => 'on',
				'conditional' => array()
			), 
            array(
				
				'label'    => esc_html__( 'Page Logo', 'tecz' ),
				'id'      => "{$prefix}_page_logo",
				'type'    => 'image',
				'default' => '',
				'conditional' => array()
			),
            array(
				
				'label'    => esc_html__( 'Breadcrumb Background', 'tecz' ),
				'id'      => "{$prefix}_breadcrumb_bg",
				'type'    => 'image',
				'default' => '',
				'conditional' => array(
					"{$prefix}_check_bredcrumb_img", "==", "on"
				)
			),

            array(
				'label'    => esc_html__( 'Enable Secondary Logo', 'tecz' ),
				'id'      => "{$prefix}_en_secondary_logo",
				'type'    => 'switch',
				'default' => 'off',
				'conditional' => array()
			), 


            array(
				
				'label'    => esc_html__( 'Footer BG', 'tecz' ),
				'id'      => "{$prefix}_footer_bg",
				'type'    => 'image',
				'default' => '',
				'conditional' => array()
			),

            array(
				'label' => esc_html__( 'Footer BG Color', 'tecz' ),
				'id'   	=> "{$prefix}_footer_bg_color",
				'type' 	=> 'colorpicker',
				'placeholder' => '',
				'default' 	  => '',
				'conditional' => array()
			),

            // multiple buttons group field like multiple radio buttons
			array(
				'label'   => esc_html__( 'Header', 'tecz' ),
				'id'      => "{$prefix}_header_tabs",
				'desc'    => '',
				'type'    => 'tabs',
				'choices' => array(
					'default' => esc_html__( 'Default', 'tecz' ),
					'custom' =>  esc_html__( 'Custom', 'tecz' ),
				),
				'default' => 'default',
				'conditional' => array()
			), 

            // select field dropdown
			array(  
				
				'label'           => esc_html__('Select Header Style', 'tecz'),
				'id'              => "{$prefix}_header_style",
				'type'            => 'select',
				'options'         => array(
					'header_1' =>  esc_html__( 'Header 1', 'tecz' ),
					'header_2' =>  esc_html__( 'Header 2', 'tecz' ),
					'header_3' =>  esc_html__( 'Header 3', 'tecz' ),
					'header_4' =>  esc_html__( 'Header 4', 'tecz' ),
					'header_5' =>  esc_html__( 'Header 5', 'tecz' ),
				),
				'placeholder'     => esc_html__( 'Select a header', 'tecz' ),
				'conditional' => array(
					"{$prefix}_header_tabs", "==", "custom"
				),
				'default' => 'header_1',
				'parent' => 'tecz_header_tabs'
			),

            // select field dropdown
			array(
				
				'label'           => esc_html__('Select Header Template', 'tecz'),
				'id'              => "{$prefix}_header_templates",
				'type'            => 'select_posts',
				'placeholder'     => esc_html__( 'Select a template', 'tecz' ),
                'post_type'       => 'tp-header',
				'conditional' => array(
					"{$prefix}_header_tabs", "==", "elementor"
				),
				'default' => '',
				'parent' => 'tecz_header_tabs'
			),


            // multiple buttons group field like multiple radio buttons
			array(
				'label'   => esc_html__( 'Footer', 'tecz' ),
				'id'      => "{$prefix}_footer_tabs",
				'desc'    => '',
				'type'    => 'tabs',
				'choices' => array(
					'default' => esc_html__( 'Default', 'tecz' ),
					'custom' =>  esc_html__( 'Custom', 'tecz' ),
				),
				'default' => 'default',
				'conditional' => array()
			), 

            // select field dropdown
			array(
				
				'label'           => esc_html__('Select Footer Style', 'tecz'),
				'id'              => "{$prefix}_footer_style",
				'type'            => 'select',
				'options'         => array(
					'footer_1' => esc_html__( 'Footer 1', 'tecz' ),
					'footer_2' => esc_html__( 'Footer 2', 'tecz' ),
					'footer_3' => esc_html__( 'Footer 3', 'tecz' ),
				),
				'placeholder'     => esc_html__( 'Select a footer', 'tecz' ),
				'conditional' => array(
					"{$prefix}_footer_tabs", "==", "custom"
				),
				'default' => 'footer_1',
				'parent' => 'tecz_footer_tabs'
			),

            // select field dropdown
			array(
				
				'label'           => esc_html__('Select Footer Template', 'tecz'),
				'id'              => "{$prefix}_footer_template",
				'type'            => 'select_posts',
				'placeholder'     => 'Select a template',
                'post_type'       => 'tp-footer',
				'conditional' => array(
					"{$prefix}_footer_tabs", "==", "elementor"
				),
				'default' => '',
				'parent' => 'tecz_footer_tabs'
			),
		),
	);

    $meta_boxes[] = array(
        'metabox_id'       => $prefix . '_post_meta_gallery_box',
        'title'    => esc_html__( 'Post Meta Gallery', 'tecz' ),
        'post_type'=> 'post',
        'context'  => 'normal',
        'priority' => 'core',
        'fields'   => array(
            array(
                    
                'label'    => esc_html__( 'Gallery Format', 'tecz' ),
                'id'      => "{$prefix}_post_gallery",
                'type'    => 'gallery',
                'default' => '',
                'conditional' => array(),
            ),
        ),
        'post_format' => 'gallery' // if u want to bind with post formats
    );

	$meta_boxes[] = array(
		'metabox_id'       => $prefix . '_post_video_meta',
		'title'    => esc_html__( 'TP Video Post', 'tecz' ),
		'post_type'=> 'post',
		'context'  => 'normal',
		'priority' => 'core',
		'fields'   => array( 
			array(
				'label'    => esc_html__( 'Video', 'tecz' ),
				'id'      => "{$prefix}_post_video",
				'type'    => 'text',
				'default' => '',
				'conditional' => array(),
				'placeholder'     => 'Place your video url.',
			),
		),
		'post_format' => 'video'
	);	

	$meta_boxes[] = array(
		'metabox_id'       => $prefix . '_post_audio_meta',
		'title'    => esc_html__( 'TP Audio Post', 'tecz' ),
		'post_type'=> 'post',
		'context'  => 'normal',
		'priority' => 'core',
		'fields'   => array( 
			array(
				'label'    => esc_html__( 'Audio', 'tecz' ),
				'id'      => "{$prefix}_post_audio'",
				'type'    => 'text',
				'default' => '',
				'conditional' => array(),
				'placeholder'     => 'Place your audio url.',
			),
		),
		'post_format' => 'audio'
	);
	return $meta_boxes;
}