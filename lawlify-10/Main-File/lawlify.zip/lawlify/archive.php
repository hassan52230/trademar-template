<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package lawlify
 */

get_header();

?>

<section class="page-title">
<div class="page-title_pattern"></div>
<div class="page-title_gradient"></div>
<div class="auto-container">
   <h2><?php echo esc_html__('Blog Classic', 'lawlify'); ?></h2>
   <ul class="bread-crumb clearfix">
      <li><a href="<?php echo get_home_url(); ?>"><i class="fa-solid fa-house fa-fw"></i> Home</a></li>
      <li><?php echo esc_html__('Blog Classic', 'lawlify'); ?></li>
   </ul>
</div>
</section>

<div class="sidebar-page-container">
    	<div class="auto-container">
        	<div class="row clearfix">
				
				<!-- Content Side -->
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
					<div class="blog-classic">
						
						<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
								global $post;
								$categories = get_the_category($post->ID);
								$commentcount = get_comments_number( $post->ID );
								$imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
								$excerpt = get_the_excerpt(); 
								$excerpt = substr( $excerpt, 0, 260 ); // Only display first 260 characters of excerpt
								$result = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
								
								?>

						<!-- News Block -->
						<div class="news-block_one style-three">
							<div class="news-block_one-inner">
								<?php if ( has_post_thumbnail() ) { ?>
								<div class="news-block_one-image">
									<div class="news-block_one-date"><?php echo get_the_date('j'); ?> <span><?php echo get_the_date('M, Y'); ?></span></div>
									<a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo esc_url($imgSrc); ?>" alt="image" /></a>
								</div>
							    <?php } ?>

								<div class="news-block_one-content">
									<ul class="news-block_one-meta d-flex align-items-center flex-wrap">
										<li><span class="icon fa-regular fa-user fa-fw"></span><?php echo esc_html($categories[0]->name); ?></li>
										<li><span class="icon fa-regular fa-comment-dots fa-fw"></span><?php echo $commentcount; ?> Comments</li>
									</ul>
									<h3 class="news-block_one-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
									<div class="news-block_one-text"><?php echo esc_html($result); ?></div>
									<a class="news-block_one-more" href="<?php echo get_the_permalink(); ?>">read more<i class="fa-solid fa-angle-right fa-fw"></i></a>
								</div>
							</div>
						</div>
                       <?php endwhile; wp_reset_query(); endif; ?>

					</div>

					<!-- Styled Pagination -->
					<div class="styled-pagination">
						<?php tecz_pagination( '<i class="fas fa-angle-double-left"></i>', '<i class="fas fa-angle-double-right"></i>', '', [ 'class' => '' ] );?>
					</div>
					<!-- End Styled Pagination -->

				</div>

				<!-- Sidebar Side -->
				<?php if ( is_active_sidebar( 'primary' ) ): ?>
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                	<aside class="sidebar">
						<div class="sidebar-inner">
							<?php dynamic_sidebar('primary');?>
						</div>
					</aside>
				</div>
				<?php endif;?>
			</div>
		</div>
	</div>



<?php
get_footer();
