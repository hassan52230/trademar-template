<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package lawlify
 */

get_header();

?>

<section class="page-title">
	<div class="page-title_pattern"></div>
	<div class="page-title_gradient"></div>
	<div class="auto-container">
		<h2><?php echo esc_html__('Blog Classic', 'lawlify'); ?></h2>
		<ul class="bread-crumb clearfix">
			<li><a href="<?php echo get_home_url(); ?>"><i class="fa-solid fa-house fa-fw"></i> Home</a></li>
			<li><?php echo esc_html__('Blog Classic', 'lawlify'); ?></li>
		</ul>
	</div>
</section>

<div class="sidebar-page-container">
	<div class="auto-container">
		<div class="row clearfix">
			
			<!-- Content Side -->
			<div class="content-side col-lg-8 col-md-12 col-sm-12">
				<div class="blog-classic">
					
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
						   
						?>

						<!-- News Block -->
						<div class="news-block_one style-three">
							<div class="news-block_one-inner">
								<div class="news-block_one-content">
									<div class="news-block_one-text"><?php echo esc_html(the_content()); ?></div>
									
								</div>
							</div>
						</div>
					<?php endwhile; wp_reset_query(); endif; ?>

				</div>

			</div>

			<!-- Sidebar Side -->
			<?php if ( is_active_sidebar( 'primary' ) ): ?>
				<div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
					<aside class="sidebar">
						<div class="sidebar-inner">
							<?php dynamic_sidebar('primary');?>
						</div>
					</aside>
				</div>
			<?php endif;?>
		</div>
	</div>
</div>



<?php
get_footer();
