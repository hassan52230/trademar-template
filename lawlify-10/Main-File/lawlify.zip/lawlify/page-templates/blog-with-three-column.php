<?php
/**
* Template Name: Blog With 3 Column
*/

get_header();

?>

<section class="page-title">
    <div class="page-title_pattern"></div>
    <div class="page-title_gradient"></div>
    <div class="auto-container">
     <h2><?php echo esc_html__('Our Blog', 'lawlify'); ?></h2>
     <ul class="bread-crumb clearfix">
      <li><a href="<?php echo get_home_url(); ?>"><i class="fa-solid fa-house fa-fw"></i> Home</a></li>
      <li><?php echo esc_html__('Our Blog', 'lawlify'); ?></li>
  </ul>
</div>
</section>

<div class="news-three">
    <div class="auto-container">
        <div class="row clearfix">
            <?php
            $paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
            $args = array(
                'post_type'=> 'post',
                'orderby'    => 'ID',
                'post_status' => 'publish',
                'order'    => 'DESC',
                'paged' => $paged,
                'posts_per_page' => 6 
            );

            $query = new WP_Query( $args );
            if ($query->have_posts()) :

                /* Start the Loop */
                while ($query->have_posts()) :
                    $query->the_post();
                    $categories = get_the_category($post->ID);
                    $commentcount = get_comments_number( $post->ID );
                    $imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
                    ?>
                    <div class="news-block_one style-two col-lg-4 col-md-6 col-sm-12">
                        <div class="news-block_one-inner">
                            <?php if ( has_post_thumbnail() ) { ?>
                                <div class="news-block_one-image">
                                    <div class="news-block_one-date"><?php echo get_the_date('j'); ?> <span><?php echo get_the_date('M, Y'); ?></span></div>
                                    <a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo esc_url($imgSrc); ?>" alt="image" /></a>
                                </div>
                            <?php } ?>
                            <div class="news-block_one-content">
                                <ul class="news-block_one-meta d-flex align-items-center flex-wrap">
                                    <li><span class="icon fa-regular fa-user fa-fw"></span><?php echo esc_html($categories[0]->name); ?></li>
                                    <li><span class="icon fa-regular fa-comment-dots fa-fw"></span><?php echo $commentcount; ?> Comments</li>
                                </ul>
                                <h3 class="news-block_one-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
                                <a class="news-block_one-more" href="<?php echo get_the_permalink(); ?>">read more<i class="fa-solid fa-angle-right fa-fw"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
            <?php wp_reset_postdata(); ?>
        </div>
        <div class="law-pagination">
            <?php $total_pages = $query->max_num_pages;

            if ($total_pages > 1){

                $current_page = max(1, get_query_var('paged'));

                echo paginate_links(array(
                    'base' => get_pagenum_link(1) . '%_%',
                    'format' => '/page/%#%',
                    'current' => $current_page,
                    'total' => $total_pages,
                    'prev_text'    => __('<i class="fas fa-angle-double-left"></i>'),
                    'next_text'    => __('<i class="fas fa-angle-double-right"></i>'),
                ));
            } ?>
        </div>

    </div>
</div>

<?php
get_footer();