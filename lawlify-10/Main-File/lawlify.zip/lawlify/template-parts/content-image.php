<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package lawlify
 */
$tecz_singleblog_social = get_theme_mod( 'tecz_singleblog_social', false );
 
$social_shear_col= $tecz_singleblog_social ? "col-xl-6 col-lg-6 " : "col-xl-12 col-md-12 col-lg-12";
if ( is_single() ) : ?>

<article id="post-<?php the_ID();?>" <?php post_class( 'postbox-item format-image mb-50 transition-3' );?>>
    <?php if ( has_post_thumbnail() ): ?>     
        <div class="postbox-thumb w-img">
            <a href="<?php the_permalink();?>">
                <?php the_post_thumbnail( 'full', ['class' => 'img-responsive'] );?>
            </a>
        </div>
    <?php endif; ?>
    <div class="postbox-content">
         <!-- blog meta -->
    <?php get_template_part( 'template-parts/blog/blog-meta' ); ?>        
        <?php the_content();?>
        <?php
            wp_link_pages( [
                'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'lawlify' ),
                'after'       => '</div>',
                'link_before' => '<span class="page-number">',
                'link_after'  => '</span>',
            ] );
        ?>
    </div>
    <div class="postbox-meta-wrapper mt-50">
        <div class="postbox-share mb-70">
            <div class="row">
                <div class="<?php echo esc_attr($social_shear_col); ?>">
                    <?php echo tecz_get_tag(); ?>
                </div>
                <?php tecz_blog_social_share(); ?>
            </div>
        </div>
    </div>
</article>

<?php else: ?>
    <article id="post-<?php the_ID();?>" <?php post_class( 'postbox-item mb-60 transition-3 format-standard' );?>>
    <?php if ( has_post_thumbnail() ): ?>     
        <div class="postbox-thumb w-img">
            <a href="<?php the_permalink();?>">
                <?php the_post_thumbnail( 'full', ['class' => 'img-responsive'] );?>
            </a>
        </div>
    <?php endif; ?>
    <!-- blog meta -->
    <?php get_template_part( 'template-parts/blog/blog-meta' ); ?>
    <div class="postbox-content">            
        <h3 class="postbox-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        <div class="postbox-text">
            <?php the_excerpt(); ?>
        </div>
                <!-- blog btn -->
            <?php get_template_part( 'template-parts/blog/blog-btn' ); ?>
    </div>
</article>
<?php endif;?>