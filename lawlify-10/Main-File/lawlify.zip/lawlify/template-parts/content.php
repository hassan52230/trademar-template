<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package lawlify
 */
$user = wp_get_current_user();
 $tecz_singleblog_social = get_theme_mod( 'tecz_singleblog_social', false );
 $social_shear_col= $tecz_singleblog_social ? "col-xl-6 col-lg-6 " : "col-xl-12 col-md-12 col-lg-12";
if ( is_single() ) : ?>
<article id="post-<?php the_ID();?> blog-detail_inner">
    <?php if ( has_post_thumbnail() ): ?>     
        <div class="blog-detail_image">
                <?php the_post_thumbnail( 'full', ['class' => 'img-responsive'] );?>
        </div>
    <?php endif; ?>

  <div class="blog-detail_content">
                                <h2 class="blog-detail_heading"><?php echo get_the_title(); ?></h2>
                                <div class="blog-detail_author-outer d-flex align-items-center flex-wrap">
                                    <div class="blog-detail-author d-flex align-items-center flex-wrap">
                                        <div class="blog-detail-author-image">
                                            <img src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="" />
                                        </div>
                                        <i>By</i> <?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?>
                                    </div>
                                    <ul class="blog-detail-meta d-flex align-items-center flex-wrap">
                                        <li><span class="icon fa-regular fa-calendar fa-fw"></span><?php echo get_the_date('M j, Y'); ?></li>
                                        <li><span class="icon fa-regular fa-comment-dots fa-fw"></span><?php echo get_comments_number( $post->ID );?> Comments</li>
                                    </ul>
                                    <?php echo get_the_content(); ?>
                                </div>
                               
                               
                               
                                <!-- Post Share Options-->
                                <div class="post-share-options">
                                    <div class="post-share-inner d-flex justify-content-between flex-wrap">
                                        <div class="post-tags">
                                            <?php 
                            $tags = get_tags();

                            foreach ((array)$tags as $key => $tag) {

                             ?>
                                <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ) ?>"><?php echo esc_html($tag->name); ?></a>
                            <?php }
                            ?>
                                        </div>
                                        <ul class="social-links">
                                            <li><a href="#" class="fa-brands fa-facebook-f fa-fw"></a></li>
                                            <li><a href="#" class="fa-brands fa-twitter fa-fw"></a></li>
                                            <li><a href="#" class="fa-brands fa-google fa-fw"></a></li>
                                            <li><a href="#" class="fa-brands fa-dribbble fa-fw"></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <!-- Author Box -->
                                <div class="blog-author_box">
                                    <div class="blog-author-box_inner">
                                        <div class="blog-author-box_content">
                                            <div class="blog-author-box_image">
                                                <img src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="" />
                                            </div>
                                            <h5><?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?></h5>
                                            <div class="blog-author_box-designation"><?php echo get_the_author_meta('email', get_the_author_meta( 'ID' )); ?></div>
                                            <div class="blog-author_box-text"><?php echo get_the_author_meta('description', get_the_author_meta( 'ID' )); ?></div>
                                            <div class="blog-author_signature"><?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <!--End Comment Form -->

                            </div>
</article>


<?php endif;?>