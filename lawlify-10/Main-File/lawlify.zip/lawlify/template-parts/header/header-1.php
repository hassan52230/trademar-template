<?php 

	/**
	 * Template part for displaying header layout one
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
	 *
	 * @package lawlify
	*/

// info
    $header_topbar_switch = get_theme_mod( 'header_topbar_switch', false );
    $tecz_header_cart = get_theme_mod( 'tecz_header_cart', false );
 // Button Text
   $header_button_switch = get_theme_mod( 'header_button_switch', false);
   $header_top_button_text = get_theme_mod( 'header_button_text', __( 'Get Solution', 'lawlify' ) );
    $tecz_acc_button_link = get_theme_mod( 'tecz_acc_button_link', __( '#', 'lawlify' ) );
    $header_top_text = get_theme_mod( 'header_top_text', __( 'Free Delivery on orders over $200. Don’t miss discount.', 'lawlify' ) );
    $header_search_switch = get_theme_mod( 'header_search_switch', false );
    $header_shop_switch = get_theme_mod( 'header_shop_switch', false );
// Phone Number
   $header_top_phone = get_theme_mod( 'header_phone', __( '+8801310-069824', 'lawlify' ) );
// Email id 
   $header_top_email = get_theme_mod( 'header_email', __( 'poorex@support.com', 'lawlify' ) );
   $tecz_top_menu = get_theme_mod( 'header_top_menu', __( 'Top menu set', 'lawlify' ) );
// Header Address Text
   $header_top_address_text = get_theme_mod( 'header_address', __( '76 San Fransisco Street. New York', 'lawlify' ) );
   $header_address_link = get_theme_mod( 'header_address_link', __( '#', 'lawlify' ) );
// header right
    $tecz_header_right = get_theme_mod( 'header_right_switch', false );
    $tecz_menu_col = $tecz_header_right ? 'col-xl-8 d-none d-xl-block' : 'col-xl-10 d-none d-xl-block text-end';


   $tecz_page_logo = function_exists( 'tpmeta_image_field' ) ? tpmeta_image_field( 'tecz_page_logo' ) : '';


?>
 
<!-- header area start -->
<header>
   <div class="tp-header-area tp-header-3 tp-header-height">
   <?php  if ( !empty( $header_topbar_switch ) ): ?>
      <div class="tp-header-3-top theme-bg d-none d-lg-block">
         <div class="tp-header-3-top-wrap d-flex align-items-center justify-content-between">
            <div class="tp-header-3-top-left d-flex align-items-center">
            <?php if(!empty($header_top_address_text)) : ?>
               <div class="tp-header-3-top-left-item">
                  <span><i class="fa-solid fa-location-dot"></i></span>
                  <a href="<?php echo esc_url( $header_address_link ); ?>"><?php echo esc_html( $header_top_address_text ); ?></a>      
               </div>
               <?php endif;  ?> 
               <?php if(!empty($header_top_email)) : ?>
               <div class="tp-header-3-top-left-item">
                  <span><i class="fa-solid fa-envelope"></i></span>
                  <a href="mailto:<?php echo esc_attr($header_top_email); ?>"><?php echo esc_html($header_top_email); ?></a>
               </div>
               <?php endif; ?>
            </div>
            <?php if(!empty($tecz_top_menu)) : ?>
            <div class="tp-header-3-top-right d-flex align-items-center">
               <div class="tp-header-3-top-info">
                  <?php echo tecz_kses($tecz_top_menu); ?>
               </div>
               <div class="tp-header-3-top-social">
                  <?php tecz_header_social_profiles(); ?>
               </div>
            </div>
            <?php endif; ?>
         </div>
      </div>
   <?php endif; ?>
      <div id="header-sticky" class="tp-header-3-wrap white-bg d-flex justify-content-between">
         <div class="tp-header-3-main d-flex">
            <div class="logo">
            <?php if ($tecz_page_logo) : ?>
                <a href="<?php print esc_url( home_url( '/' ) );?>">
                    <img src="<?php print esc_url( $tecz_page_logo['url'] );?>" alt="<?php print esc_attr__( 'logo', 'lawlify' );?>" />
                </a>
            <?php else : ?>
            <?php tecz_header_logo(); ?>
            <?php endif; ?>


            </div>
            <div class="main-menu tp-header-3-menu d-none d-xl-block">
               <nav id="mobile-menu" class="tp-main-menu-content">
               <?php tecz_header_menu(); ?>
               </nav>
            </div>
         </div>
         <?php if( !empty($tecz_header_right)) : ?>
         <div class="tp-header-right d-flex align-items-center">
         <?php  if ( !empty( $header_search_switch ) ): ?>
            <div class="tp-header-search">
               <button class="tp-header-search-btn tp-search-open-btn" type="submit">
                  <i class="fa-light fa-magnifying-glass"></i>
               </button>
            </div>
            <?php endif; ?>
            <?php  if ( !empty( $header_shop_switch ) && class_exists( 'WooCommerce' ) ): ?>
            <div class="tp-header-cart ml-30">
               <button class="tp-header-cart-btn cartmini-open-btn p-relative" type="button">
                  <i class="flaticon-shopping-cart"></i>
                  <span id="tp-cart-item" class="tp-header-action-badge cart__count"><?php echo esc_html(WC()->cart->cart_contents_count); ?></span> 
               </button>
            </div>
            <?php endif; ?>
            <?php  if( !empty( $header_button_switch ) ): ?>
            <div class="tp-header-btn ml-35 mr-30 d-none d-lg-block">
               <a class="tp-btn" href="<?php echo esc_url( $header_top_button_link ); ?>"><?php echo esc_html( $header_top_button_text ); ?></a>
            </div>
            <?php endif; ?>
            <?php  if ( !empty( $header_top_phone ) ): ?>
            <div class="d-none d-xxl-block">
               <div class="tp-header-cta d-flex align-items-center">
                  <div class="tp-header-cta-icon d-none d-lg-block">
                     <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/header-cta-icon.svg" alt="">
                  </div>
                  <div class="tp-header-cta-content d-none d-lg-block">
                     <p><?php echo esc_html__( "Need help? Talk to an expert ", 'lawlify' ) ?></p>
                     <a href="tel:<?php echo esc_html( $header_top_phone ); ?>"><?php echo esc_html( $header_top_phone ); ?></a>
                  </div>
               </div>
            </div>
            <?php endif; ?>
            <div class="offcanvas-btn d-xl-none ml-30">
               <button class="offcanvas-open-btn"><i class="fa-solid fa-bars"></i></button>
            </div>
         </div>
         <?php endif; ?>
      </div>
   </div>
</header>
<!-- header area end -->


<?php get_template_part( 'template-parts/header/header-side-info' ); ?>




