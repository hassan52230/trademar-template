<?php 

	/**
	 * Template part for displaying header layout one
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
	 *
	 * @package lawlify
	*/


	// info
   $header_topbar_switch = get_theme_mod( 'header_topbar_switch', false );
   $tecz_header_cart = get_theme_mod( 'tecz_header_cart', false );
   $header_top_phone = get_theme_mod( 'header_phone', __( '+8801310-069824', 'lawlify' ) );
   $header_top_text = get_theme_mod( 'header_top_text', __( 'Free Delivery on orders over $200. Don’t miss discount.', 'lawlify' ) );
   $header_search_switch = get_theme_mod( 'header_search_switch', false );
   $header_shop_switch = get_theme_mod( 'header_shop_switch', false );
   // header right
   $tecz_header_right = get_theme_mod( 'header_right_switch', false );

  // Button Text
  $header_button_switch = get_theme_mod( 'header_button_switch', false);
  $header_top_button_text = get_theme_mod( 'header_button_text', __( 'Get Solution', 'lawlify' ) );
  $tecz_menu_col = $tecz_header_right ? 'col-xl-8 d-none d-xl-block' : 'col-xl-10 d-none d-xl-block text-end';

  $tecz_page_logo = function_exists( 'tpmeta_image_field' ) ? tpmeta_image_field( 'tecz_page_logo' ) : '';

?>
 <!-- header area start -->
 <header>
      <div id="header-sticky" class="tp-header-area tp-header-transparent tp-header-2" >
         <div class="container">
            <div class="tp-header-box">
               <div class="row align-items-center">
                  <div class="col-xl-3 col-lg-6 col-md-6 col-6">
                     <div class="logo">
                     <?php if ($tecz_page_logo) : ?>
                         <a href="<?php print esc_url( home_url( '/' ) );?>">
                             <img src="<?php print esc_url( $tecz_page_logo['url'] );?>" alt="<?php print esc_attr__( 'logo', 'tecz' );?>" />
                         </a>
                     <?php else : ?>
                     <?php tecz_header_logo(); ?>
                     <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-xl-7 d-none d-xl-block">
                     <div class="main-menu">
                        <nav id="mobile-menu" class="tp-main-menu-content">
                        <?php tecz_header_menu(); ?>
                        </nav>
                     </div>
                  </div>
                  <div class="col-xl-2 col-lg-6 col-md-6 col-6">
                     <div class="tp-header-right d-flex align-items-center justify-content-end">
                     <?php  if ( !empty( $header_search_switch ) ): ?>
                        <div class="tp-header-search">
                           <button class="tp-header-search-btn tp-search-open-btn" type="submit">
                              <i class="fa-light fa-magnifying-glass"></i>
                           </button>
                        </div>
                        <?php endif; ?>
                        <?php  if ( !empty( $header_shop_switch ) && class_exists( 'WooCommerce' ) ): ?>
                        <div class="tp-header-cart ml-30">
                           <button class="tp-header-cart-btn cartmini-open-btn p-relative" type="button">
                              <i class="flaticon-shopping-cart"></i>
                              <span id="tp-cart-item" class="tp-header-action-badge cart__count"><?php echo esc_html(WC()->cart->cart_contents_count); ?></span> 
                           </button>
                        </div>
                        <?php endif; ?>
                        <div class="offcanvas-btn d-xl-none ml-20">
                           <button class="offcanvas-open-btn"><i class="fa-solid fa-bars"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- header area end -->


<?php get_template_part( 'template-parts/header/header-side-info' ); ?>