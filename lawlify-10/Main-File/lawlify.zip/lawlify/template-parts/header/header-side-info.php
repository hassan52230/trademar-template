<?php 

   /**
    * Template part for displaying header side information
    *
    * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
    *
    * @package lawlify
   */

    $tecz_side_hide = get_theme_mod( 'header_sideinfo_switch', false );
    $tecz_side_search = get_theme_mod( 'tecz_side_search', false );
    $tecz_side_logo = get_theme_mod( 'header_side_logo', get_template_directory_uri() . '/assets/img/logo/logo-black.png' );
    $tecz_extra_about_text = get_theme_mod( 'header_side_des', __( 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and will give you a complete account of the system and expound the actual teachings of the great explore', 'lawlify' ) );

    $header_side_button = get_theme_mod( 'header_side_button', __( 'Getting Started', 'lawlify' ) );
    $header_side_button_link = get_theme_mod( 'header_side_button_link', __( '#', 'lawlify' ) );
    $tecz_contact_title = get_theme_mod( 'header_side_title', __( 'Contact Info', 'lawlify' ) );
    $tecz_extra_address = get_theme_mod( 'header_side_address', __( '12/A, Mirnada City Tower, NYC', 'lawlify' ) );
    $tecz_extra_phone = get_theme_mod( 'header_side_number', __( '088889797697', 'lawlify' ) );
    $tecz_extra_email = get_theme_mod( 'header_side_email', __( 'support@mail.com ', 'lawlify' ) );
?>
   <!-- offcanvas area start -->
   <div class="offcanvas__area">
      <div class="offcanvas__wrapper">
         <div class="offcanvas__close">
            <button class="offcanvas__close-btn offcanvas-close-btn">
               <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M11 1L1 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                     stroke-linejoin="round" />
                  <path d="M1 1L11 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                     stroke-linejoin="round" />
               </svg>
            </button>
         </div>
         <div class="offcanvas__content">
            <div class="offcanvas__top mb-70 d-flex justify-content-between align-items-center">
            <?php if (!empty($tecz_side_logo)) : ?>
               <div class="offcanvas__logo logo">
               <a href="<?php print esc_url( home_url( '/' ) );?>">
                     <img src="<?php echo esc_url($tecz_side_logo); ?>" alt="<?php print esc_attr__( 'logo', 'lawlify' );?>">
                  </a>
               </div>
               <?php endif; ?>
            </div>
            <?php if (!empty($tecz_side_hide)) : ?>
               <div class="tp-main-menu-mobile"></div>
                  <?php if (!empty($header_side_button)) : ?>
                     <div class="offcanvas__btn">
                        <a href="<?php echo esc_url($header_side_button_link); ?>" class="tp-btn"><?php echo esc_html($header_side_button); ?></a>
                     </div>
                  <?php endif; ?>
               <div class="side-info-contact">
                  <?php if (!empty($tecz_contact_title)) : ?>
                     <span><?php echo esc_html($tecz_contact_title); ?></span>
                  <?php endif; ?>
                  <?php if (!empty($tecz_extra_address)) : ?>
                     <p><?php echo esc_html($tecz_extra_address); ?></p>
                  <?php endif; ?>
               </div>
               <div class="side-info-social">
                  <?php tecz_header_social_profiles_side(); ?>
               </div>
            <?php endif; ?>
         </div>
      </div>
   </div>
   <div class="body-overlay"></div>
   <!-- offcanvas area end -->
