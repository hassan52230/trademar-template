<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package lawlify
 */
$tecz_singleblog_social = get_theme_mod( 'tecz_singleblog_social', false );
$social_shear_col= $tecz_singleblog_social ? "col-xl-6 col-lg-6 " : "col-xl-12 col-md-12 col-lg-12";
 $tp_gallery_images = function_exists('tpmeta_gallery_field')? tpmeta_gallery_field('tecz_post_gallery') : '';
if ( is_single() ): ?>
<article id="post-<?php the_ID();?>" <?php post_class( 'postbox-item format-image mb-50 transition-3' );?>>
<?php if ( !empty( $tp_gallery_images ) ): ?>
   <div class="postbox-thumb postbox-slider swiper-container w-img p-relative">
      <div class="swiper-wrapper">
      <?php foreach ( $tp_gallery_images as $key => $single_image_src ): ?>
         <div class="postbox-slider-item swiper-slide">
         <img src="<?php echo esc_url( $single_image_src['url'] ); ?>" alt="<?php echo esc_attr($single_image_src['alt'] ); ?>">
         </div>
         <?php endforeach;?>
      </div>
      <div class="postbox-nav">
         <button class="postbox-slider-button-next">
            <i class="fa-sharp fa-regular fa-arrow-right"></i>
         </button>
         <button class="postbox-slider-button-prev">
            <i class="fa-sharp fa-regular fa-arrow-left"></i>
         </button>
      </div>
   </div>
   <?php endif; ?>
    <div class="postbox-content">
         <!-- blog meta -->
    <?php get_template_part( 'template-parts/blog/blog-meta' ); ?>        
        <?php the_content();?>
        <?php
            wp_link_pages( [
                'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'lawlify' ),
                'after'       => '</div>',
                'link_before' => '<span class="page-number">',
                'link_after'  => '</span>',
            ] );
        ?>
    </div>
    <div class="postbox-meta-wrapper mt-50">
        <div class="postbox-share mb-70">
            <div class="row">
                <div class="<?php echo esc_attr($social_shear_col); ?>">
                    <?php echo tecz_get_tag(); ?>
                </div>
                <?php tecz_blog_social_share(); ?>
            </div>
        </div>
    </div>
</article>
<?php else: 
    $categories = get_the_terms( $post->ID, 'category' );    
    $tecx_blog_cat = get_theme_mod( 'tecx_blog_cat', false );
?>
<article id="post-<?php the_ID();?>" <?php post_class( 'postbox-item format-image mb-60 transition-3' );?>>
<?php if ( !empty( $tp_gallery_images ) ): ?>
   <div class="postbox-thumb postbox-slider swiper-container w-img p-relative">
      <div class="swiper-wrapper">
      <?php foreach ( $tp_gallery_images as $key => $single_image_src ): ?>
         <div class="postbox-slider-item swiper-slide">
         <img src="<?php echo esc_url( $single_image_src['url'] ); ?>" alt="<?php echo esc_attr($single_image_src['alt'] ); ?>">
         </div>
         <?php endforeach;?>
      </div>
      <div class="postbox-nav">
         <button class="postbox-slider-button-next">
            <i class="fa-sharp fa-regular fa-arrow-right"></i>
         </button>
         <button class="postbox-slider-button-prev">
            <i class="fa-sharp fa-regular fa-arrow-left"></i>
         </button>
      </div>
   </div>
   <?php endif; ?>
     <!-- blog meta -->
     <?php get_template_part( 'template-parts/blog/blog-meta' ); ?>
    <div class="postbox-content">            
        <h3 class="postbox-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        
        <div class="postbox-text">
            <?php the_excerpt(); ?>
        </div>
                <!-- blog btn -->
            <?php get_template_part( 'template-parts/blog/blog-btn' ); ?>
    </div>
</article>
<?php
endif;?>