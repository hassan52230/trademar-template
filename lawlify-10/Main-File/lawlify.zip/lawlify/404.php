<?php
/**
* The template for displaying 404 pages (not found)
*
* @link https://codex.wordpress.org/Creating_an_Error_404_Page
*
* @package lawlify
*/

get_header();
?>

<section class="page-title">
   <div class="page-title_pattern"></div>
   <div class="page-title_gradient"></div>
   <div class="auto-container">
      <h2><?php echo esc_html__('Error 404', 'lawlify'); ?></h2>
      <ul class="bread-crumb clearfix">
         <li><a href="<?php echo get_home_url(); ?>"><i class="fa-solid fa-house fa-fw"></i> Home</a></li>
         <li><?php echo esc_html__('404', 'lawlify'); ?></li>
      </ul>
   </div>
</section>
<section class="error-one">
   <div class="auto-container">
      <h1><?php echo esc_html__('404', 'lawlify'); ?></h1>
      <h2><?php echo esc_html__("Oops! That page can't be found.", 'lawlify'); ?></h2>
      <div class="text"> <?php echo esc_html__("We're really sorry but we can't seem to find the page you were looking for.Oops! That page can't be found.", 'lawlify'); ?></div>
      <!-- Button Box -->
      <div class="button-box text-center">
         <a href="<?php echo get_home_url(); ?>" class="theme-btn btn-style-one">
            <span class="btn-wrap">
               <span class="text-one">Go Back Home Now <i class="fa-solid fa-angle-right fa-fw"></i></span>
               <span class="text-two">Go Back Home Now <i class="fa-solid fa-angle-right fa-fw"></i></span>
            </span>
         </a>
      </div>
   </div>
</section>

<?php
get_footer();
