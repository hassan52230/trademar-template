<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package lawlify
 */

if ( !is_active_sidebar( 'primary' ) ) {
    return;
}
?>

<?php dynamic_sidebar( 'primary' );?>
