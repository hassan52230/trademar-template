<?php
/**
* The main template file
*
* @package  WordPress
* @subpackage  tpcore
*/
get_header();
global $post;
$breadcrumb_image = get_theme_mod( 'breadcrumb_image', false );
$page_title = $wp_query->post->post_title;


?> 

<!-- Page Title -->
<section class="page-title" style="background-image:url(<?php echo esc_url($breadcrumb_image); ?>)">
<div class="page-title_pattern"></div>
<div class="page-title_gradient"></div>
<div class="auto-container">
   <h2><?php echo esc_html($page_title); ?></h2>
   <ul class="bread-crumb clearfix">
      <li><a href="<?php echo get_home_url(); ?>"><i class="fa-solid fa-house fa-fw"></i> Home</a></li>
      <li><?php echo esc_html($page_title); ?></li>
   </ul>
</div>
</section>
<!-- End Page Title -->

<!-- sercices-area-start -->
<section class="service-detail">
<div class="auto-container">
   <div class="row clearfix">

            <div class="column col-lg-12 col-md-12 col-sm-12">
               <div class="tp-services-details-wrapper ml-30">
                  <?php the_content(); ?>
               </div>
            </div>
          
   </div>

   <!-- Post Share Options-->
   <div class="post-share-options style-two">
      <div class="post-share-inner d-flex justify-content-between align-items-center flex-wrap">
         <div class="post-tags">
            <?php 
                $args = array( 
                   'taxonomy'     => 'services_cat',
                );
                $cats = get_categories($args);
               foreach ( $cats as $key => $cat ) { 
                ?>
            <a href="#"><?php echo esc_html( $cat->name ); ?></a>
             <?php } ?>
         </div>
         <ul class="social-links">
            <?php
              $fb_url = get_post_meta( get_the_ID(), 'facebook', true );
              $tw_url = get_post_meta( get_the_ID(), 'twitter', true );
              $ln_url = get_post_meta( get_the_ID(), 'linkedin', true );
              $yt_url = get_post_meta( get_the_ID(), 'youtube', true );
              $ins_url = get_post_meta( get_the_ID(), 'instagram', true );
              
            ?>
            <?php if ( !empty( $fb_url ) ) { ?>
            <li><a href="<?php echo esc_url( $fb_url ) ?>" class="fa-brands fa-facebook-f fa-fw"></a></li>
            <?php } ?>
            <?php if ( !empty( $tw_url ) ) { ?>
            <li><a href="<?php echo esc_url( $tw_url ) ?>" class="fa-brands fa-twitter fa-fw"></a></li>
            <?php } ?>
            <?php if ( !empty( $ln_url ) ) { ?>
            <li><a href="<?php echo esc_url( $ln_url ) ?>" class="fa-brands fa-linkedin-in fa-fw"></a></li>
            <?php } ?>
            <?php if ( !empty( $yt_url ) ) { ?>
            <li><a href="<?php echo esc_url( $yt_url ) ?>" class="fa-brands fa-youtube fa-fw"></a></li>
            <?php } ?>
            <?php if ( !empty( $ins_url ) ) { ?>
            <li><a href="<?php echo esc_url( $ins_url ) ?>" class="fa-brands fa-instagram fa-fw"></a></li>
            <?php } ?>
         </ul>
      </div>
   </div>

   <div class="service-detail_posts">
      <div class="d-flex align-items-center flex-wrap justify-content-between">
         <div class="new-post">
            <?php $previous_post_url = get_permalink( get_adjacent_post(false,'',true)->ID ); 
            if (!empty($previous_post_url)) {
            ?>
            <a href="<?php echo esc_url($previous_post_url); ?>"><i class="fa-solid fa-angle-left fa-fw"></i> Previous</a>
            <h4><?php previous_post_link('%link'); ?> </h4>
            <?php } ?>
         </div>
         <div class="new-post text-right">
            <?php $next_post_url = get_permalink( get_adjacent_post(false,'',false)->ID );
             if (!empty($next_post_url)) {
             ?>
            <a href="<?php echo esc_url($next_post_url); ?>">next <i class="fa-solid fa-angle-right fa-fw"></i></a>
            <h4><?php next_post_link('%link'); ?></h4>
            <?php } ?>
         </div>
      </div>
   </div>

    

</div>
</section>
<!-- sercices-area-end -->


<?php get_footer();  ?>
