<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Portfolio_Post extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-portfolio-post';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio Post', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );


        $this->end_controls_section();


        $this->tp_section_title_render_controls('portfolio', 'Section Title', 'Sub Title', 'Your title here');

        
        // Product Query

        $this->tp_query_controls('portfolio', 'Portfolio', '6', '10', 'portfolio', 'portfolio-cat');

        // tp_post__columns_section
        $this->tp_columns('col', 'Portfolio Column');

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('portfolio_section', 'Section Style', '.ele-section');
        $this->tp_link_controls_style('portfoli_tab', 'Portfolio Post Tab Button', '.ele-port-tab-btn');
        $this->tp_basic_style_controls('repeater_title', 'Portfolio Post Title Style', '.ele-repeater-title');
        $this->tp_basic_style_controls('repeater_cat', 'Portfolio Post Cetagory Style', '.ele-repeater-cat');
        $this->tp_link_controls_style('repeater_btn', 'Portfolio Post Button', '.ele-repeater-btn');

    }



	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        /**
         * Setup the post arguments.
        */
        $query_args = TP_Helper::get_query_args('portfolio', 'portfolio-cat', $this->get_settings());

       // The Query
       $query = new \WP_Query($query_args);

       $filter_list = $settings['category'];

       $portfolio_filter_btn_active = 1; // for filter button active

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ): 
    $this->add_render_attribute('title_args', 'class', 'section__title-4 tp-el-title');
?>

<?php else: 
    $this->add_render_attribute('title_args', 'class', 'portfolio__section-title tp-el-title');   
    
?>


<section class="tp-portfolio-3-area ele-section">
    <div class="container">
        <?php if( !empty($filter_list) ) : ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-portfolio-tab-button masonary-menu text-center mb-70">
                    <?php 
                    $post_type = 'portfolio';
                    $count_posts = wp_count_posts( $post_type );
                
                    $published_posts = $count_posts->publish;

                    foreach ( $filter_list as $list ): 

                    ?>
                        <?php 
                            if ( $portfolio_filter_btn_active === 1 ): 
                            $portfolio_filter_btn_active++; 
                        ?>
                        <button class="active ele-port-tab-btns" data-filter="*"><?php echo esc_html__( 'See All','tpcore' ); ?></button>
                        <button class="ele-port-tab-btn" data-filter=".<?php echo esc_attr( $list ); ?>"><?php echo esc_html( $list ); ?> <span></span></button>
                        <?php else: ?>
                        <button class="ele-port-tab-btn" data-filter=".<?php echo esc_attr( $list ); ?>"><?php echo esc_html( $list ); ?></button>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if( !empty($filter_list) ) : ?>
        <div class="row grid">

            <?php 
            while ($query->have_posts()) : 
            $query->the_post();
            global $post;
            $terms = get_the_terms($post->ID, 'portfolio-cat'); 
            $item_classes = '';
            $item_cat_names = '';
            $item_cats = get_the_terms( $post->ID, 'portfolio-cat' );
            if( !empty($item_cats) ):
                $count = count($item_cats) - 1;
                foreach($item_cats as $key => $item_cat) {
                    $item_classes .= $item_cat->slug . ' ';
                    $item_cat_names .= ( $count > $key ) ? $item_cat->name  . ', ' : $item_cat->name;
                }
            endif; 
            $harry_video_url = function_exists('get_field') ? get_field('add_portfolio_video') : '';
            ?>
            <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?> tp-portfolio grid-item <?php echo $item_classes; ?>">
                <div class="tp-project-thumb w-img p-relative mb-30">
                <?php if ( has_post_thumbnail() ): ?>
                    <a href="<?php echo esc_url( get_the_permalink() ); ?>">
                        <?php the_post_thumbnail('full'); ?>
                    </a>
                <?php endif; ?>
                <div class="tp-project-info p-relative">
                    <div class="tp-project-content">
                        <div class="tp-project-title-wrapper">
                            <h4 class="tp-project-title ele-repeater-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php the_title(); ?></a></h4>
                            <p class="ele-repeater-cat"><?php echo esc_html($item_cat_names); ?></p>
                        </div>
                    </div>
                    <div class="tp-project-btn">
                        <a class="ele-repeater-btn" href="<?php echo esc_url( get_the_permalink() ); ?>"><i class="fa-regular fa-arrow-up-right"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <?php endwhile;  wp_reset_query(); ?>
        </div>
        <?php else : ?>
        <div class="row grid">
            <?php 
            while ($query->have_posts()) : 
            $query->the_post();
            global $post;
            $terms = get_the_terms($post->ID, 'portfolio-cat'); 
            $item_classes = '';
            $item_cat_names = '';
            $item_cats = get_the_terms( $post->ID, 'portfolio-cat' );
            if( !empty($item_cats) ):
                $count = count($item_cats) - 1;
                foreach($item_cats as $key => $item_cat) {
                    $item_classes .= $item_cat->slug . ' ';
                    $item_cat_names .= ( $count > $key ) ? $item_cat->name  . ', ' : $item_cat->name;
                }
            endif; 
            $harry_video_url = function_exists('get_field') ? get_field('add_portfolio_video') : '';
            ?>
            <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?> tp-portfolio grid-item <?php echo $item_classes; ?>">
                    <div class="tp-project-thumb w-img p-relative mb-30">
                    <?php if ( has_post_thumbnail() ): ?>
                        <a href="<?php echo esc_url( get_the_permalink() ); ?>">
                            <?php the_post_thumbnail('full'); ?>
                        </a>
                    <?php endif; ?>
                    <div class="tp-project-info p-relative">
                        <div class="tp-project-content">
                            <div class="tp-project-title-wrapper">
                                <h4 class="tp-project-title ele-repeater-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                <p class="ele-repeater-cat"><?php echo esc_html($item_cat_names); ?></p>
                            </div>
                        </div>
                        <div class="tp-project-btn">
                            <a class="ele-repeater-btn" href="<?php echo esc_url( get_the_permalink() ); ?>"><i class="fa-regular fa-arrow-up-right"></i></a>
                        </div>
                    </div>
                    </div>
            </div>
            <?php endwhile; wp_reset_query(); ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php endif;
	}

}

$widgets_manager->register( new TP_Portfolio_Post() );