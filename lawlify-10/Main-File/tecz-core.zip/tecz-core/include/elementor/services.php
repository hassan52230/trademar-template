<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;
use TPCore\Elementor\Controls\Group_Control_TPGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Services extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'services';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Services', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                    'layout-5' => esc_html__('Layout 5', 'tpcore'),
                    'layout-6' => esc_html__('Layout 6', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        $this->tp_button_render('about', 'Button', ['layout-6']); 
      
        $this->tp_section_title_render_controls('services', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-2', 'layout-3', 'layout-4', 'layout-5']); 

        // Service group
        $this->start_controls_section( 
            'tp_services',
            [
                'label' => esc_html__('Services List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']
                ]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                    'style_3' => __( 'Style 3', 'tpcore' ),
                    'style_4' => __( 'Style 4', 'tpcore' ),
                    'style_5' => __( 'Style 5', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );
        $repeater->add_control(
            'tp_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],
                'condition' => [
                    'repeater_condition' => [ 'style_2', 'style_3', 'style_4', 'style_5']
                ]
            ]
        );

        $repeater->add_control(
            'tp_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                'condition' => [
                    'tp_box_icon_type' => 'svg',
                    'repeater_condition' => [ 'style_2', 'style_3', 'style_4', 'style_5']
                ]
            ]
        );

        $repeater->add_control(
            'tp_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_box_icon_type' => 'image',
                    'repeater_condition' => ['style_2', 'style_3', 'style_4', 'style_5']
                ]
            ]
        );

        if (tp_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'tp_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'tp_box_icon_type' => 'icon',
                        'repeater_condition' => ['style_2', 'style_3', 'style_4', 'style_5']
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'tp_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'tp_box_icon_type' => 'icon',
                        'repeater_condition' => ['style_2', 'style_3', 'style_4', 'style_5']
                    ]
                ]
            );
        }
        $repeater->add_control(
            'tp_service_largs_text', [
                'label' => esc_html__('Service Large Text', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('R', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_1']
                ]
            ]
        );

        $repeater->add_control(
            'tp_service_title', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_1', 'style_2', 'style_3', 'style_4', 'style_5']
                ]
            ]
        );

        $repeater->add_control(
            'tp_service_description',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered.',
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'tp_services_image_avata',
            [
                'label' => esc_html__('Upload Avata Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => ['style_1']
                ]
            ]
        );
        $repeater->add_control(
            'tp_services_image_bg',
            [
                'label' => esc_html__('Upload Bg Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => ['style_2', 'style_4']
                ]
            ]
        );
        $repeater->add_control(
            'tp_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'tp_services_btn_text',
            [
                'label' => esc_html__('Button Text', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tpcore'),
                'title' => esc_html__('Enter button text', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_services_link_switcher' => 'yes',
                    'repeater_condition' => ['style_1', 'style_2', 'style_3']
                ],
            ]
        );
        $repeater->add_control(
            'tp_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'tp_services_link_switcher' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'tp_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'tpcore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'tp_services_link_type' => '1',
                    'tp_services_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'tp_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_services_link_type' => '2',
                    'tp_services_link_switcher' => 'yes',
                ]
            ]
        );
        
        // creative animation
        $repeater->add_control(
			'tp_creative_anima_switcher',
			[
				'label' => esc_html__( 'Active Animation', 'tpcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tpcore' ),
				'label_off' => esc_html__( 'No', 'tpcore' ),
				'return_value' => 'yes',
				'default' => '0',
                'separator' => 'before',
                'condition' => [
                    'repeater_condition' => ['style_1', 'style_4']
                ]
			]
		);

        $repeater->add_control(
            'tp_anima_type',
            [
                'label' => __( 'Animation Type', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'fadeInUp' => __( 'fadeInUp', 'tpcore' ),
                    'fadeInDown' => __( 'fadeInDown', 'tpcore' ),
                    'fadeInLeft' => __( 'fadeInLeft', 'tpcore' ),
                    'fadeInRight' => __( 'fadeInRight', 'tpcore' ),
                ],
                'default' => 'fadeInUp',
                'frontend_available' => true,
                'style_transfer' => true,
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1', 'style_4']
                ],
            ]
        );
        
        $repeater->add_control(
            'tp_anima_dura', [
                'label' => esc_html__('Animation Duration', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.3s', 'tpcore'),
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1', 'style_4']
                ],
            ]
        );
        
        $repeater->add_control(
            'tp_anima_delay', [
                'label' => esc_html__('Animation Delay', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.6s', 'tpcore'),
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1', 'style_4']
                ],
            ]
        );

        $this->add_control(
            'tp_service_list',
            [
                'label' => esc_html__('Services - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_service_title' => esc_html__('Business Stratagy', 'tpcore'),
                    ],
                    [
                        'tp_service_title' => esc_html__('Website Development', 'tpcore')
                    ],
                    [
                        'tp_service_title' => esc_html__('Marketing & Reporting', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_service_title }}}',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                'condition' => [
                    'tp_design_style' => ['layout-2', 'layout-4']
                ]
            ]
        );
        $this->end_controls_section();
  // _tp_image
  $this->start_controls_section(
    '_tp_image',
    [
        'label' => esc_html__('Thumbnail', 'tpcore'),
        'condition' => [
            'tp_design_style' => ['layout-3', 'layout-5']
        ]
    ]
);
$this->add_control(
    'tp_image',
    [
        'label' => esc_html__( 'Choose BG Image', 'tpcore' ),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ], 
    ]
);
$this->add_group_control(
    Group_Control_Image_Size::get_type(),
    [
        'name' => 'tp_image_size',
        'default' => 'full',
        'exclude' => [
            'custom'
        ]
    ]
);
$this->end_controls_section();


$this->start_controls_section(
    'tp_services_single',
    [
        'label' => esc_html__('About Services ', 'tpcore'),
        'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'tp_design_style' => ['layout-6']
        ]
    ]
);



$this->add_control(
    'repeater_condition',
    [
        'label' => __( 'Field condition', 'tpcore' ),
        'type' => Controls_Manager::SELECT,
        'options' => [
            'style_1' => __( 'Style 1', 'tpcore' ),
        ],
        'default' => 'style_1',
        'frontend_available' => true,
        'style_transfer' => true,
    ]
);



$this->add_control(
    'tp_box_icon_type',
    [
        'label' => esc_html__('Select Icon Type', 'tpcore'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'icon',
        'options' => [
            'image' => esc_html__('Image', 'tpcore'),
            'icon' => esc_html__('Icon', 'tpcore'),
            'svg' => esc_html__('SVG', 'tpcore'),
        ],
    
    ]
);

$this->add_control(
    'tp_box_icon_svg',
    [
        'show_label' => false,
        'type' => Controls_Manager::TEXTAREA,
        'label_block' => true,
        'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
        'condition' => [
            'tp_box_icon_type' => 'svg',
        ]
    ]
);

$this->add_control(
    'tp_box_icon_image',
    [
        'label' => esc_html__('Upload Icon Image', 'tpcore'),
        'type' => Controls_Manager::MEDIA,
        'default' => [
            'url' => Utils::get_placeholder_image_src(),
        ],
        'condition' => [
            'tp_box_icon_type' => 'image',
        ]
    ]
);

if (tp_is_elementor_version('<', '2.6.0')) {
    $this->add_control(
        'tp_box_icon',
        [
            'show_label' => false,
            'type' => Controls_Manager::ICON,
            'label_block' => true,
            'default' => 'fa fa-star',
            'condition' => [
                'tp_box_icon_type' => 'icon',
            ]
        ]
    );
} else {
    $this->add_control(
        'tp_box_selected_icon',
        [
            'show_label' => false,
            'type' => Controls_Manager::ICONS,
            'fa4compatibility' => 'icon',
            'label_block' => true,
            'default' => [
                'value' => 'fas fa-star',
                'library' => 'solid',
            ],
            'condition' => [
                'tp_box_icon_type' => 'icon',
            ]
        ]
    );
}

$this->add_control(
    'tp_service_title', [
        'label' => esc_html__('Title', 'tpcore'),
        'description' => tp_get_allowed_html_desc( 'basic' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'About Service Title', 'tpcore'),
        'label_block' => true,
    ]
);
$this->add_control(
    'tp_service_contat_prag',
    [
        'label'       => esc_html__( 'About services Desc', 'tpcore' ),
        'type'        => \Elementor\Controls_Manager::TEXTAREA,
        'default'     => esc_html__( 'Lorem ipsum dolor sit amet, consectetur
        adipiscing elit, sed do eiusm', 'tpcore' ),
        'label_block' => true,
    ]
);    
$this->add_control(
    'tp_services_page_link',
    [
        'label' => esc_html__( 'Select Service Link Page', 'tpcore' ),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'label_block' => true,
        'options' => tp_get_all_pages(),
        'condition' => [
            'tp_services_link_type' => '2',
            'tp_services_link_switcher' => 'yes',
        ]
    ]
);



$this->end_controls_section();



        // colum controls
        $this->tp_columns('col', ['layout-1', 'layout-2', 'layout-3', 'layout-4']);
    }

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('services_section', 'Section - Style', '.tp-el-section');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
?>
  <!-- services-area-start -->
  <section class="services-area tp-services-two pb-120">
         <div class="container">
            <div class="row align-items-end">
               <div class="col-xl-5 col-lg-6">
                  <div class="tp-section tp-section-two mb-50 wow fadeInRight" data-wow-duration="1s"
                     data-wow-delay=".4s">
                     <?php if ( !empty($settings['tp_services_sub_title']) ) : ?>
                     <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_services_sub_title']); ?></span>
                     <?php endif; ?>
                     <?php
                    if ( !empty($settings['tp_services_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_services_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_services_title' ] )
                        );
                    endif;
                    ?>
                  </div>
               </div>
               <div class="offset-xl-2 col-xl-5 col-lg-6">
                  <div class="tp-section mb-40 wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".4s">
                     <div class="tp-section-title-wrapper">
                     <?php if ( !empty($settings['tp_services_description']) ) : ?>
                    <p><?php echo tp_kses( $settings['tp_services_description'] ); ?></p>
                    <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="swiper-container tp-services-two-active">
            <div class="swiper-wrapper">
            <?php foreach ($settings['tp_service_list'] as $key => $item) :
                // Link
                if ('2' == $item['tp_services_link_type']) {
                    $link = get_permalink($item['tp_services_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
                    $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
                }
                if ( !empty($item['tp_services_image_bg']['url']) ) {
                    $tp_services_image_url = !empty($item['tp_services_image_bg']['id']) ? wp_get_attachment_image_url( $item['tp_services_image_bg']['id'], $settings['thumbnail_size']) : $item['tp_services_image_bg']['url'];
                    $tp_services_image_alt = get_post_meta($item["tp_services_image_bg"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
               <div class="swiper-slide">
                  <div class="tp-services-two-bg tp-thumb-common fix"
                  style="background-image: url(<?php echo esc_url($tp_services_image_url); ?>);">
                     <div class="tp-thumb-common-overlay wow"></div>
                     <div class="tp-services-two-item">
                        <div class="tp-services-two-count">
                           <span>0<?php echo ( $key+1); ?></span> 
                        </div>
                        <div class="tp-services-two-content">
                           <div class="tp-services-two-item-icon">
                           <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                            <span><?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?></span>
                            <?php endif; ?>
                        <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                            <span><img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>"></span>
                            <?php endif; ?>
                        <?php else : ?>
                            <?php if (!empty($item['tp_box_icon_svg'])): ?>
                            <span><?php echo $item['tp_box_icon_svg']; ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                           </div>
                           <?php if (!empty($item['tp_service_title' ])): ?>
                            <h4 class="tp-services-two-title">
                            <?php if ($item['tp_services_link_switcher'] == 'yes') : ?>
                            <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_service_title' ]); ?></a>
                            <?php else : ?>
                            <?php echo tp_kses($item['tp_service_title' ]); ?>
                            <?php endif; ?>
                        </h4>
                        <?php endif; ?>
                        </div>
                        <?php if(!empty($item['tp_services_btn_text'])) : ?>
                            <div class="tp-services-two-btn">
                            <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_services_btn_text']); ?></a>
                        </div>
                        <?php endif; ?>
                        <div class="tp-services-two-shape">
                           <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services/two/services-2-shape-1.png" alt="">
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </section>
      <!-- services-area-end -->
<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
        // thumbnail
        if ( !empty($settings['tp_image']['url']) ) {
            $tp_bg_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
            $tp_bg_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
        }
 ?>
<!-- Offering-area-start -->
<section class="offering-area tp-offer-bg pb-80 pt-120" style="background-image: url(<?php echo esc_url($tp_bg_image); ?>);">
<div class="container">
    <div class="row align-items-end">
        <div class="col-lg-7">
            <div class="tp-section tp-section-white-two mb-80">
            <?php if ( !empty($settings['tp_services_sub_title']) ) : ?>
            <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_services_sub_title']); ?></span>
            <?php endif; ?>
            <?php
                if ( !empty($settings['tp_services_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $settings['tp_services_title_tag'] ),
                    $this->get_render_attribute_string( 'title_args' ),
                    tp_kses( $settings['tp_services_title' ] )
                    );
                endif;
            ?>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="tp-section-title-wrapper mb-80">
            <?php if ( !empty($settings['tp_services_description']) ) : ?>
                <p><?php echo tp_kses( $settings['tp_services_description'] ); ?></p>
        <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
    <?php foreach ($settings['tp_service_list'] as $key => $item) :
    // Link
        if ('2' == $item['tp_services_link_type']) {
            $link = get_permalink($item['tp_services_page_link']);
            $target = '_self';
            $rel = 'nofollow';
        } else {
            $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
            $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
            $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
        }
        if ( !empty($item['tp_services_image_bg']['url']) ) {
            $tp_services_image_url = !empty($item['tp_services_image_bg']['id']) ? wp_get_attachment_image_url( $item['tp_services_image_bg']['id'], $settings['thumbnail_size']) : $item['tp_services_image_bg']['url'];
            $tp_services_image_alt = get_post_meta($item["tp_services_image_bg"]["id"], "_wp_attachment_image_alt", true);
        }
        ?>
        <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="tp-offer-item mb-40 wow bounceIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <div class="tp-offer-item-icon">
            <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                <span><?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?></span>
                <?php endif; ?>
            <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                <span><img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>"></span>
                <?php endif; ?>
            <?php else : ?>
                <?php if (!empty($item['tp_box_icon_svg'])): ?>
                <span><?php echo $item['tp_box_icon_svg']; ?></span>
                <?php endif; ?>
            <?php endif; ?>
            </div>
            <div class="tp-offer-item-content">
            <?php if (!empty($item['tp_service_title'])): ?>
                <h4 class="tp-offer-item-title under-line-white">
                <?php if ($item['tp_services_link_switcher'] == 'yes') : ?>
                <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_service_title' ]); ?></a>
                <?php else : ?>
                <?php echo tp_kses($item['tp_service_title' ]); ?>
                <?php endif; ?>
                </h4>
                <?php if (!empty($item['tp_service_description'])): ?>
                <p><?php echo tp_kses($item['tp_service_description']);?></p>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php if (!empty($item['tp_services_btn_text'])): ?>
            <div class="tp-offer-item-btn">
                <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_services_btn_text']); ?><i class="fa-regular fa-arrow-right"></i></a>
            </div>
            <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</div>
</section>
<!-- Offering-area-end -->

<?php elseif ( $settings['tp_design_style']  == 'layout-4' ) : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
?>

      <!-- services-area-start -->
      <section class="provide-area tp-provide-bg pb-60">
         <div class="container tp-provide-width">
            <div class="row">
               <div class="col-lg-12">
                  <div class="tp-section tp-section-red text-center mb-50">
                     <?php if ( !empty($settings['tp_services_sub_title']) ) : ?>
                     <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_services_sub_title']); ?></span>
                     <?php endif; ?>
                     <?php
                    if ( !empty($settings['tp_services_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_services_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_services_title' ] )
                        );
                    endif;
                    ?>
                  </div>
               </div>
            </div>
            <div class="row gx-0">
                <?php foreach ($settings['tp_service_list'] as $key => $item) :
                    // Link
                    if ('2' == $item['tp_services_link_type']) {
                        $link = get_permalink($item['tp_services_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
                        $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
                    }
                    if ( !empty($item['tp_services_image_bg']['url']) ) {
                        $tp_services_image_url = !empty($item['tp_services_image_bg']['id']) ? wp_get_attachment_image_url( $item['tp_services_image_bg']['id'], $settings['thumbnail_size']) : $item['tp_services_image_bg']['url'];
                        $tp_services_image_alt = get_post_meta($item["tp_services_image_bg"]["id"], "_wp_attachment_image_alt", true);
                    }

                ?>
               <div class="col-lg-3 col-md-6">
                  <div class="tp-provide-wrap mb-60 tp-thumb-common fix">
                     <div class="tp-thumb-common-overlay-red wow"></div>
                     <div class="tp-provide-item-bg"
                     style="background-image: url(<?php echo esc_url($tp_services_image_url); ?>);"></div>
                     <div class="tp-provide-shape-1">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services/four/provide-shape-1.png" alt="">
                     </div>
                     <div class="tp-provide-item">
                        <div class="tp-provide-item-icon">
                        <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                            <span><?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?></span>
                            <?php endif; ?>
                        <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                            <span><img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>"></span>
                            <?php endif; ?>
                        <?php else : ?>
                            <?php if (!empty($item['tp_box_icon_svg'])): ?>
                            <span><?php echo $item['tp_box_icon_svg']; ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                        </div>
                        <div class="tp-provide-item-content">
                           <h4 class="tp-provide-item-title under-line-white">
                                <?php if ($item['tp_services_link_switcher'] == 'yes') : ?>
                                <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_service_title' ]); ?></a>
                                <?php else : ?>
                                <?php echo tp_kses($item['tp_service_title' ]); ?>
                                <?php endif; ?>
                           </h4>
                                 <?php if (!empty($item['tp_service_description'])): ?>
                                     <p><?php echo tp_kses($item['tp_service_description']);?></p>
                                <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </section>
      <!-- services-area-end -->
<?php elseif ( $settings['tp_design_style']  == 'layout-5' ) : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
        // thumbnail
        if ( !empty($settings['tp_image']['url']) ) {
        $tp_bg_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_bg_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }
    ?>

    <!-- services-area-start -->
    <section class="services-area tp-services-5-bg pt-115 pb-70"
    style="background-image: url(<?php echo esc_url($tp_bg_image); ?>);">
        <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-section tp-section-red-white text-center mb-50">
                <?php if ( !empty($settings['tp_services_sub_title']) ) : ?>
                    <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_services_sub_title']); ?></span>
                    <?php endif; ?>
                    <?php
                if ( !empty($settings['tp_services_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $settings['tp_services_title_tag'] ),
                    $this->get_render_attribute_string( 'title_args' ),
                    tp_kses( $settings['tp_services_title' ] )
                    );
                endif;
                ?>
                </div>
            </div>
        </div>
        <div class="row">
            <?php foreach ($settings['tp_service_list'] as $key => $item) :
                // Link
                if ('2' == $item['tp_services_link_type']) {
                    $link = get_permalink($item['tp_services_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
                    $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
                }
                if ( !empty($item['tp_services_image_avata']['url']) ) {
                    $tp_services_image_url = !empty($item['tp_services_image_avata']['id']) ? wp_get_attachment_image_url( $item['tp_services_image_avata']['id'], $settings['thumbnail_size']) : $item['tp_services_image_avata']['url'];
                    $tp_services_image_alt = get_post_meta($item["tp_services_image_avata"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div class="col-lg-3 col-md-6">
                <div class="tp-services-5 mb-40">
                    <div class="tp-services-5-icon mb-25">
                    <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                    <span><?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?></span>
                    <?php endif; ?>
                <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                    <span><img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>"></span>
                    <?php endif; ?>
                <?php else : ?>
                    <?php if (!empty($item['tp_box_icon_svg'])): ?>
                    <span><?php echo $item['tp_box_icon_svg']; ?></span>
                    <?php endif; ?>
                <?php endif; ?>
                    </div>
                    <div class="tp-services-5-content">
                    <h5 class="tp-services-5-title under-line-white mb-25">
                    <?php if ($item['tp_services_link_switcher'] == 'yes') : ?>
                        <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_service_title' ]); ?></a>
                        <?php else : ?>
                        <?php echo tp_kses($item['tp_service_title' ]); ?>
                    <?php endif; ?>
                    </h5>
                        <?php if (!empty($item['tp_service_description'])): ?>
                            <p><?php echo tp_kses($item['tp_service_description']);?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        </div>
    </section>
    <!-- services-area-end -->
<?php elseif ( $settings['tp_design_style']  == 'layout-6' ) : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
        // Link
        if ('2' == $settings['tp_about_btn_link_type']) {
            $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_about_btn_page_link']));
            $this->add_render_attribute('tp-button-arg', 'target', '_self');
            $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('tp-button-arg', 'class', '');
        } else {
            if ( ! empty( $settings['tp_about_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'tp-button-arg', $settings['tp_about_btn_link'] );
                $this->add_render_attribute('tp-button-arg', 'class', '');
            }
        }
        // thumbnail
        if ( !empty($settings['tp_image']['url']) ) {
        $tp_bg_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_bg_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
     }
    ?>
      <!-- services-area-start -->
      <section class="services-area tp-services-4">
         <div class="container"> 
            <div class="row align-items-center">
               <div class="col-lg-6 col-md-5">
                  <div class="tp-services-4-info wow fadeInLeft" data-wow-duration=".6s" data-wow-delay=".6s">
                     <div class="tp-services-4-info-wrap d-flex align-items-center">
                        <div class="tp-services-4-info-icon">
                        <?php if($settings['tp_box_icon_type'] == 'icon') : ?>
                        <?php if (!empty($settings['tp_box_icon']) || !empty($settings['tp_box_selected_icon']['value'])) : ?>
                        <span><?php tp_render_icon($settings, 'tp_box_icon_contat', 'tp_box_selected_icon'); ?></span>
                            <?php endif; ?>
                        <?php elseif( $settings['tp_box_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($settings['tp_box_icon_image']['url'])): ?>
                            <span><img src="<?php echo $settings['tp_box_icon_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($settings['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>"></span>
                            <?php endif; ?>
                        <?php else : ?>
                            <?php if (!empty($settings['tp_box_icon_svg'])): ?>
                            <span><?php echo $settings['tp_box_icon_svg']; ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                        </div>
                        <div class="tp-services-4-info-content">
                           <h4 class="tp-services-4-info-title"><?php echo tp_kses($settings['tp_service_title']);?></h4>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-md-7">
                  <div class="tp-services-4-wrapper wow fadeInRight" data-wow-duration=".6s" data-wow-delay=".6s">
                     <h4 class="tp-services-4-title"><?php echo tp_kses($settings['tp_service_contat_prag']);?></h4>
                     <div class="tp-services-4-details">
                     <?php if(!empty($settings['tp_about_btn_text'])) : ?>
                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><?php echo tp_kses($settings['tp_about_btn_text']); ?><span><i class="fa-regular fa-arrow-right"></i></span></a>
                    <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="tp-services-4-shape-1">
            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/shape/services-4-shape-1.png" alt="">
         </div>
      </section>
      <!-- services-area-end -->

<?php else:
    $this->add_render_attribute('title_args', 'class', 'tpsection-title');
?>
     <!-- services-area-start -->
     <section class="services-area tp-services-plr pb-90">
         <div class="container-fluid tp-services-width">
            <div class="row">
            <?php foreach ($settings['tp_service_list'] as $key => $item) :
                // Link
                if ('2' == $item['tp_services_link_type']) {
                    $link = get_permalink($item['tp_services_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
                    $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
                }
                if ( !empty($item['tp_services_image_avata']['url']) ) {
                    $tp_services_image_url = !empty($item['tp_services_image_avata']['id']) ? wp_get_attachment_image_url( $item['tp_services_image_avata']['id'], $settings['thumbnail_size']) : $item['tp_services_image_avata']['url'];
                    $tp_services_image_alt = get_post_meta($item["tp_services_image_avata"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
                <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?>">
                  <div class="tp-services-item d-flex mb-30 wow fadeInRight" data-wow-duration="1s"
                     data-wow-delay=".4s">
                     <?php if (!empty($item['tp_service_largs_text' ])): ?>
                     <div class="tp-services-item-head">
                        <span><?php echo tp_kses($item['tp_service_largs_text']);?></span>
                     </div>
                    <?php endif; ?>
                     <?php if(!empty($tp_services_image_url)) : ?>
                     <div class="tp-services-item-thumb">
                     <img src="<?php echo esc_url($tp_services_image_url); ?>" alt="<?php echo esc_attr($tp_services_image_alt); ?>">
                     </div>
                     <?php endif; ?>
                     <div class="tp-services-item-content">
                           <?php if (!empty($item['tp_service_title' ])): ?>
                        <h4 class="tp-services-item-title">
                            <?php if ($item['tp_services_link_switcher'] == 'yes') : ?>
                            <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_service_title' ]); ?></a>
                            <?php else : ?>
                            <?php echo tp_kses($item['tp_service_title' ]); ?>
                            <?php endif; ?>
                        </h4>
                        <?php endif; ?>
                        <?php if(!empty($item['tp_service_description'])) : ?>
                        <p><?php echo tp_kses($item['tp_service_description']); ?></p>
                        <?php endif; ?>
                     </div>
                     <div class="tp-services-item-shape">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services/one/shape/shape-01.png" alt="">
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </section>
      <!-- services-area-end -->

<?php endif; 
    }
}

$widgets_manager->register( new TP_Services() ); 