<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Blog_Post extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'blogpost';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog Post', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                    'layout-5' => esc_html__('Layout 5', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->tp_section_title_render_controls('blog', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2', 'layout-3','layout-4', 'layout-5']);
        
        // Blog Query
		$this->tp_query_controls('blog', 'Blog');

        // tp_post__columns_section
        $this->tp_columns('col', ['layout-1', 'layout-2', 'layout-3','layout-4', 'layout-5']);
    }

    // style_tab_content
    protected function style_tab_content(){
		$this->tp_section_style_controls('blog_section', 'Section Style', '.tp-el-section');
    }
    
	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        /**
         * Setup the post arguments.
        */
        $query_args = TP_Helper::get_query_args('post', 'category', $this->get_settings());

        // The Query
        $query = new \WP_Query($query_args);


        $filter_list = $settings['category'];

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) :
  $this->add_render_attribute('title_args', 'class', 'tp-section-title');    
?>
 <!-- blog-area-start -->
 <section class="blog-area tp-blog-two-bg fix tp-el-section">
         <div class="container">
            <div class="row align-items-end">
               <div class="col-lg-5">
                  <div class="tp-section tp-section-two mb-35">
                     <?php if ( !empty($settings['tp_blog_sub_title']) ) : ?>
                            <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_blog_sub_title']); ?></span>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['tp_blog_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_blog_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_blog_title' ] )
                            );
                        endif;
                        ?>
                  </div>
               </div>
               <div class="offset-lg-2 col-lg-5">
                  <div class="tp-section mb-40">
                     <div class="tp-section-title-wrapper">
                         <?php if ( !empty($settings['tp_blog_description']) ) : ?>
                            <p><?php echo tp_kses( $settings['tp_blog_description'] ); ?></p>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12">
                  <div class="tp-blog-two-wrapper">
                     <div class="swiper-container tp-blog-two-active">
                        <div class="swiper-wrapper">
                            <?php 
                                if ($query->have_posts()) : 
                                    $i = 0;
                                    while ($query->have_posts()) : 
                                    $query->the_post();
                                    global $post;
                                    $categories = get_the_category($post->ID);
                                    $i++;
                                    
                            ?>
                           <div class="swiper-slide">
                              <div class="tp-blog-two mb-40">
                                 <div class="tp-blog-two-item">
                                        <?php if(has_post_thumbnail()) : ?>
                                            <div class="tp-blog-two-thumb overlay-anim tp-thumb-common fix">
                                            <div class="tp-thumb-common-overlay wow"></div>
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_post_thumbnail(); ?>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    <div class="tp-blog-two-content">
                                       <span><?php the_time( get_option('date_format') ); ?> _ <?php echo esc_html($categories[0]->name); ?></span>
                                       <h4 class="tp-blog-two-title">
                                             <a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a>
                                       </h4>
                                       <?php if(!empty($settings['tp_post_button'])) : ?>
                                       <div class="tp-blog-two-btn">
                                       <a href="<?php the_permalink(); ?>"><?php echo tp_kses($settings['tp_post_button']); ?></a>
                                       </div>
                                       <?php endif; ?>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php endwhile; wp_reset_query(); endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
    </div>
</section>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) :
      $this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
    ?>
<!-- blog-area-start -->
<section class="blog-area pb-40 tp-el-section">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="tp-blog-3-wrapper">
            <div class="tp-section tp-section-two text-center mb-50">
            <?php if ( !empty($settings['tp_blog_sub_title']) ) : ?>
                <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_blog_sub_title']); ?></span>
            <?php endif; ?>
            <?php
            if ( !empty($settings['tp_blog_title' ]) ) :
                printf( '<%1$s %2$s>%3$s</%1$s>',
                tag_escape( $settings['tp_blog_title_tag'] ),
                $this->get_render_attribute_string( 'title_args' ),
                tp_kses( $settings['tp_blog_title' ] )
                );
            endif;
            ?>
            </div>
            </div>
        </div>
    </div>
    <div class="row">
    <?php 
        if ($query->have_posts()) : 
        $i = 0;
        while ($query->have_posts()) : 
        $query->the_post();
        global $post;
        $categories = get_the_category($post->ID);
        $i++;
    ?>
        <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?>">
            <div class="tp-blog-two mb-40">
            <div class="tp-blog-two-item">
                <?php if(has_post_thumbnail()) : ?>
                <div class="tp-blog-two-thumb overlay-anim tp-thumb-common fix">
                    <div class="tp-thumb-common-overlay wow"></div>
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail(); ?>
                            <div class="tp-blog-two-thumb-plus">
                                <i class="fa-regular fa-plus"></i>
                            </div>
                        </a>
                </div>
                <?php endif; ?>
                <div class="tp-blog-two-content">
                <span><?php the_time( get_option('date_format') ); ?> _ <?php echo esc_html($categories[0]->name); ?></span>
                    <h4 class="tp-blog-two-title">
                        <a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a>
                    </h4>
                    <?php if(!empty($settings['tp_post_button'])) : ?>
                    <div class="tp-blog-two-btn">
                    <a href="<?php the_permalink(); ?>"><?php echo tp_kses($settings['tp_post_button']); ?></a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            </div>
        </div>
        <?php endwhile; wp_reset_query(); endif; ?>
    </div>
</div>
</section>


<?php elseif ( $settings['tp_design_style']  == 'layout-4' ) : 

    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
?>
<!-- blog-area-start -->
<section class="blog-area pb-75 tp-el-section">
    <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="tp-section tp-section-red text-center mb-50">
        <?php if ( !empty($settings['tp_blog_sub_title']) ) : ?>
            <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_blog_sub_title']); ?></span>
        <?php endif; ?>
        <?php
        if ( !empty($settings['tp_blog_title' ]) ) :
            printf( '<%1$s %2$s>%3$s</%1$s>',
            tag_escape( $settings['tp_blog_title_tag'] ),
            $this->get_render_attribute_string( 'title_args' ),
            tp_kses( $settings['tp_blog_title' ] )
            );
        endif;
        ?>
            </div>
        </div>
    </div>
    <div class="row">
    <?php 
        if ($query->have_posts()) : 
        $i = 0;
        while ($query->have_posts()) : 
        $query->the_post();
        global $post;
        $categories = get_the_category($post->ID);
        $i++;
        ?>
        <div class="col-lg-4 col-md-6">
            <div class="tp-blog-4-item mb-40 fix">
                <?php if(has_post_thumbnail()) : ?>
                    <div class="tp-blog-4-thumb tp-thumb-common overlay-anim">
                    <div class="tp-thumb-common-overlay-red wow"></div>
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail(); ?>
                        <div class="tp-blog-4-thumb-plus">
                            <i class="fa-regular fa-plus"></i>
                        </div>
                    </a>
                    </div>
                <?php endif; ?>
                <div class="tp-blog-4-content">
                <h4 class="tp-blog-4-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></h4>
                <?php if (!empty($settings['tp_post_content'])):
                    $tp_post_content_limit = (!empty($settings['tp_post_content_limit'])) ? $settings['tp_post_content_limit'] : '';
                ?>
                <p class="tp-el-box-desc"><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $tp_post_content_limit, ''); ?></p>
                <?php endif; ?>
                    <?php if(!empty($settings['tp_post_button'])) : ?>
                <div class="tp-blog-4-btn">
                    <a href="<?php the_permalink(); ?>"><?php echo tp_kses($settings['tp_post_button']); ?> <i class="fa-sharp fa-regular fa-arrow-right"></i></a>
                </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endwhile; wp_reset_query(); endif; ?>
    </div>
    </div>
</section>
<!-- blog-area-end -->

 
<?php elseif ( $settings['tp_design_style']  == 'layout-5' ) :
       $this->add_render_attribute('title_args', 'class', 'tp-section-title');    
?>

      <!-- blog-area-start -->
<section class="blog-area tp-blog-5 pb-90 pt-120 tp-el-section">
<div class="tp-blog-5-bg" style="background-image:url('<?php echo get_template_directory_uri(); ?>/assets/img/blog/five/blog-5-bg-1.jpg')"> </div>
<div class="container">
<div class="row">
    <div class="tp-section tp-section-red text-center mb-35">
        <?php if ( !empty($settings['tp_blog_sub_title']) ) : ?>
            <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_blog_sub_title']); ?></span>
        <?php endif; ?>
        <?php
        if ( !empty($settings['tp_blog_title' ]) ) :
            printf( '<%1$s %2$s>%3$s</%1$s>',
            tag_escape( $settings['tp_blog_title_tag'] ),
            $this->get_render_attribute_string( 'title_args' ),
            tp_kses( $settings['tp_blog_title' ] )
            );
        endif;
        ?>
    </div>
</div>
<div class="row">
    <?php 
        if ($query->have_posts()) : 
        $i = 0;
        while ($query->have_posts()) : 
        $query->the_post();
        global $post;
        $categories = get_the_category($post->ID);
        $i++;
    ?>
    <div class="col-lg-4 col-md-6">
        <div class="tp-blog-5-item mb-30 tp-thumb-common fix">
            <?php if(has_post_thumbnail()) : ?>
                <div class="tp-thumb-common-overlay-red wow"></div>
                    <div class="tp-blog-5-thumb">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail(); ?>
                        </a>
                    </div>
            <?php endif; ?>
            <div class="tp-blog-5-content">
            <div class="tp-blog-5-content-post d-flex align-items-center">
                <div class="tp-blog-5-content-post-icon">
                    <i class="flaticon-manufacturing"></i>
                </div>
                <div class="tp-blog-5-content-post-content">
                    <p><?php echo tp_kses('Posted by', 'tp-core');?></p>
                    <span><?php print get_the_author();?></span>
                </div>
            </div>
            <div class="tp-blog-5-content-main">
                <div class="tp-blog-5-content-info d-flex align-items-center mb-20">
                    <div class="tp-blog-5-content-info-item mr-35">
                        <span><i class="flaticon-user"></i> <?php print get_the_author();?></span>
                    </div>
                    <div class="tp-blog-5-content-info-item">
                        <span><i class="fa-light fa-message"></i> <?php comments_number();?></span>
                    </div>
                </div>
                <h5 class="tp-blog-5-title mb-30"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></h5>
                <div class="tp-blog-5-tags">
                    <?php if(!empty($categories[0]->name)) : ?>
                    <a href="<?php the_permalink(); ?>"><?php echo esc_html($categories[0]->name); ?></a>
                    <?php endif; ?>
                    <?php if(!empty($categories[1]->name)) : ?>
                    <a href="<?php the_permalink(); ?>"><?php echo esc_html($categories[1]->name); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            </div>
        </div>
    </div>
    <?php endwhile; wp_reset_query(); endif; ?>
</div>
</div>
</section>
      <!-- blog-area-end -->
<?php else : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title');
    ?>    
      <!-- blog-area-start -->
      <section class="blog-area pb-90 pt-110 tp-el-section">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="tp-section text-center mb-60">
                        <?php if ( !empty($settings['tp_blog_sub_title']) ) : ?>
                            <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_blog_sub_title']); ?></span><br/>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['tp_blog_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_blog_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_blog_title' ] )
                            );
                        endif;
                        ?>
                  </div>
               </div>
            </div>
            <div class="tp-blog-wrapper">
               <div class="row gx-0">
               <?php 
             	 if ($query->have_posts()) : 
                    $i = 0;
                    while ($query->have_posts()) : 
                    $query->the_post();
                    global $post;
                    $categories = get_the_category($post->ID);
                    $i++;
                ?>
                <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?>">
                     <div class="tp-blog-item text-center">
                     <?php if(has_post_thumbnail()) : ?>
                        <div class="tp-blog-item-thumb tp-thumb-common fix overlay-anim mb-20">
                           <div class="tp-thumb-common-overlay wow"></div>
                           <a href="<?php the_permalink(); ?>">
                                 <?php the_post_thumbnail(); ?>
                            </a>
                            <div class="tp-blog-item-date">
                                <h4><?php echo the_time("j")?></h4>
                                <p><?php echo  the_time("F")?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="tp-blog-item-content">
                           <div class="tp-blog-item-tag mb-20">
                             <?php if(!empty($categories[0]->name)) : ?>
                              <a href="<?php the_permalink(); ?>"><?php echo esc_html($categories[0]->name); ?></a>
                              <?php endif; ?>
                              <?php if(!empty($categories[1]->name)) : ?>
                              <a href="<?php the_permalink(); ?>"><?php echo esc_html($categories[1]->name); ?></a>
                              <?php endif; ?>
                           </div>
                           <h4 class="tp-blog-item-title mb-30">
                           <a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a>
                           </h4>
                           <?php if(!empty($settings['tp_post_button'])) : ?>
                           <div class="tp-blog-item-btn">
                                <a href="<?php the_permalink(); ?>"><?php echo tp_kses($settings['tp_post_button']); ?></a>
                           </div>
                           <?php endif; ?>
                        </div>
                     </div>
                  </div>
                  <?php endwhile; wp_reset_query(); endif; ?>
               </div>
            </div>
         </div>
      </section>
      <!-- blog-area-end -->
<?php endif;  
	}

}

$widgets_manager->register( new TP_Blog_Post() );