<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Hero_Three extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-hero-three';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero Three', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    }


    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
       
        $repeater = new Repeater();

        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__( 'Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );

         $repeater->add_control(
            'list_sub_title',
            [
                'label' => esc_html__( 'Sub Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Sub Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );

         $repeater->add_control(
            'list_img_pattern',
            [
                'label' => esc_html__( 'Image Shape', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        ); 

         $repeater->add_control(
            'list_img_bg',
            [
                'label' => esc_html__( 'BG Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'list_img_author1',
            [
                'label' => esc_html__( 'Author Image 01', 'tpcore' ),
                'type' => Controls_Manager::MEDIA, 
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'list_img_author2',
            [
                'label' => esc_html__( 'Author Image 02', 'tpcore' ),
                'type' => Controls_Manager::MEDIA, 
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        ); 

        $repeater->add_control(
            'list_img_author3',
            [
                'label' => esc_html__( 'Author Image 03', 'tpcore' ),
                'type' => Controls_Manager::MEDIA, 
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        ); 
        

         $repeater->add_control(
            'list_author_title',
            [
                'label' => esc_html__( 'Author Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        ); 

         $repeater->add_control(
            'list_author_rating',
            [
                'label' => esc_html__( 'Author Rating', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        ); 

       $repeater->add_control(
			'list_btn_txt',
			[
				'label' => esc_html__( 'Button Text', 'tpcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Find Out More', 'tpcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'tpcore' ),
			]
		);

       $repeater->add_control(
			'list_btn_link',
			[
				'label' => esc_html__( 'Link', 'tpcore' ),
				'type' => Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'label_block' => true,
			]
		);

  


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_sub_title' => esc_html__( 'Sub Title #1.', 'tpcore' ),
                        
                    ],
                    [
                        'list_title' => esc_html__( 'Title #2', 'tpcore' ),
                        'list_sub_title' => esc_html__( 'Sub Title #2', 'tpcore' ),
                    ], 
                    [
                        'list_title' => esc_html__( 'Title #3', 'tpcore' ),
                        'list_sub_title' => esc_html__( 'Sub Title #3', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-block_two-heading a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .service-block_two-heading a',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-block_two-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .service-block_two-text p',
            ]
        );


        $this->end_controls_section();


        

    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $list_img_pattern = $settings['list_img_author']['url'];

     ?>

    <section class="slider-three">
        <div class="slider-three_pattern" style="background-image:url(<?php echo $list_img_pattern; ?>)"></div>
        <div class="main-slider_three-carousel swiper-container">
            <div class="swiper-wrapper">
                <?php foreach (  $settings['list'] as $key => $item ) : ?>
                <!-- Slide -->
                <div class="swiper-slide">
                    <div class="slider-three_image" style="background-image:url(<?php echo esc_url($item['list_img_bg']['url']); ?>)"></div>
                    <div class="auto-container">
                        <!-- Content Column -->
                        <div class="slider-three_content">
                            <div class="slider-three_content-inner">
                                <div class="slider-three_title"><?php echo $item['list_sub_title']; ?></div>
                                <h1 class="slider-three_heading"><?php echo $item['list_title']; ?></h1>
                                <div class="slider-three_button">
                                    <a href="<?php echo esc_url($item['list_btn_link']['url']); ?>" class="theme-btn btn-style-one">
                                        <span class="btn-wrap">
                                            <span class="text-one"><?php echo $item['list_btn_txt']; ?> <i class="fa-solid fa-angle-right fa-fw"></i></span>
                                            <span class="text-two"><?php echo $item['list_btn_txt']; ?> <i class="fa-solid fa-angle-right fa-fw"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Reviews -->
                        <div class="slider-three_reviews d-flex align-items-center flex-wrap">
                            <div class="slider-three_arrow" style="background-image:url(<?php echo esc_url($item['list_img_pattern']['url']); ?>)"></div>
                            <div class="slider-three_authors">
                                <span><img src="<?php echo $item['list_img_author1']['url']; ?>" alt="shape-1" /></span>
                                <span><img src="<?php echo $item['list_img_author2']['url']; ?>" alt="shape-2" /></span>
                                <span><img src="<?php echo $item['list_img_author3']['url']; ?>" alt="shape-3" /></span>
                            </div>
                            <div class="slider-three_total-rating">
                                <?php echo $item['list_author_title']; ?>
                                <span><i class="fa fa-star"></i><?php echo $item['list_author_rating']; ?></span>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach ; ?>
            </div>
            <!-- Slider Three Arrows -->
            <div class="slider-three-arrow">
                <!-- If we need navigation buttons -->
                <div class="slider_three-carousel-prev fas fa-arrow-left fa-fw"></div>
                <div class="slider_three-carousel-next fas fa-arrow-right fa-fw"></div>
            </div>
            <div class="slider_three-carousel-pagination"></div>
            <!-- Scroll Down -->
            <div class="slider-three_scroll-down scroll-to-target" data-target=".services-four">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/scroll-down.png" alt="scroll-down" />
            </div>
        </div>
    </section>


     <?php
    }
}

$widgets_manager->register( new TP_Hero_Three() );



