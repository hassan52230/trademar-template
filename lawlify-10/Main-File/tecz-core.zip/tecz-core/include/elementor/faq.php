<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_FAQ extends Widget_Base {

	use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'FAQ', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    public function get_tp_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $tp_cfa         = array();
        $tp_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $tp_forms       = get_posts( $tp_cf_args );
        $tp_cfa         = ['0' => esc_html__( 'Select Form', 'tpcore' ) ];
        if( $tp_forms ){
            foreach ( $tp_forms as $tp_form ){
                $tp_cfa[$tp_form->ID] = $tp_form->post_title;
            }
        }else{
            $tp_cfa[ esc_html__( 'No contact form found', 'tpcore' ) ] = 0;
        }
        return $tp_cfa;
    }


	protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [ 
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->end_controls_section();
	
		// title/content
		$this->tp_section_title_render_controls('faq', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2',]);

		$this->start_controls_section(
            '_accordion',
            [
                'label' => esc_html__( 'Accordion', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'accordion_main_title', [
                'label' => esc_html__( 'Accordion Title', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'This is accordion title' , 'tpcore' ),
                'label_block' => true,
				'condition' => [
                    'tp_design_style' => ['layout-3','layout-4']
                ]
            ]
        );
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'tp_accordion_active_switch',
            [
                'label' => esc_html__( 'Show', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => '0',
            ]
        );

        $repeater->add_control(
            'accordion_title', [
                'label' => esc_html__( 'Accordion Item', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'This is accordion item title' , 'tpcore' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'accordion_description',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Facilis fugiat hic ipsam iusto laudantium libero maiores minima molestiae mollitia repellat rerum sunt ullam voluptates? Perferendis, suscipit.',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'accordions',
            [
                'label' => esc_html__( 'Repeater Accordion', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #1', 'tpcore' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #2', 'tpcore' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #3', 'tpcore' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #4', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ accordion_title }}}',
            ]
        );

        $this->end_controls_section();
		if ( class_exists( 'WPCF7' ) ) {
            $this->start_controls_section(
                'tpcore_contact',
                [
                    'label' => esc_html__('Contact Form', 'tpcore'),
					'condition' => [
						'tp_design_style' => ['layout-1','layout-2']
					]
                ]
            );

            $this->add_control(
                'tpcore_select_contact_form',
                [
                    'label'   => esc_html__( 'Select Form', 'tpcore' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => '0',
                    'options' => $this->get_tp_contact_form(),
                ]
            );

            $this->end_controls_section();
        }

        $this->start_controls_section(
            'tp_contact_form',
            [
                'label' => esc_html__('Form Contact ', 'tpcore'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-1',]
                ]
            ]
        );
		$this->add_control(
			'tp_contact_sub_title',
			[
				'label'       => esc_html__( 'Contact Form Sub Title', 'tpcore' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Contact With Us', 'tpcore' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tp_contact_title',
			[
				'label'       => esc_html__( 'Contact Form Title', 'tpcore' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Drop Us a Line', 'tpcore' ),
				'label_block' => true,
			]
		);
        $this->end_controls_section();

	  // _tp_image
	  $this->start_controls_section(
		'_tp_image',
		[
			'label' => esc_html__('Thumbnail', 'tp-core'),
			'condition' => [
				'tp_design_style' => ['layout-2',]
			]
		]
	);

	$this->add_control(
		'tp_image',
		[
			'label' => esc_html__( 'Choose Image', 'tp-core' ),
			'type' => \Elementor\Controls_Manager::MEDIA,
			'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			],
		]
	);

	$this->add_group_control(
		Group_Control_Image_Size::get_type(),
		[
			'name' => 'tp_image_size',
			'default' => 'full',
			'exclude' => [
				'custom'
			]
		]
	);
	$this->end_controls_section();


       // _tp_bottom info
	   $this->start_controls_section(
		'_tp_image_bottom_info',
		[
			'label' => esc_html__('Bottom Info', 'tp-core'),
			'condition' => [
				'tp_design_style' => ['layout-2',]
			]
		]
	);


	$this->add_control(
		'repeater_condition_contat',
		[
			'label' => __( 'Field condition', 'tpcore' ),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'style_1' => __( 'Style 1', 'tpcore' ),
			],
			'default' => 'style_1',
			'frontend_available' => true,
			'style_transfer' => true,
		]
	);

	$this->add_control(
		'tp_box_icon_type_contat',
		[
			'label' => esc_html__('Select Icon Type', 'tpcore'),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'icon',
			'options' => [
				'image' => esc_html__('Image', 'tpcore'),
				'icon' => esc_html__('Icon', 'tpcore'),
				'svg' => esc_html__('SVG', 'tpcore'),
			],
		
		]
	);

	$this->add_control(
		'tp_box_icon_svg_contat',
		[
			'show_label' => false,
			'type' => Controls_Manager::TEXTAREA,
			'label_block' => true,
			'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
			'condition' => [
				'tp_box_icon_type_contat' => 'svg',
			]
		]
	);

	$this->add_control(
		'tp_box_icon_image_contat',
		[
			'label' => esc_html__('Upload Icon Image', 'tpcore'),
			'type' => Controls_Manager::MEDIA,
			'default' => [
				'url' => Utils::get_placeholder_image_src(),
			],
			'condition' => [
				'tp_box_icon_type_contat' => 'image',
			]
		]
	);

	if (tp_is_elementor_version('<', '2.6.0')) {
		$this->add_control(
			'tp_box_icon_contat',
			[
				'show_label' => false,
				'type' => Controls_Manager::ICON,
				'label_block' => true,
				'default' => 'fa fa-star',
				'condition' => [
					'tp_box_icon_type_contat' => 'icon',
				]
			]
		);
	} else {
		$this->add_control(
			'tp_box_selected_icon_contat',
			[
				'show_label' => false,
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block' => true,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => [
					'tp_box_icon_type_contat' => 'icon',
				]
			]
		);
	}

	$this->add_control(
		'tp_service_title_contat', [
			'label' => esc_html__('Sub Title', 'tpcore'),
			'description' => tp_get_allowed_html_desc( 'basic' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'About Service Title', 'tpcore'),
			'label_block' => true,
		]
	);

	$this->add_control(
		'tp_services_page_link_contat',
		[
			'label' => esc_html__( 'Select Service Link Page', 'tpcore' ),
			'type' => \Elementor\Controls_Manager::SELECT2,
			'label_block' => true,
			'options' => tp_get_all_pages(),
			'condition' => [
				'tp_services_link_type_contat' => '2',
				'tp_services_link_switcher' => 'yes',
			]
		]
	);
	
	$this->add_control(
		'tp_image_2',
		[
			'label' => esc_html__( 'Choose Image 2', 'tp-core' ),
			'type' => \Elementor\Controls_Manager::MEDIA,
			'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			],
		]
	);
	$this->add_group_control(
		Group_Control_Image_Size::get_type(),
		[
			'name' => 'tp_image_size_2',
			'default' => 'full',
			'exclude' => [
				'custom'
			]
		]
	);
	
	$this->end_controls_section();

	}

	protected function style_tab_content(){
		$this->tp_section_style_controls('faq_section', 'Section - Style', '.tp-el-section');
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>


<?php if ( $settings['tp_design_style']  == 'layout-2' ):
	// thumbnail
	if ( !empty($settings['tp_image']['url']) ) {
		$tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_2_size']) : $settings['tp_image']['url'];
		$tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
	}
	// thumbnail
	if ( !empty($settings['tp_image_2']['url']) ) {
		$tp_image_2 = !empty($settings['tp_image_2']['id']) ? wp_get_attachment_image_url( $settings['tp_image_2']['id'], $settings['tp_image_size_2_size']) : $settings['tp_image_2']['url'];
		$tp_image_alt = get_post_meta($settings["tp_image_2"]["id"], "_wp_attachment_image_alt", true);
	}


	$this->add_render_attribute('title_args', 'class', 'tp-section-title');
?>

      <!-- faq-area-start -->
      <section class="faq-area tp-faq-5 pt-110 pb-90">
         <div class="container">
            <div class="row">
               <div class="col-lg-6"></div>
               <div class="col-lg-6">
                  <div class="tp-faq tp-faq-red ml-70 wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".8s">
                     <div class="tp-section tp-section-red mb-55">
						<?php if ( !empty($settings['tp_faq_sub_title']) ) : ?>
                       		 <span  class="tp-section-sub-title"><?php echo tp_kses($settings['tp_faq_sub_title']); ?></span>
						<?php endif; ?>
					    <?php
                        if ( !empty($settings['tp_faq_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_faq_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_faq_title' ] )
                            );
                        endif;
                        ?>
                     </div>
                     <div class="tp-faq-accordion">
                        <div class="accordion" id="accordionExample-<?php echo esc_attr($this->get_id()); ?>">
						<?php foreach ( $settings['accordions'] as $index => $item) :
								$collapsed = ($index == '0' ) ? '' : 'collapsed';
								$aria_expanded = ($index == '0' ) ? "true" : "false";
								$show = $item['tp_accordion_active_switch'] ? "show" : "";
							?>
                           <div class="accordion-item">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne-<?php echo esc_attr($index); ?>" aria-expanded="<?php echo esc_attr($aria_expanded); ?>" aria-controls="collapseOne-<?php echo esc_attr($index); ?>">
                                    <?php echo esc_html($item['accordion_title']); ?>
                                    <span class="accordion-btn"></span>
                                 </button>
                              </h2>
                              <div id="collapseOne-<?php echo esc_attr($index); ?>" class="accordion-collapse collapse <?php echo esc_attr($show); ?>"
                                 data-bs-parent="#accordionExample-<?php echo esc_attr($this->get_id()); ?>">
                                 <div class="accordion-body">
								 	<p><?php echo tp_kses($item['accordion_description']); ?></p>
                                 </div>
                              </div>
                           </div>
						   <?php endforeach; ?>
                        
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="tp-faq-5-bg"  style="background-image:url('<?php echo esc_url($tp_image); ?>')"></div>
         <div class="tp-faq-5-bg-2" style="background-image:url('<?php echo esc_url($tp_image_2); ?>')">
            <div class="tp-faq-5-content">
			<?php if (!empty($settings['tp_service_title_contat'])): ?>
               <h5 class="tp-faq-5-title"><?php echo tp_kses($settings['tp_service_title_contat']);?></h5>
			<?php endif; ?>
               <div class="tp-faq-5-icon">
			  		 <?php if($settings['tp_box_icon_type_contat'] == 'icon') : ?>
                        <?php if (!empty($settings['tp_box_icon_contat']) || !empty($settings['tp_box_selected_icon_contat']['value'])) : ?>
                        <span><?php tp_render_icon($settings, 'tp_box_icon_contat', 'tp_box_selected_icon_contat'); ?></span>
                        <?php endif; ?>
                    <?php elseif( $settings['tp_box_icon_type_contat'] == 'image' ) : ?>
                        <?php if (!empty($settings['tp_box_icon_image_contat']['url'])): ?>
                        <span><img src="<?php echo $settings['tp_box_icon_image_contat']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($settings['tp_box_icon_image_contat']['url']), '_wp_attachment_image_alt', true); ?>"></span>
                        <?php endif; ?>
                    <?php else : ?>
                        <?php if (!empty($settings['tp_box_icon_svg_contat'])): ?>
                        <span><?php echo $settings['tp_box_icon_svg_contat']; ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
               </div>
            </div>
         </div>
      </section>
      <!-- faq-area-end -->
	  
<?php elseif ( $settings['tp_design_style']  == 'layout-3' ):


	$this->add_render_attribute('title_args', 'class', 'tp-section-title');
?>
   <div class="tp-faq tp-faq-inner-2-wrap mb-60 ml-70 wow fadeInLeft" data-wow-duration="1s"
                     data-wow-delay=".4s">
		<div class="tp-faq-content">
		<?php if ( !empty($settings['accordion_main_title']) ) : ?>
			<h4 class="tp-faq-content-title"><?php echo tp_kses($settings['accordion_main_title']);?></h4>
		<?php endif; ?>
		</div>
		<div class="tp-faq-accordion">
		<div class="accordion" id="accordionExample-<?php echo esc_attr($this->get_id()); ?>">
		<?php foreach ( $settings['accordions'] as $index => $item) :
			$collapsed = ($index == '0' ) ? '' : 'collapsed';
			$aria_expanded = ($index == '0' ) ? "true" : "false";
			$show = $item['tp_accordion_active_switch'] ? "show" : "";
		?>
			<div class="accordion-item">
				<h2 class="accordion-header">
					<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
					data-bs-target="#collapseTwo-<?php echo esc_attr($index); ?>" aria-expanded="false" aria-controls="collapseTwo-<?php echo esc_attr($index); ?>"><?php echo esc_html($item['accordion_title']); ?>
					<span class="accordion-btn"></span>
					</button>
				</h2>
				<div id="collapseTwo-<?php echo esc_attr($index); ?>" class="accordion-collapse collapse <?php echo esc_attr($show); ?>"
					data-bs-parent="#accordionExample-<?php echo esc_attr($this->get_id()); ?>">
					<div class="accordion-body">
					<p><?php echo tp_kses($item['accordion_description']); ?></p>
					</div>
				</div>
			</div>
		<?php endforeach; ?>
		</div>
		</div>
	</div>


	  
<?php elseif ( $settings['tp_design_style']  == 'layout-4' ):


	$this->add_render_attribute('title_args', 'class', 'tp-section-title');
?>
<div class="tp-faq tp-faq-inner-2-wrap ml-70 wow fadeInLeft" data-wow-duration="1s"
                     data-wow-delay=".4s">
	<div class="tp-faq-content">
	<?php if ( !empty($settings['accordion_main_title']) ) : ?>
		<h4 class="tp-faq-content-title"><?php echo tp_kses($settings['accordion_main_title']);?></h4>
	<?php endif; ?>
	</div>
		<div class="tp-faq-accordion">
			<div class="accordion" id="accordionExample2-<?php echo esc_attr($this->get_id()); ?>">
				<?php foreach ( $settings['accordions'] as $index => $item) :
					$collapsed = ($index == '0' ) ? '' : 'collapsed';
					$aria_expanded = ($index == '0' ) ? "true" : "false";
					$show = $item['tp_accordion_active_switch'] ? "show" : "";
				?>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
							data-bs-target="#collapseSix-<?php echo esc_attr($index); ?>" aria-expanded="false" aria-controls="collapseSix-<?php echo esc_attr($index); ?>"><?php echo esc_html($item['accordion_title']); ?>
							<span class="accordion-btn"></span>
							</button>
						</h2>
						<div id="collapseSix-<?php echo esc_attr($index); ?>" class="accordion-collapse collapse <?php echo esc_attr($show); ?>"
							data-bs-parent="#accordionExample2-<?php echo esc_attr($this->get_id()); ?>">
							<div class="accordion-body">
								<p><?php echo tp_kses($item['accordion_description']); ?></p>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
		</div>
	</div>
</div>



<?php else : 
    $this->add_render_attribute('title_args', 'class', 'tp-faq-content-title');
?>
      <!-- form-area-start -->
      <section class="form-area tp-faq-wrapper pb-55">
         <div class="tp-faq-bg" style="background-image:url('<?php echo get_template_directory_uri(  ); ?>/assets/img/shape/faq-2-shape-1.jpg')"></div>
         <div class="container"> 
            <div class="row">
               <div class="col-lg-6">
                  <div class="tp-form-wrapper mb-60 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".4s">
                     <div class="tp-form-content">
					 <?php if ( !empty($settings['tp_contact_sub_title']) ) : ?>
                        <span><?php echo tp_kses($settings['tp_contact_sub_title']);?></span>
					<?php endif; ?>
					<?php if ( !empty($settings['tp_contact_title']) ) : ?>
                        <h4 class="tp-form-title"><?php echo tp_kses($settings['tp_contact_title']);?></h4>
					<?php endif; ?>
                     </div>
                     <div class="tp-form-wrap">
					 <?php if( !empty($settings['tpcore_select_contact_form']) ) : ?>
						<?php echo do_shortcode( '[contact-form-7  id="'.$settings['tpcore_select_contact_form'].'"]' ); ?>
						<?php else : ?>
						<?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'tpcore' ). '</p></div>'; ?>
					<?php endif; ?>	
                     </div>
                     <div class="tp-form-shape">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/shape/contact-2-shape-1.png" alt="">
                     </div>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="tp-faq ml-70 wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".4s">
                     <div class="tp-faq-content">
					<?php if ( !empty($settings['tp_faq_sub_title']) ) : ?>
                        <span><?php echo tp_kses($settings['tp_faq_sub_title']); ?></span>
					<?php endif; ?>
					    <?php
                        if ( !empty($settings['tp_faq_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_faq_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_faq_title' ] )
                            );
                        endif;
                        ?>
                     </div>
                     <div class="tp-faq-accordion">
                        <div class="accordion" id="accordionExample-<?php echo esc_attr($this->get_id()); ?>">
							<?php foreach ( $settings['accordions'] as $index => $item) :
								$collapsed = ($index == '0' ) ? '' : 'collapsed';
								$aria_expanded = ($index == '0' ) ? "true" : "false";
								$show = $item['tp_accordion_active_switch'] ? "show" : "";
							?>
                           <div class="accordion-item">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne-<?php echo esc_attr($index); ?>" aria-expanded="<?php echo esc_attr($aria_expanded); ?>" aria-controls="collapseOne-<?php echo esc_attr($index); ?>">
                                    <?php echo esc_html($item['accordion_title']); ?>
                                    <span class="accordion-btn"></span>
                                 </button>
                              </h2>
                              <div id="collapseOne-<?php echo esc_attr($index); ?>" class="accordion-collapse collapse <?php echo esc_attr($show); ?>"
                                 data-bs-parent="#accordionExample-<?php echo esc_attr($this->get_id()); ?>">
                                 <div class="accordion-body">
								 	<p><?php echo tp_kses($item['accordion_description']); ?></p>
                                 </div>
                              </div>
                           </div>
						   <?php endforeach; ?>
                        </div>
                     </div>
                  </div>
               </div> 
            </div>
         </div>
      </section>
      <!-- form-area-end -->

<?php endif;
	}

}

$widgets_manager->register( new TP_FAQ() );