<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Team_Member extends Widget_Base {

	use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
    	return 'tp-team-member';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
    	return __( 'Team Member', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
    	return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
    	return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
    	return [ 'tpcore'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {


       $this->start_controls_section(
            'layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

    	$this->start_controls_section(
    		'content_section',
    		[
    			'label' => esc_html__( 'Content', 'tpcore' ),
    			'tab' => Controls_Manager::TAB_CONTENT,
    		]
    	);


    	$repeater = new Repeater();

    	$repeater->add_control(
    		'list_image',
    		[
    			'label' => esc_html__( 'Choose Image', 'tpcore' ),
    			'type' => Controls_Manager::MEDIA,
    			'default' => [
    				'url' => Utils::get_placeholder_image_src(),
    			],
    		]
    	);

    	$repeater->add_control(
    		'list_name',
    		[
    			'label' => esc_html__( 'Name', 'tpcore' ),
    			'type' => Controls_Manager::TEXT,
    			'default' => esc_html__( 'Marget M. Hason' , 'tpcore' ),
    			'label_block' => true,
    		]
    	);
    	$repeater->add_control(
    		'list_designation',
    		[
    			'label' => esc_html__( 'Designation', 'tpcore' ),
    			'type' => Controls_Manager::TEXT,
    			'default' => esc_html__( 'Patent Lawyer' , 'tpcore' ),
    			'label_block' => true,
    		]
    	);

    	 $repeater->add_control(
			'list_link',
			[
				'label' => esc_html__( 'Link', 'tpcore' ),
				'type' => Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'label_block' => true,
			]
		);



    	$this->add_control(
    		'list',
    		[
    			'label' => esc_html__( 'Repeater List', 'tpcore' ),
    			'type' => Controls_Manager::REPEATER,
    			'fields' => $repeater->get_controls(),
    			'default' => [
    				[
    					'list_name' => esc_html__( 'Marget M. Hason', 'textdomain' ),
    					'list_designation' => esc_html__( 'Patent Lawyer', 'tpcore' ),

    				],
    				[
    					'list_name' => esc_html__( 'Marget M. Hason', 'textdomain' ),
    					'list_designation' => esc_html__( 'Patent Lawyer', 'tpcore' ),
    				], 
    				[
    					'list_name' => esc_html__( 'Marget M. Hason', 'textdomain' ),
    					'list_designation' => esc_html__( 'Patent Lawyer', 'tpcore' ),
    				],
    			],
    			'title_field' => '{{{ list_name }}}',
    		]
    	);

    	$this->end_controls_section();



    	$this->start_controls_section(
    		'style_section',
    		[
    			'label' => esc_html__( 'Style', 'tpcore' ),
    			'tab' => Controls_Manager::TAB_STYLE,
    		]
    	);

    	$this->add_control(
    		'name_color',
    		[
    			'label' => esc_html__( 'Name Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .team-block_one-heading a' => 'color: {{VALUE}}',
               '{{WRAPPER}} .team-block_two-heading a' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'name_typography',
    			'selector' => '{{WRAPPER}} .team-block_one-heading a',
            'selector' => '{{WRAPPER}} .team-block_two-heading a',
    		]
    	);

    	$this->add_control(
    		'designation_color',
    		[
    			'label' => esc_html__( 'Designation Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .team-block_one-designation' => 'color: {{VALUE}}',
               '{{WRAPPER}} .team-block_two-designation' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'designation_typography',
    			'selector' => '{{WRAPPER}} .team-block_one-designation',
            'selector' => '{{WRAPPER}} .team-block_two-designation',
    		]
    	);

    	$this->end_controls_section();




    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
    	$settings = $this->get_settings_for_display();
    	?>


  <?php if ($settings['design_style'] == 'layout-1') { ?> 
	<section class="team-one">
		<div class="auto-container">
			<div class="team-one_carousel swiper-container">
				<div class="swiper-wrapper">
					<?php foreach (  $settings['list'] as $item ) : ?>
					<!-- Slide -->
					<div class="swiper-slide">
						<!-- Team Block One -->
						<div class="team-block_one">
							<div class="team-block_one-inner">
								<div class="team-block_one-image">
									<a href="#"><img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="" /></a>
								</div>
								<div class="team-block_one-content">
									<h4 class="team-block_one-heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_name']; ?></a></h4>
									<div class="team-block_one-designation"><?php echo $item['list_designation']; ?></div>
									<div class="team-block_one-share_outer">
										<div class="team-block_one-share fa-solid fa-share-nodes fa-fw"></div>
										<!-- Social Box -->
										<ul class="team-block_one-socials">
											<li><a href="#" class="fa-brands fa-facebook-f fa-fw"></a></li>
											<li><a href="#" class="fa-brands fa-twitter fa-fw"></a></li>
											<li><a href="#" class="fa-brands fa fa-dribbble"></a></li>
											<li><a href="#" class="fa-brands fa-linkedin-in fa-fw"></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php endforeach ; ?>
				</div>

				<!-- Team One Arrows -->
				<div class="team-one-arrow">
					<!-- If we need navigation buttons -->
					<div class="team-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
					<div class="team-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
				</div>
				<div class="team-one_carousel-pagination"></div>

			</div>

		</div>
	</section>
<?php } elseif ($settings['design_style'] == 'layout-2') { ?>
   <section class="team-three">
      <div class="auto-container">
         <div class="row clearfix">
            <?php foreach (  $settings['list'] as $item ) : ?>
            <!-- Team Block One -->
            <div class="team-block_one col-lg-4 col-md-6 col-sm-12">
               <div class="team-block_one-inner">
                  <div class="team-block_one-image">
                     <a href="team-detail.html"><img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="" /></a>
                  </div>
                  <div class="team-block_one-content">
                     <h4 class="team-block_one-heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_name']; ?></a></h4>
                     <div class="team-block_one-designation"><?php echo $item['list_designation']; ?></div>
                     <div class="team-block_one-share_outer">
                        <div class="team-block_one-share fa-solid fa-share-nodes fa-fw"></div>
                        <!-- Social Box -->
                        <ul class="team-block_one-socials">
                           <li><a href="https://www.facebook.com/" class="fa-brands fa-facebook-f fa-fw"></a></li>
                           <li><a href="https://www.twitter.com/" class="fa-brands fa-twitter fa-fw"></a></li>
                           <li><a href="https://dribbble.com/" class="fa-brands fa fa-dribbble"></a></li>
                           <li><a href="https://www.linkedin.com/" class="fa-brands fa-linkedin-in fa-fw"></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <?php endforeach ; ?>
         </div>

         <!-- Styled Pagination -->
        <!--  <ul class="styled-pagination text-center">
            <li><a href="#" class="active">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li class="next"><a href="#"><span class="fa-solid fa-angle-right fa-fw"></span></a></li>
         </ul> -->
         <!-- End Styled Pagination -->

      </div>
   </section>
  <?php } else { ?> 
   <section class="team-two">
      <div class="team-two_circle"></div>
      <div class="team-two_circle-two"></div>
      <div class="auto-container">
         <div class="team-one_carousel swiper-container">
            <div class="swiper-wrapper">
            <?php foreach (  $settings['list'] as $item ) : ?>
               <!-- Slide -->
               <div class="swiper-slide">
                  <!-- Team Block Two -->
                  <div class="team-block_two">
                     <div class="team-block_two-inner">
                        <div class="team-block_two-image">
                           <a href="#"><img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="" /></a>
                           <div class="team-block_two-content">
                              <h4 class="team-block_two-heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_name']; ?></a></h4>
                              <div class="team-block_two-designation"><?php echo $item['list_designation']; ?></div>
                              <div class="team-block_two-share_outer">
                                 <div class="team-block_two-share fa-solid fa-share-nodes fa-fw"></div>
                                 <!-- Social Box -->
                                 <ul class="team-block_two-socials">
                                    <li><a href="#" class="fa-brands fa-facebook-f fa-fw"></a></li>
                                    <li><a href="#" class="fa-brands fa-twitter fa-fw"></a></li>
                                    <li><a href="#" class="fa-brands fa fa-dribbble"></a></li>
                                    <li><a href="#" class="fa-brands fa-linkedin-in fa-fw"></a></li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach ; ?>
            </div>

            <!-- Team One Arrows -->
            <div class="team-one-arrow">
               <!-- If we need navigation buttons -->
               <div class="team-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
               <div class="team-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
            </div>
            <div class="team-one_carousel-pagination"></div>

         </div>
      </div>
   </section>
   <?php } ?>


    <?php
    }
}

$widgets_manager->register( new TP_Team_Member() );



