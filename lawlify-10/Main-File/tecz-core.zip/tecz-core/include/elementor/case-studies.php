<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Case_Studies extends Widget_Base {

	use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
    	return 'tp-case-studies';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
    	return __( 'Case Studies', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
    	return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
    	return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
    	return [ 'tpcore'];
    }


    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

      $this->start_controls_section(
         'layout',
         [
           'label' => esc_html__('Design Layout', 'tpcore'),
        ]
     );
      $this->add_control(
         'design_style',
         [
           'label' => esc_html__('Select Layout', 'tpcore'),
           'type' => Controls_Manager::SELECT,
           'options' => [
             'layout-1' => esc_html__('Layout 1', 'tpcore'),
             'layout-2' => esc_html__('Layout 2', 'tpcore'),
          ],
          'default' => 'layout-1',
       ]
    );

      $this->add_control(
         'select_cat',
         [
            'label' => esc_html__( 'Select Category', 'tpcore' ),
            'type' => Controls_Manager::SELECT2,
            'multiple' => false,
            'default' => 'all',
            'options' => $this->getCategories(),
            'label_block' => true,
            'condition' => [
               'design_style' => 'layout-2',
            ],
         ]
      );

      $this->end_controls_section();

      $this->start_controls_section(
         'content_section',
         [
           'label' => esc_html__( 'Settings', 'tpcore' ),
           'tab' => Controls_Manager::TAB_CONTENT,
        ]
     );

      $this->add_control(
         'case_post_order',
         [
           'label' => esc_html__( 'Order', 'tpcore' ),
           'type' => Controls_Manager::SELECT,
           'label_block' => true,
           'default' => 'ASC',
           'options' => [
               'asc' => esc_html__( 'ASC', 'tpcore' ),
               'desc' => esc_html__( 'DESC', 'tpcore' ),
            ],
        ]
     );

     $this->add_control(
         'case_post_no',
         [
           'label' => esc_html__( 'Post Number', 'tpcore' ),
           'type' => Controls_Manager::TEXT,
           'label_block' => true,
        ]
     );

   $this->add_control(
         'case_col_no',
         [
           'label' => esc_html__( 'Column Number', 'tpcore' ),
           'type' => Controls_Manager::TEXT,
           'label_block' => true,
        ]
     );
      

      $this->end_controls_section();



      $this->start_controls_section(
         'style_section',
         [
           'label' => esc_html__( 'Style', 'tpcore' ),
           'tab' => Controls_Manager::TAB_STYLE,
        ]
     );


      $this->add_control(
         'box_height',
         [
            'label' => esc_html__( 'Box Heigh', 'textdomain' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
            'range' => [
               'px' => [
                  'min' => 0,
                  'max' => 1000,
                  'step' => 5,
               ],
               '%' => [
                  'min' => 0,
                  'max' => 100,
               ],
            ],
            'default' => [
               'unit' => '%',
               'size' => 50,
            ],
            'selectors' => [
               '{{WRAPPER}} .case-block_two-image img' => 'height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
               'design_style' => 'layout-2',
            ],
         ]
      );

   
      $this->end_controls_section();




   }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
    	$settings = $this->get_settings_for_display();   
      $count = $settings['case_post_no'];
      $case_col_no = $settings['case_col_no'];
      $ccat = $settings['select_cat'];
      $case_post_order = $settings['case_post_order'];
      ?>


    <?php if ($settings['design_style'] == 'layout-1'): ?> 
         <section class="project-one">
            <div class="outer-container">
               <!-- Porfolio Tabs -->
               <div class="project-tab">
                <?php 
                $args1 = array( 
                   'taxonomy'     => 'cases_cat',
                );
                $cats = get_categories($args1);

                ?>
                <div class="tab-btns-box">
                  <div class="auto-container">
                     <!--Tabs Header-->
                     <div class="tabs-header">
                        <ul class="product-tab-btns clearfix">
                           <?php foreach ( $cats as $key => $cat ) { ?>
                              <li class="p-tab-btn <?php echo $key == 0 ? 'active-btn' : '' ?>" data-tab="#p-tab-<?php echo $key + 1; ?>"><?php echo esc_html( $cat->name ); ?> <span><?php echo esc_html( $cat->count ); ?></span></li>
                           <?php } ?>
                        </ul>
                     </div>
                  </div>
               </div>

               <?php foreach ( $cats as $key => $cat ) { ?>
                  <div class="p-tabs-content">
                     <!-- Portfolio Tab / Active Tab -->
                     <div class="p-tab <?php echo $key == 0 ? 'active-tab' : '' ?>" id="p-tab-<?php echo $key + 1; ?>">
                        <div class="project-one_carousel swiper-container">
                           <div class="swiper-wrapper">
                              <?php 
                              $catname = $cat->name;
                              $args2 = array(
                                 'post_type'=> 'cases',
                                 'orderby'        => 'date',
                                 'order'          => 'DESC',
                                 'category' => $catname,
                              );
                              $query = new WP_Query( $args2 );
                              while ( $query->have_posts() ) : $query->the_post();
                                 $imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
                                 $categories = get_the_terms( get_the_ID(), 'cases_cat' );
                                 ?>
                                 <!-- Slide -->
                                 <div class="swiper-slide">
                                    <!-- Project Block One -->
                                    <div class="project-block_one">
                                       <div class="project-block_one-inner">
                                          <div class="project-block_one-image">
                                             <img src="<?php echo esc_url($imgSrc); ?>" alt="" />
                                             <div class="project-block_one-content">
                                                <h4 class="project-block_one-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
                                                <div class="project-block_one-subtitle"><i class="fa-solid fa-tag fa-fw"></i> <?php echo $categories[0]->name; ?></div>
                                                <a href="<?php echo get_the_permalink(); ?>" class="project-block_one-arrow fa-solid fa-arrow-right-long fa-fw"></a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              <?php endwhile; ?>
                              <?php wp_reset_postdata(); ?>
                           </div>
                        </div>
                     </div>
                  </div>
               <?php } ?>
               
               <!-- Project One Arrows -->
               <div class="project-one-arrow">
                  <!-- If we need navigation buttons -->
                  <div class="project-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                  <div class="project-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
               </div>
               <div class="project-one_carousel-pagination"></div>

            </div>
         </div>
      </section>
    <?php elseif ($settings['design_style'] == 'layout-2'): ?>
   <section class="case-two">
      <div class="auto-container">
         <div class="row clearfix">


            <?php
              

            $args3 = array(
               'post_type'       => 'cases',
               'post_status'    => 'publish',
               'order'           => $case_post_order,
               'posts_per_page'  => $count,
               'tax_query' => array(
                array(
                    'taxonomy'  => 'cases_cat',
                    'field'     => 'slug', 
                    'terms'     => $ccat,
                    'operator'  => 'AND'
                )
            ),
            );

               $query3 = new WP_Query( $args3 );
               while ( $query3->have_posts() ) : $query3->the_post();
                  $imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
                   
                  ?>
            <!-- Project Block One -->
            <div class="case-block_two col-lg-12 col-md-12 col-sm-12">
               <div class="case-block_two-inner">
                  <div class="case-block_two-image">
                     <img src="<?php echo esc_url($imgSrc); ?>" alt="">
                     <div class="case-block_two-content">
                        <h4 class="case-block_two-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
                        <div class="case-block_two-subtitle"><i class="icon-tag_svgrepocom"></i> <?php echo esc_attr($ccat); ?></div>
                        <a href="<?php echo get_the_permalink(); ?>" class="case-block_two-arrow fa-solid fa-arrow-right-long fa-fw"></a>
                     </div>
                  </div>
               </div>
            </div>
      <?php endwhile; ?>
         <?php wp_reset_postdata(); ?>
         </div>

      </div>
   </section>
   <?php else: ?> 
      <section class="case-one">
         <div class="auto-container">
            <div class="row clearfix">
               <?php 
               $args3 = array(
                  'post_type'=> 'cases',
                  'orderby'        => 'date',
                  'order'          => 'DESC',
                  'posts_per_page' => $count,
               );
               $query3 = new WP_Query( $args3 );
               while ( $query3->have_posts() ) : $query3->the_post();
                  $imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
                   $categories = get_the_terms( get_the_ID(), 'cases_cat' );
                   
                  
                  ?>
                  <div class="case-block_one col-lg-<?php echo $case_col_no; ?> col-md-<?php echo $case_col_no; ?> col-sm-12">
                     <div class="case-block_one-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="case-block_one-image">
                           <a href="#"><img src="<?php echo esc_url($imgSrc); ?>" alt="" /></a>
                           <a href="<?php echo get_the_permalink(); ?>" class="case-block_one-arrow fa-solid fa-arrow-right-long fa-fw"></a>
                        </div>
                        <div class="case-block_one-content">
                           <h4 class="case-block_one-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
                           <div class="case-block_one-designation"><i class="icon-tag_svgrepocom"></i> 
                              <?php echo $categories[0]->name; ?></div>
                        </div>
                     </div>
                  </div>
                  <?php endwhile; ?>
                  <?php wp_reset_postdata(); ?>
               </div>
            </div>
         </section>
      <?php endif; ?>

      <?php
   }

   protected function getCategories()
        {
            $args = array(
                'taxonomy'           => 'cases_cat',
                'hide_empty'         => 0,
            );
        
            foreach (get_categories($args) as $cat):
                $tags[$cat->slug] = $cat->name ;
            endforeach;
        
            return $tags;
        }
}

$widgets_manager->register( new TP_Case_Studies() );



