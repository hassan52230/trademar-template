<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_About extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
    	return 'tp-about';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
    	return __( 'About Us', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
    	return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
    	return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
    	return [ 'tpcore'];
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

    	$this->start_controls_section(
    		'content_section',
    		[
    			'label' => esc_html__( 'Content', 'tpcore' ),
    			'tab' => Controls_Manager::TAB_CONTENT,
    		]
    	);

      $this->add_control(
         'about_us_title',
         [
            'label' => esc_html__( 'Section Title', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( 'Let’s Explore Our Intellectual Property Journey ' , 'tpcore' ),
            'label_block' => true,
         ]
      );

      $this->add_control(
         'about_us_sub_title',
         [
            'label' => esc_html__( 'Section Sub Title', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( 'ABOUT US ' , 'tpcore' ),
            'label_block' => true,
         ]
      );

      $this->add_control(
         'about_us_content',
         [
            'label' => esc_html__( 'Section Content', 'tpcore' ),
            'type' => Controls_Manager::WYSIWYG,
            'default' => esc_html__( 'We are a team of the dedicated patent professionals, united by our commitment toour excellence patent protection. With years of collective experience acros diverse industries team of this dedicated patent professionals, united by our' , 'tpcore' ),
            'show_label' => false,
         ]
      );

      $this->add_control(
         'about_us_image',
         [
            'label' => esc_html__( 'About Us Image', 'tpcore' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
               'url' => Utils::get_placeholder_image_src(),
            ],
         ]
      );

      $this->add_control(
         'about_us_ex_year',
         [
            'label' => esc_html__( 'Experience Year', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( '10 ' , 'tpcore' ),
            'label_block' => true,
         ]
      );

      $this->add_control(
         'about_us_ex_year_text',
         [
            'label' => esc_html__( 'Experience Year Text', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( 'Year Of Experience ' , 'tpcore' ),
            'label_block' => true,
         ]
      );

      $this->add_control(
         'about_us_award_image',
         [
            'label' => esc_html__( 'Award Image', 'tpcore' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
               'url' => Utils::get_placeholder_image_src(),
            ],
         ]
      );

       $this->add_control(
         'about_us_box_title_one',
         [
            'label' => esc_html__( 'Box One Title', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( 'Proven Track Record ' , 'tpcore' ),
            'label_block' => true,
         ]
      );

      $this->add_control(
         'about_us_box_content_one',
         [
            'label' => esc_html__( 'Box One Content', 'tpcore' ),
            'type' => Controls_Manager::WYSIWYG,
            'default' => esc_html__( 'We are history successful of patent application' , 'tpcore' ),
            'show_label' => false,
         ]
      );

      $this->add_control(
         'about_us_box_icon_one',
         [
            'label' => esc_html__( 'Box One Icon', 'tpcore' ),
            'type' => Controls_Manager::ICONS,
            'default' => [
               'value' => 'fas fa-circle',
               'library' => 'fa-solid',
            ],
            'recommended' => [
               'fa-solid' => [
                  'circle',
                  'dot-circle',
                  'square-full',
               ],
               'fa-regular' => [
                  'circle',
                  'dot-circle',
                  'square-full',
               ],
            ],
         ]
      );

      $this->add_control(
         'about_us_box_title_two',
         [
            'label' => esc_html__( 'Box Two Title', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( 'Proven Track Record ' , 'tpcore' ),
            'label_block' => true,
         ]
      );

      $this->add_control(
         'about_us_box_content_two',
         [
            'label' => esc_html__( 'Box Two Content', 'tpcore' ),
            'type' => Controls_Manager::WYSIWYG,
            'default' => esc_html__( 'We are history successful of patent application' , 'tpcore' ),
            'show_label' => false,
         ]
      );

      $this->add_control(
         'about_us_box_icon_two',
         [
            'label' => esc_html__( 'Box Two Icon', 'tpcore' ),
            'type' => Controls_Manager::ICONS,
            'default' => [
               'value' => 'fas fa-circle',
               'library' => 'fa-solid',
            ],
            'recommended' => [
               'fa-solid' => [
                  'circle',
                  'dot-circle',
                  'square-full',
               ],
               'fa-regular' => [
                  'circle',
                  'dot-circle',
                  'square-full',
               ],
            ],
         ]
      );

      $this->add_control(
         'about_us_btn_txt',
         [
            'label' => esc_html__( 'Button Text', 'tpcore' ),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__( 'Know More', 'tpcore' ),
            'placeholder' => esc_html__( 'Type your title here', 'tpcore' ),
         ]
      );

       $this->add_control(
         'about_us_btn_link',
         [
            'label' => esc_html__( 'Link', 'tpcore' ),
            'type' => Controls_Manager::URL,
            'options' => [ 'url', 'is_external', 'nofollow' ],
            'default' => [
               'url' => '',
               'is_external' => true,
               'nofollow' => true,
            ],
            'label_block' => true,
         ]
      );

       $this->add_control(
         'about_us_signature',
         [
            'label' => esc_html__( 'Client Signature', 'tpcore' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
               'url' => Utils::get_placeholder_image_src(),
            ],
         ]
      );


    	$this->end_controls_section();



    	$this->start_controls_section(
    		'style_section',
    		[
    			'label' => esc_html__( 'Style', 'tpcore' ),
    			'tab' => Controls_Manager::TAB_STYLE,
    		]
    	);

    	$this->add_control(
    		'name_color',
    		[
    			'label' => esc_html__( 'Name Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .testimonial-block_one-author' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'name_typography',
    			'selector' => '{{WRAPPER}} .testimonial-block_one-author',
    		]
    	);

    	$this->add_control(
    		'designation_color',
    		[
    			'label' => esc_html__( 'Designation Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .testimonial-block_one-author span' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'designation_typography',
    			'selector' => '{{WRAPPER}} .testimonial-block_one-author span',
    		]
    	);

    	

    	$this->add_control(
    		'content_color',
    		[
    			'label' => esc_html__( 'Content Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .testimonial-block_one-text p' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'content_typography',
    			'selector' => '{{WRAPPER}} .testimonial-block_one-text p',
    		]
    	);


    	$this->end_controls_section();




    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
    	$settings = $this->get_settings_for_display();
    	?>

      <section class="about-four">
      <div class="auto-container">
         <div class="row clearfix">

            <!-- Content Column -->
            <div class="about-four_image-column col-lg-6 col-md-12 col-sm-12">
               <div class="about-four_image-outer">
                  <div class="about-four_image">
                     <img src="<?php echo esc_url($settings['about_us_image']['url']); ?>" alt="image" />
                     <div class="about-four_experiance">
                        <span class="odometer" data-count="<?php echo esc_attr($settings['about_us_ex_year']); ?>"></span><i>+</i>
                        <div class="about-four_experiance-text"><?php echo esc_html($settings['about_us_ex_year_text']); ?></div>
                     </div>
                  </div>
                  <div class="about-four_award" data-parallax='{"y" : 50}'>
                     <img src="<?php echo esc_url($settings['about_us_award_image']['url']); ?>" alt="image" />
                  </div>
               </div>
            </div>

            <!-- Title Column -->
            <div class="about-four_content-column col-lg-6 col-md-12 col-sm-12">
               <div class="about-four_content-outer">
                  <div class="sec-title title-anim">
                     <div class="sec-title_title"><?php echo esc_html($settings['about_us_sub_title']); ?></div>
                     <h2 class="sec-title_heading"><?php echo esc_html($settings['about_us_title']); ?></h2>
                     <div class="sec-title_text"><?php echo esc_html($settings['about_us_content']); ?> </div>
                  </div>
                  <div class="row clearfix">

                     <!-- About Four Block -->
                     <div class="about-four_block col-lg-6 col-md-6 col-sm-12">
                        <div class="about-four_block-inner">
                           <div class="about-four_block-icon">
                              <i class="<?php echo esc_attr($settings['about_us_box_icon_one']['value']); ?>"></i>
                           </div>
                           <h5 class="about-four_block-title"><?php echo esc_html($settings['about_us_box_title_one']); ?></h5>
                           <div class="about-four_block-text"><?php echo esc_html($settings['about_us_box_content_one']); ?></div>
                        </div>
                     </div>

                     <!-- About Four Block -->
                     <div class="about-four_block col-lg-6 col-md-6 col-sm-12">
                        <div class="about-four_block-inner">
                           <div class="about-four_block-icon">
                              <i class="<?php echo esc_attr($settings['about_us_box_icon_two']['value']); ?>"></i>
                           </div>
                           <h5 class="about-four_block-title"><?php echo esc_html($settings['about_us_box_title_two']); ?></h5>
                           <div class="about-four_block-text"><?php echo esc_html($settings['about_us_box_content_two']); ?></div>
                        </div>
                     </div>

                  </div>
                  <div class="about-four_button d-flex align-items-center flex-wrap">
                     <a href="<?php echo esc_url($settings['about_us_btn_link']['url']); ?>" class="theme-btn btn-style-one">
                        <span class="btn-wrap">
                           <span class="text-one">Know More <i class="fa-solid fa-angle-right fa-fw"></i></span>
                           <span class="text-two">Know More <i class="fa-solid fa-angle-right fa-fw"></i></span>
                        </span>
                     </a>
                     <div class="about-four_signature">
                        <img src="<?php echo esc_url($settings['about_us_signature']['url']); ?>" alt="image" />
                     </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </section>

    	<?php
    }
}

$widgets_manager->register( new TP_About() );



