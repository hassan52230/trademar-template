<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Portfolio_List extends Widget_Base {

     use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-portfolio-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio List', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   
	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                    'layout-5' => esc_html__('Layout 5', 'tpcore'),
                    'layout-6' => esc_html__('Layout 6', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // tp_section_title
        $this->tp_section_title_render_controls('portfolio', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1','layout-5','layout-6']);

        $this->start_controls_section(
         'tp_portfolio_sec',
             [
               'label' => esc_html__( 'Portfolio Slider', 'tpcore' ),
               'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
             ]
        );
        
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tp_portfolio_image',
            [
                'label' => esc_html__('Upload Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );
        
        $repeater->add_control(
         'tp_portfolio_box_title',
           [
             'label'   => esc_html__( 'Portfolio Title', 'tpcore' ),
             'type'        => \Elementor\Controls_Manager::TEXT,
             'default'     => esc_html__( 'Default-value Title', 'tpcore' ),
             'label_block' => true,
           ]
        );
        
        $repeater->add_control(
         'tp_portfolio_box_sub_title',
           [
             'label'   => esc_html__( 'Portfolio Sub Title', 'tpcore' ),
             'type'        => \Elementor\Controls_Manager::TEXT,
             'default'     => esc_html__( 'Default-value Subtitle', 'tpcore' ),
             'label_block' => true,
           ]
        );
         
        $repeater->add_control(
            'tp_portfolio_link_switcher',
            [
                'label' => esc_html__( 'Add Portfolio link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'tp_portfolio_link_type',
            [
                'label' => esc_html__( 'Portfolio Link Type', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'tp_portfolio_link_switcher' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'tp_portfolio_link',
            [
                'label' => esc_html__( 'Portfolio Link link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'tpcore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'tp_portfolio_link_type' => '1',
                    'tp_portfolio_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'tp_portfolio_page_link',
            [
                'label' => esc_html__( 'Select Portfolio Link Page', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_portfolio_link_type' => '2',
                    'tp_portfolio_link_switcher' => 'yes',
                ]
            ]
        );
        
        $this->add_control(
        'tp_portfolio_list',
            [
                'label'       => esc_html__( 'Portfolio List', 'tpcore' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                [
                    'tp_portfolio_box_title' => esc_html__('Business Stratagy', 'tpcore'),
                ],
                [
                    'tp_portfolio_box_title' => esc_html__('Website Development', 'tpcore')
                ],
                [
                    'tp_portfolio_box_title' => esc_html__('Marketing & Reporting', 'tpcore')
                ],
                ],
                'title_field' => '{{{ tp_portfolio_box_title }}}',
            ]
        );

        $this->add_group_control(
        Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        
        $this->end_controls_section();


        // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'tp-core'),
                'condition' => [
                    'tp_design_style' => 'layout-1'
                ]
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'tp-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tp-core'),
                'title' => esc_html__('Enter button text', 'tp-core'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'tp-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tp-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'tp-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();


	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('services_section', 'Section Style', '.ele-section');
        $this->tp_basic_style_controls('portfolio_sub_title', 'Subtitle Style', '.ele-subtitle');
        $this->tp_basic_style_controls('portfolio_title', 'Heading Style', '.ele-heading');
        $this->tp_basic_style_controls('portfolio_des', 'Content Style', '.ele-description');
        $this->tp_link_controls_style('portfolio_btn', 'Button Style', '.ele-btn');
        $this->tp_basic_style_controls('portfolio_repeater_title', 'Project Title Style', '.ele-repeater-title');
        $this->tp_basic_style_controls('portfolio_repeater_des', 'Project Description Style', '.ele-repeater-des');
        $this->tp_link_controls_style('portfolio_repeater_btn', 'Project Repeater Button', '.ele-repeater-btn');

    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    $bloginfo = get_bloginfo( 'name' );
    $this->add_render_attribute('title_args', 'class', 'tp-section__title ele-heading');
?>

 <section class="portfolio-area pt-145 pb-145 ele-section"> 
    <div class="container">
       <div class="row">
          <div class="col-lg-12">
             <div class="portfolio-4-list">
                <ul>
                    <?php foreach ($settings['tp_portfolio_list'] as $item) :
                        if ( !empty($item['tp_portfolio_image']['url']) ) {
                            $tp_portfolio_image_url = !empty($item['tp_portfolio_image']['id']) ? wp_get_attachment_image_url( $item['tp_portfolio_image']['id'], $settings['thumbnail_size']) : $item['tp_portfolio_image']['url'];
                            $tp_portfolio_image_alt = get_post_meta($item["tp_portfolio_image"]["id"], "_wp_attachment_image_alt", true);
                        }
                        // Link
                        if ('2' == $item['tp_portfolio_link_type']) {
                            $link = get_permalink($item['tp_portfolio_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['tp_portfolio_link']['url']) ? $item['tp_portfolio_link']['url'] : '';
                            $target = !empty($item['tp_portfolio_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['tp_portfolio_link']['nofollow']) ? 'nofollow' : '';
                        }

                    ?>
                   <li>
                      <h3 class="portfolio-4-title">
                         <a href="<?php echo esc_url($link); ?>" class="tp-img-reveal tp-img-reveal-item" data-img="<?php echo esc_url($tp_portfolio_image_url); ?>" data-fx="1"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a>
                      </h3>
                   </li>
                   <?php endforeach; ?>
                </ul>
             </div>
          </div>
       </div>
    </div>
 </section>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : 
    $bloginfo = get_bloginfo( 'name' );
    $this->add_render_attribute('title_args', 'class', 'tp-section__title ele-heading');
?>
    <?php foreach ($settings['tp_portfolio_list'] as $item) :
        if ( !empty($item['tp_portfolio_image']['url']) ) {
            $tp_portfolio_image_url = !empty($item['tp_portfolio_image']['id']) ? wp_get_attachment_image_url( $item['tp_portfolio_image']['id'], $settings['thumbnail_size']) : $item['tp_portfolio_image']['url'];
            $tp_portfolio_image_alt = get_post_meta($item["tp_portfolio_image"]["id"], "_wp_attachment_image_alt", true);
        }
        // Link
        if ('2' == $item['tp_portfolio_link_type']) {
            $link = get_permalink($item['tp_portfolio_page_link']);
            $target = '_self';
            $rel = 'nofollow';
        } else {
            $link = !empty($item['tp_portfolio_link']['url']) ? $item['tp_portfolio_link']['url'] : '';
            $target = !empty($item['tp_portfolio_link']['is_external']) ? '_blank' : '';
            $rel = !empty($item['tp_portfolio_link']['nofollow']) ? 'nofollow' : '';
        }

    ?>
     <div class="services-5">
        <div class="services-5-item mb-25">
           <h3 class="services-5-title">
            <a href="<?php echo esc_url($link); ?>" class="tp-img-reveal-2 tp-img-reveal-item" data-img="<?php echo esc_url($tp_portfolio_image_url); ?>" data-fx="1"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a>
           </h3>
        </div>
     </div>
     <?php endforeach; ?>


<?php elseif ( $settings['tp_design_style']  == 'layout-4' ) : 
    $bloginfo = get_bloginfo( 'name' );
    $this->add_render_attribute('title_args', 'class', 'tp-section__title ele-heading');
?>
  <div class="case-5-item">
     <div class="row">
        <?php foreach ($settings['tp_portfolio_list'] as $key => $item) :
            if ( !empty($item['tp_portfolio_image']['url']) ) {
                $tp_portfolio_image_url = !empty($item['tp_portfolio_image']['id']) ? wp_get_attachment_image_url( $item['tp_portfolio_image']['id'], $settings['thumbnail_size']) : $item['tp_portfolio_image']['url'];
                $tp_portfolio_image_alt = get_post_meta($item["tp_portfolio_image"]["id"], "_wp_attachment_image_alt", true);
            }
            // Link
            if ('2' == $item['tp_portfolio_link_type']) {
                $link = get_permalink($item['tp_portfolio_page_link']);
                $target = '_self';
                $rel = 'nofollow';
            } else {
                $link = !empty($item['tp_portfolio_link']['url']) ? $item['tp_portfolio_link']['url'] : '';
                $target = !empty($item['tp_portfolio_link']['is_external']) ? '_blank' : '';
                $rel = !empty($item['tp_portfolio_link']['nofollow']) ? 'nofollow' : '';
            }

        ?>

        <?php if ( $key == 0 ) : ?>
        <div class="col-lg-3 align-self-end">
           <div class="case-5-wrapper">
              <div class="case-5-info">
                 <span class="under-line-heading"><a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a></span>
              </div>
              <div class="case-5-thumb">
                 <img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="">
              </div>
           </div>
        </div>
        <?php elseif ( $key == 1 ) : ?>
        <div class="col-lg-6">
           <div class="case-5-wrapper ml-40">
              <div class="case-5-thumb">
                 <img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="">
              </div>
              <div class="case-5-info">
                 <span class="under-line-heading"><a href="<?php echo esc_url($link); ?>">Art <?php echo tp_kses($item['tp_portfolio_box_title']); ?></a></span>
              </div>
           </div>
        </div>
        <?php elseif ( $key == 2 ) : ?>
        <div class="col-lg-3 align-self-start">
           <div class="case-5-wrapper">
              <div class="case-5-thumb">
                 <img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="">
              </div>
              <div class="case-5-info">
                 <span class="under-line-heading"><a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a></span>
              </div>
           </div>
        </div>
        <?php endif; ?>

        <?php endforeach; ?>
     </div>
  </div>


<?php elseif ( $settings['tp_design_style']  == 'layout-5' ) : 
    $bloginfo = get_bloginfo( 'name' );
    $this->add_render_attribute('title_args', 'class', 'whitesection-title ele-heading');
?>

 <section class="portfolio-area portfolio-6-bg pt-145 mt-10 pb-105 ele-section">
    <div class="portfolio-6-theme-bg"></div>
    <div class="container">
       <div class="row align-items-center">
          <div class="col-lg-7">
             <div class="whitesection mb-65">
                <?php if ( !empty($settings['tp_portfolio_sub_title']) ) : ?>
                <span class="whitesection-round-subtitle mb-10 ele-subtitle"><?php echo tp_kses($settings['tp_portfolio_sub_title']); ?></span>
                <?php endif; ?>
                <?php
                if ( !empty($settings['tp_portfolio_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_portfolio_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_portfolio_title' ] )
                        );
                endif;
                ?>
             </div>
          </div>
          <div class="col-lg-5">
             <div class="whitesection mb-65">
                <?php if ( !empty($settings['tp_portfolio_description']) ) : ?>
                <p class="ele-description"><?php echo tp_kses( $settings['tp_portfolio_description'] ); ?></p>
                <?php endif; ?>
             </div>
          </div>
       </div>
    </div>
    <div class="portfolio-6-wrap">
       <div class="container-fluid">
          <div class="row gx-6">
            <?php foreach ($settings['tp_portfolio_list'] as $key => $item) :
                if ( !empty($item['tp_portfolio_image']['url']) ) {
                    $tp_portfolio_image_url = !empty($item['tp_portfolio_image']['id']) ? wp_get_attachment_image_url( $item['tp_portfolio_image']['id'], $settings['thumbnail_size']) : $item['tp_portfolio_image']['url'];
                    $tp_portfolio_image_alt = get_post_meta($item["tp_portfolio_image"]["id"], "_wp_attachment_image_alt", true);
                }
                // Link
                if ('2' == $item['tp_portfolio_link_type']) {
                    $link = get_permalink($item['tp_portfolio_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_portfolio_link']['url']) ? $item['tp_portfolio_link']['url'] : '';
                    $target = !empty($item['tp_portfolio_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_portfolio_link']['nofollow']) ? 'nofollow' : '';
                }

                $class = ($key%2) == 0 ? 'portfolio-6-item-bottom' : '';
            ?>
             <div class="col-lg-3 col-md-6">
                <div class="portfolio-6-item <?php echo esc_attr($class); ?> mb-40 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".4s">
                   <div class="portfolio-6-thumb">
                      <?php if(!empty($link)) : ?>
                            <a href="<?php echo esc_url($link); ?>"><img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="<?php echo esc_url($tp_portfolio_image_alt); ?>"></a>
                        <?php else : ?>
                            <img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="<?php echo esc_url($tp_portfolio_image_alt); ?>">
                        <?php endif; ?>
                   </div>
                   <div class="portfolio-6-content">
                      <h4 class="portfolio-6-title">
                        <?php if(!empty($link)) : ?>
                        <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a>
                        <?php else : ?>
                        <?php echo tp_kses($item['tp_portfolio_box_title']); ?>
                        <?php endif; ?>
                      </h4>
                      <div class="portfolio-6-details">
                         <span><a href="<?php echo esc_url($link); ?>">Discover <br> Now</a></span>
                      </div>
                   </div>
                </div>
             </div>
             <?php endforeach; ?>
          </div>
       </div>
    </div>
 </section>

<?php elseif ( $settings['tp_design_style']  == 'layout-6' ) : 
    $bloginfo = get_bloginfo( 'name' );
    $this->add_render_attribute('title_args', 'class', 'tpsection-title ele-heading');
?>

 <section class="category-area pt-130 pb-140 ele-section">
    <div class="container">
       <div class="row">
          <div class="col-lg-12">
             <div class="tpsection text-center mb-65">
                <?php if ( !empty($settings['tp_portfolio_sub_title']) ) : ?>
                <span class="tp-section__title-pre ele-subtitle"><?php echo tp_kses($settings['tp_portfolio_sub_title']); ?></span>
                <?php endif; ?>
                <?php
                if ( !empty($settings['tp_portfolio_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_portfolio_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_portfolio_title' ] )
                        );
                endif;
                ?>
                <?php if ( !empty($settings['tp_portfolio_description']) ) : ?>
                <p class="ele-description"><?php echo tp_kses( $settings['tp_portfolio_description'] ); ?></p>
                <?php endif; ?>
             </div>
          </div>
       </div>
       <div class="category-7-slider">
          <div class="swiper-container category-7-active">
             <div class="swiper-wrapper">
                <?php foreach ($settings['tp_portfolio_list'] as $item) :
                    if ( !empty($item['tp_portfolio_image']['url']) ) {
                        $tp_portfolio_image_url = !empty($item['tp_portfolio_image']['id']) ? wp_get_attachment_image_url( $item['tp_portfolio_image']['id'], $settings['thumbnail_size']) : $item['tp_portfolio_image']['url'];
                        $tp_portfolio_image_alt = get_post_meta($item["tp_portfolio_image"]["id"], "_wp_attachment_image_alt", true);
                    }
                    // Link
                    if ('2' == $item['tp_portfolio_link_type']) {
                        $link = get_permalink($item['tp_portfolio_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['tp_portfolio_link']['url']) ? $item['tp_portfolio_link']['url'] : '';
                        $target = !empty($item['tp_portfolio_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['tp_portfolio_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
                <div class="swiper-slide">
                   <div class="category-7 mb-20">
                      <div class="category-7-thumb tp-thumb-common">
                         <div class="tp-thumb-common-overlay wow"></div>
                       <?php if(!empty($link)) : ?>
                            <a href="<?php echo esc_url($link); ?>"><img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="<?php echo esc_url($tp_portfolio_image_alt); ?>"></a>
                        <?php else : ?>
                            <img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="<?php echo esc_url($tp_portfolio_image_alt); ?>">
                        <?php endif; ?>
                      </div>
                      <div class="category-7-content">
                         <?php if(!empty($link)) : ?>
                        <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a>
                        <?php else : ?>
                        <?php echo tp_kses($item['tp_portfolio_box_title']); ?>
                        <?php endif; ?>
                      </div>
                   </div>
                </div>
                <?php endforeach; ?>
             </div>
             <div class="category-7-arrow d-flex align-items-center justify-content-center">
                <div class="category-7-single-arrow category-7-button-prev">
                   <span>
                      <svg width="35" height="28" viewBox="0 0 35 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                         <g clip-path="url(#clip0_326_651)">
                         <path d="M35 13.9954H3.29442e-07" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                         <path d="M13.5547 0C13.5547 7.73574 7.49212 13.9953 -0.000121431 13.9953" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                         <path d="M-0.000121431 13.9954C7.49212 13.9954 13.5547 20.255 13.5547 27.9907" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                         </g>
                         <defs>
                         <clipPath id="clip0_326_6512">
                         <rect width="35" height="28" fill="white" transform="matrix(-1 0 0 1 35 0)"/>
                         </clipPath>
                         </defs>
                      </svg>
                   </span>
                </div>
                <div class="category-7-single-arrow category-7-button-next ml-25">
                   <span>
                      <svg width="35" height="28" viewBox="0 0 35 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                         <g clip-path="url(#clip0_326_645)">
                         <path d="M0 13.9954H35" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                         <path d="M21.4453 0C21.4453 7.73574 27.5079 13.9953 35.0001 13.9953" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                         <path d="M35.0001 13.9954C27.5079 13.9954 21.4453 20.255 21.4453 27.9907" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                         </g>
                         <defs>
                         <clipPath id="clip0_326_645">
                         <rect width="35" height="28" fill="white"/>
                         </clipPath>
                         </defs>
                      </svg>
                   </span>
                </div>
             </div>
          </div>
       </div>
    </div>
 </section>



<?php else:
    $bloginfo = get_bloginfo( 'name' );
    $this->add_render_attribute('title_args', 'class', 'tpsection-title mb-65 ele-heading');

    // Link
    if ('2' == $settings['tp_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn ele-btn');
    } else {
        if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn ele-btn');
        }
    }
?>

 <section class="portfolio-area ele-section">
    <div class="container">
       <div class="row">
          <div class="col-lg-12">
             <div class="tpsection text-center">
                <?php if ( !empty($settings['tp_portfolio_sub_title']) ) : ?>
                <span class="tp-section__title-pre ele-subtitle"><?php echo tp_kses($settings['tp_portfolio_sub_title']); ?></span>
                <?php endif; ?>
                <?php
                if ( !empty($settings['tp_portfolio_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_portfolio_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_portfolio_title' ] )
                        );
                endif;
                ?>
                <?php if ( !empty($settings['tp_portfolio_description']) ) : ?>
                <p class="ele-description"><?php echo tp_kses( $settings['tp_portfolio_description'] ); ?></p>
                <?php endif; ?>
             </div>
          </div>
       </div>
       <div class="portfolio-wrap">
          <div class="row gx-8 portfolio-active">
            <?php foreach ($settings['tp_portfolio_list'] as $item) :
                if ( !empty($item['tp_portfolio_image']['url']) ) {
                    $tp_portfolio_image_url = !empty($item['tp_portfolio_image']['id']) ? wp_get_attachment_image_url( $item['tp_portfolio_image']['id'], $settings['thumbnail_size']) : $item['tp_portfolio_image']['url'];
                    $tp_portfolio_image_alt = get_post_meta($item["tp_portfolio_image"]["id"], "_wp_attachment_image_alt", true);
                }
                // Link
                if ('2' == $item['tp_portfolio_link_type']) {
                    $link = get_permalink($item['tp_portfolio_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_portfolio_link']['url']) ? $item['tp_portfolio_link']['url'] : '';
                    $target = !empty($item['tp_portfolio_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_portfolio_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
             <div class="col-lg-6 col-md-6 portfolio-item-active">
                <div class="portfolio-2 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".2s">
                   <div class="portfolio-2-thumb p-relative tp-thumb-common fix">
                      <div class="tp-thumb-common-overlay wow"></div>
                      <?php if(!empty($link)) : ?>
                            <a href="<?php echo esc_url($link); ?>"><img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="<?php echo esc_url($tp_portfolio_image_alt); ?>"></a>
                        <?php else : ?>
                            <img src="<?php echo esc_url($tp_portfolio_image_url); ?>" alt="<?php echo esc_url($tp_portfolio_image_alt); ?>">
                        <?php endif; ?>
                        <?php if(!empty($link)) : ?>
                      <div class="portfolio-2-badge">
                         <a href="<?php echo esc_url($link); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio/portfolio--2-badge.jpg" alt=""></a>
                      </div>
                      <?php endif; ?>
                   </div>
                   <div class="portfolio-2-content">
                    <?php if(!empty($item['tp_portfolio_box_sub_title'])) : ?>
                    <span class="ele-repeater-des"><?php echo tp_kses($item['tp_portfolio_box_sub_title']); ?></span>
                    <?php endif; ?>
                      <h5 class="portfolio-2-title">
                        <?php if(!empty($link)) : ?>
                        <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_portfolio_box_title']); ?></a>
                        <?php else : ?>
                        <?php echo tp_kses($item['tp_portfolio_box_title']); ?>
                        <?php endif; ?>
                      </h5>
                   </div>
                </div>
             </div>
            <?php endforeach; ?>
          </div>
       </div>
    </div>
 </section>


<?php endif; 

	}

}

$widgets_manager->register( new TP_Portfolio_List() );