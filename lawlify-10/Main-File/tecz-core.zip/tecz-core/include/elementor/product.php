<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Product extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-product';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Product', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->tp_section_title_render_controls('product', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-2', 'layout-3']);
        
        // Blog Query
		$this->tp_query_controls('product', 'Product', 'product', 'product_cat');

        
        $this->tp_button_render('product', 'Button', ['layout-2', 'layout-3']); 

        // tp_post__columns_section
        $this->tp_columns('col', ['layout-1', 'layout-2']);
    }

    // style_tab_content
    protected function style_tab_content(){
		$this->tp_section_style_controls('blog_section', 'Section Style', '.tp-el-section');
    }
    
	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        /**
         * Setup the post arguments.
        */
        $query_args = TP_Helper::get_query_args('product', 'product_cat', $this->get_settings());

        // The Query
        $query = new \WP_Query($query_args);


        $filter_list = $settings['category'];

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    // Link
    if ('2' == $settings['tp_product_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_product_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn');
    } else {
        if ( ! empty( $settings['tp_product_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_product_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'tpsection-title');    
?>

<section class="product-area pb-140">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8  text-center">
                <?php if ( !empty($settings['tp_product_sub_title']) ) : ?>
                    <div class="tpsection-sub-title">
                        <span><?php echo tp_kses($settings['tp_product_sub_title']); ?></span>
                    </div>
                <?php endif; ?>
                <div class="tpsection tpsection-anim p-relative mb-85">
                    <?php
                    if ( !empty($settings['tp_product_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_product_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_product_title' ] )
                        );
                    endif;
                    ?>
                    <span class="wow bounceIn" data-wow-duration=".5s" data-wow-delay=".6s">
                        <svg width="469" height="52" viewBox="0 0 469 52" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M466.547 41.3471C462.003 39.848 457.098 38.9402 452.575 37.3989C439.347 33.2184 425.821 29.7558 412.274 26.5254C410.576 26.1031 408.75 25.5119 406.69 25.7653C409.578 27.6022 413.06 28.0878 416.372 28.869C419.494 29.5869 422.042 31.3815 421.299 32.4372C420.279 33.894 419.6 35.7309 415.311 35.1397C415.438 35.8576 416.33 36.1109 417.052 36.3432L421.829 37.7578C422.381 37.9267 422.933 38.1801 422.827 38.4968C422.657 39.0246 421.787 38.7713 421.15 38.6657C419.515 38.3912 418.559 37.5044 417.158 36.9977C416.181 36.6599 414.822 36.0898 414.546 36.9977C414.419 37.4622 413.421 38.3701 415.99 38.6235C417.264 38.7501 418.581 39.4047 419.855 39.8269C420.746 40.1225 421.235 40.4814 420.513 40.9248C420.194 41.1149 419.557 41.3471 419.642 41.5371C420.577 43.5851 418.39 42.6561 416.924 42.2972C412.933 41.1571 408.919 40.0169 404.885 38.8768C403.611 38.5179 401.36 37.6522 400.83 38.3701C400.044 39.4469 402.698 39.6791 403.972 40.1859C407.539 41.5794 411.828 42.1283 415.12 43.9018C415.842 44.303 416.627 44.0285 417.392 43.9441C419.005 43.7329 420.64 43.9863 421.575 45.0209C422.275 45.8021 420.746 46.6466 418.687 46.8366C417.753 46.9211 416.733 46.9633 415.99 46.541C413.633 45.1475 410.533 44.9786 407.773 44.303C407.985 44.8942 409.769 45.0209 409.196 45.9921C407.369 45.5698 405.48 45.232 403.675 44.7253C390.914 41.326 377.961 38.3279 364.86 35.7098C350.974 32.9439 337.045 30.1992 322.712 28.3412C315.535 27.391 308.125 25.9976 300.715 26.9477C300.481 26.9688 300.078 26.9477 299.929 26.8843C298.4 25.9553 296.956 26.3987 295.3 26.7365C294.302 26.9477 292.88 26.7365 291.86 26.2509C291.202 25.9553 290.459 25.7231 289.631 25.702C282.029 25.5964 274.492 24.5196 266.826 24.773C265.743 24.8152 264.639 24.773 263.556 24.6885C257.293 24.2029 250.965 24.034 244.616 24.2874C243.512 24.3296 242.366 24.2451 241.58 24.773C240.667 25.3853 239.818 25.3641 238.926 24.773C238.48 24.4774 237.737 24.4563 237.057 24.414C230.56 23.9707 224.062 24.5407 217.65 25.0686C215.718 25.2164 214.316 24.6041 212.469 24.8997C210.133 25.2586 207.479 24.8363 205.271 25.7442C204.804 25.9342 203.827 25.9131 203.424 25.5542C202.787 24.963 202.277 24.7096 201.661 25.5753C201.449 25.8498 200.706 26.1665 200.409 25.9131C198.88 24.6885 197.967 25.3219 196.884 26.1876C196.48 26.5043 195.631 26.4409 194.93 26.4621C193.147 26.4832 191.066 25.2164 189.58 26.8843C189.516 26.9477 188.9 26.9899 188.815 26.9265C187.074 25.892 185.885 26.6521 184.377 27.2644C183.613 27.5811 182.233 27.4755 181.108 27.5388C179.855 27.6022 178.602 27.56 177.37 27.6866C168.686 28.5312 159.98 29.4179 151.232 30.1147C141.741 30.917 132.292 31.8038 122.865 32.5005C121.527 32.6061 120.062 32.9228 119.149 32.0149C121.867 31.466 124.436 30.727 127.111 30.537C129.744 30.3258 132.165 29.0379 135.053 29.7769C135.562 29.9036 136.411 29.2913 136.135 28.7001C133.205 28.7423 130.254 28.679 127.345 28.9323C118.491 29.6502 109.679 30.6425 100.888 31.4448C91.9065 32.2683 83.2008 34.1474 74.389 35.5831C70.0574 36.2587 66.108 36.0054 61.925 36.1954C61.0333 36.2587 60.1202 35.9843 59.3134 35.7731C58.2942 35.4986 56.6167 35.0764 57.5085 34.4219C58.7825 33.4717 59.9503 34.2529 60.8846 34.6752C61.1606 34.8019 61.3305 35.013 61.6065 34.9497C62.7319 34.5274 61.7552 33.2184 64.0059 33.6195C65.0888 33.8096 65.9169 33.704 66.7662 33.324C68.3375 32.6483 64.9826 32.6906 66.4477 31.9938C67.658 31.6771 68.6985 31.9093 69.8238 31.8671C70.5882 31.846 71.4588 31.7616 71.7348 31.3815C72.8814 29.7347 75.7692 29.5657 78.1261 28.9746C82.6063 27.8555 87.1077 26.7999 92.6072 25.6175C90.59 25.3008 89.6557 25.6175 88.7002 25.7864C79.0603 27.6022 69.5478 29.7558 60.1415 32.2049C52.1577 34.3374 44.0679 36.4699 36.3814 39.1935C26.6566 42.5928 16.8255 45.8865 7.44042 49.8981C5.93286 50.5526 4.25543 51.0804 2.66293 51.6716C1.8136 51.9883 0.921799 52.1572 0.3485 51.7983C-0.373432 51.3549 0.136167 50.7215 0.879332 50.1726C1.4951 49.7292 2.2595 49.3491 2.98143 48.9269C5.61436 47.3645 8.41715 45.8865 11.4323 44.3663C6.59109 42.7617 8.92675 39.4258 10.6254 36.5754C11.4535 35.1186 12.7275 34.8019 14.681 35.3931C15.9125 35.7731 16.7831 35.4986 18.2694 35.0764C21.9215 34.0418 24.512 31.9938 28.0792 31.0437C33.706 29.4602 38.9719 27.3488 44.7261 26.1031C45.3418 25.9764 45.9151 25.892 46.3823 25.5753C50.4166 22.725 55.5338 22.4294 60.6086 22.5138C61.7552 20.7614 62.4134 20.318 65.5559 19.9802C67.7005 19.7691 69.3779 19.579 71.0554 18.5867C72.0533 17.9744 73.6458 17.89 74.4739 18.5867C74.75 18.8189 74.8986 19.1145 75.2596 19.3046C75.6418 19.5157 76.2575 19.5579 76.8733 19.3468C77.3404 19.199 77.298 18.9667 77.2767 18.7345C77.2343 17.1932 77.5103 17.0243 80.5466 16.8554C81.757 16.792 83.2857 17.2565 83.9864 16.792C86.4283 15.1663 89.4222 15.5252 92.2462 15.293C92.6709 15.2508 93.0743 15.0818 93.1805 14.7863C92.7346 14.1951 90.4201 14.6596 90.4838 13.625C92.1613 12.8438 94.1997 12.6749 96.3655 12.4427C100.018 12.126 102.948 12.9494 106.366 12.9705C108.129 12.9916 108.744 12.9283 109.36 12.1893C110.167 11.2181 111.186 11.2392 112.375 11.8092C112.949 12.0837 113.055 12.8227 114.669 12.1682C115.56 11.8092 117.047 12.126 117.854 11.4503C118.767 10.6902 119.977 10.3313 121.633 10.7325C122.334 10.9014 123.141 10.7325 123.735 10.4369C126.262 9.21228 128.364 9.78235 130.275 10.5424C133.099 8.36774 133.163 8.36774 137.961 8.85335C143.291 9.4023 143.864 9.2334 146.37 6.67866C143.079 6.29861 139.554 6.29861 136.772 5.24294C145.733 4.14503 153.929 5.07403 161.87 6.65754C162.507 6.34084 163.25 5.9608 163.993 5.58075C165.098 5.01069 167.858 5.1796 167.582 4.14503C167.37 3.34272 164.97 3.76499 163.717 3.4694C162.911 3.27938 161.297 3.36383 161.806 2.62486C162.21 2.05479 163.441 1.99145 164.546 2.05479C167.518 2.18147 170.385 2.43483 173.145 2.92045C175.799 3.38494 178.432 3.91278 181.66 3.53274C183.464 3.34272 185.545 3.13158 187.414 3.57497C188.794 3.91278 189.941 3.68053 191.023 3.08935C192.361 2.37149 193.805 2.0759 194.952 3.08935C195.674 3.74387 196.459 3.61719 197.861 3.27938C200.345 2.6882 203.487 3.21604 205.844 2.13924C206.014 2.05479 206.885 2.30815 207.394 2.43483C208.137 2.62486 208.52 3.13158 209.624 2.98379C209.412 2.01256 210.374 1.40027 212.512 1.14691C212.66 1.14691 212.83 1.14691 212.957 1.08357C216.546 -0.0565648 219.688 0.0490029 221.833 1.907C223.723 0.956885 223.829 1.18913 226.759 0.809091C228.5 0.597955 229.265 1.2947 230.687 1.08357C233.448 0.682409 235.571 0.766864 237.843 1.23136C239.223 1.50584 240.582 1.80143 242.174 1.4425C243.194 1.18913 243.661 0.344593 245.147 0.661296C246.4 0.935772 245.763 1.73809 246.612 2.16036C246.761 2.24481 247.164 2.2237 247.462 2.24481C248.375 1.97034 248.183 1.48472 248.375 1.08357C248.969 -0.0776784 250.073 -0.309927 252.133 0.407933C253.173 0.766864 253.662 1.2947 254.277 1.80143C255.021 2.41372 258.63 2.28704 258.354 1.99145C256.656 0.239025 259.841 1.16802 260.796 0.851318C262.962 0.154571 263.811 0.38682 263.578 1.63252C263.493 2.05479 264.257 2.2237 265.149 2.2237C266.465 2.2237 267.782 2.2237 269.056 2.24481C269.438 1.86477 267.315 1.50584 269.013 1.23136C269.926 1.08357 271.073 0.872431 271.965 1.40027C272.665 1.82254 271.944 2.49817 273.196 3.0049C273.494 2.5404 273.621 2.26593 273.876 2.01256C274.959 0.914659 275.362 0.851318 276.785 1.86477C277.677 2.51929 278.717 2.26593 279.609 2.45595C282.39 3.02601 285.512 2.37149 288.145 3.3216C288.654 3.51162 289.822 3.4694 290.714 3.59608C293.58 3.97612 296.553 4.5673 298.485 2.94156C298.931 2.56152 299.865 2.6882 300.439 2.98379C301.437 3.4694 302.796 3.76499 303.772 4.20837C305.28 4.88401 306.32 5.30628 308.422 4.82067C309.654 4.54619 311.99 4.58842 313.094 4.96846C316.003 5.9608 318.912 5.87634 321.905 5.91857C323.583 5.93968 325.303 5.813 326.768 6.42529C328.127 7.01647 329.358 7.12204 330.951 6.86868C333.435 6.46752 335.452 7.31206 337.724 7.86102C339.869 8.40997 342.502 7.79768 345.135 8.47331C350.825 9.97237 356.664 11.0914 362.886 11.5348C364.967 11.6826 367.047 12.3371 368.534 13.0972C369.595 13.625 370.063 13.7095 371.443 13.7517C374.776 13.8573 378.896 13.7517 381.359 15.2296C384.14 16.9398 387.941 16.6654 390.659 17.9744C395.118 18.08 398.473 19.8324 402.061 21.1626C403.293 21.6271 404.461 22.0704 405.819 21.9226C406.52 21.8593 407.2 21.8382 407.964 22.0493C412.55 23.2528 416.924 24.6885 421.447 25.9976C423.486 26.631 425.418 27.9189 427.626 27.6655C430.11 27.4122 431.915 28.13 433.635 29.1435C436.523 30.8326 439.75 31.8249 443.487 32.1416C444.676 32.2683 445.781 32.4794 446.736 33.1128C448.392 34.2107 450.622 34.9497 452.66 35.4775C457.926 36.9766 462.958 39.0246 468.16 40.6292C468.712 40.7981 469.158 41.1149 468.946 41.4949C468.288 41.8327 467.375 41.5793 466.568 41.326L466.547 41.3471ZM392.103 30.8748C391.614 30.727 390.935 30.6636 390.468 30.727C388.344 31.0226 386.37 30.3681 384.862 29.7347C378.471 27.011 370.869 26.5465 363.862 25.1108C369.553 27.2221 375.668 28.5312 381.826 29.988C385.52 30.9592 389.173 31.8038 392.973 32.4583C393.355 32.5216 393.823 32.6483 394.099 32.8172C398.876 35.7731 405.204 35.8153 411.085 37.6311C410.915 36.2587 409.705 35.7731 408.389 35.3509C403.08 33.6618 397.432 32.5005 392.103 30.8537V30.8748Z" fill="currentColor"/>
                            <path d="M462.64 47.6178C458.499 46.0132 454.274 44.5141 449.963 43.1206C448.966 42.7828 447.968 42.3183 447.267 42.5084C446.842 44.9575 452.342 45.2531 453.064 47.47C450.728 46.9844 448.966 46.0765 447.585 45.3376C444.337 43.564 439.835 43.2473 436.969 41.1149C436.374 40.6715 435.164 40.2492 434.251 40.4181C432.467 40.7559 431.066 40.1436 429.537 39.5313C427.775 38.8557 425.927 38.2434 424.101 37.6522C420.746 36.6388 420.492 36.3854 420.959 34.443C421.15 33.704 421.49 33.0073 422.169 32.4161C423.783 31.0437 424.675 31.1281 427.201 32.6906C429.261 33.9785 431.151 35.4353 434.569 35.3509C435.652 35.3297 436.714 35.752 437.478 36.4699C438.986 37.9267 440.939 39.0246 443.912 39.0457C444.655 39.0457 445.292 39.2146 445.929 39.5525C451.62 42.4872 458.329 44.2819 464.232 46.9844C465.082 47.3645 466.504 47.4911 466.823 48.4624C465.251 48.4835 463.977 48.0612 462.661 47.5756L462.64 47.6178Z" fill="currentColor"/>
                            <path d="M231.048 27.75C244.213 28.1089 257.441 26.9477 270.33 28.4467C270.585 28.489 270.861 28.489 271.137 28.489C280.607 28.3834 289.822 29.7347 299.08 30.4103C300.481 30.537 302.265 30.6214 303.241 31.5504C299.271 31.7193 281.18 30.2414 262.792 29.6291C244.446 28.9112 225.825 29.1012 222.024 28.4256C225.506 27.9189 228.33 27.7078 231.069 27.75H231.048Z" fill="currentColor"/>
                            <path d="M319.676 33.1762C315.047 33.4295 307.446 32.4794 304.579 31.1915C309.994 31.6982 314.665 31.846 319.676 33.1762Z" fill="currentColor"/>
                            <path d="M43.3459 39.2569C43.8343 39.5736 43.7918 39.9958 42.9 40.1859C41.0527 40.587 39.163 41.2415 36.5725 40.7559C38.2712 40.0169 39.3328 39.5313 40.437 39.088C41.6685 38.6235 42.6028 38.7924 43.3247 39.2569H43.3459Z" fill="currentColor"/>
                        </svg>
                    </span>
                </div>
                <?php if ( !empty($settings['tp_product_description']) ) : ?>
                <p><?php echo tp_kses( $settings['tp_product_description'] ); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">

            <?php if ($query->have_posts()) :
                while ($query->have_posts()) : 
                $query->the_post();
                global $post;
                $categories = get_the_terms( $post->ID, 'product_cat' );
                global $product;
                $regular_price = $product->get_regular_price();
                $sale_price = $product->get_sale_price();
            ?>
            <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?>">
                <div class="product-4 mb-40">
                    <?php if(has_post_thumbnail()) : ?>
                    <div class="product-4-thumb p-relative mb-20">
                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                        
                        <div class="product-4-btn">
                            <?php product_add_to_cart();?>
                        </div>

                    </div>
                    <?php endif; ?>
                    <div class="product-4-content d-flex align-items-center justify-content-between">
                        <div class="product-4-info">
                            <?php if ( !empty( $categories[0]->name ) ): ?>
                            <span><?php echo esc_html($categories[0]->name); ?></span>
                            <?php endif;?>
                            <div class="under-line-heading">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> 
                            </div>
                        </div>
                        <div class="product-4-price">
                            <h4 class="pricing"><?php echo wc_price($regular_price)?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_query(); endif; ?>

        </div>
        <?php if ( !empty($settings['tp_product_btn_text']) ) : ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="product-4-all-btn text-center pt-25">
                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><?php echo tp_kses($settings['tp_product_btn_text']); ?></a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : 
    // Link
    if ('2' == $settings['tp_product_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_product_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-theme');
    } else {
        if ( ! empty( $settings['tp_product_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_product_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-theme');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'tpsection-title'); 
?>

<section class="top-product-area pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tpsection mb-65 text-center">
                    <?php if ( !empty($settings['tp_product_sub_title']) ) : ?>
                    <div class="tpsection-sub-title">
                        <span><?php echo tp_kses($settings['tp_product_sub_title']); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php
                    if ( !empty($settings['tp_product_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_product_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_product_title' ] )
                        );
                    endif;
                    ?>
                    <?php if ( !empty($settings['tp_product_description']) ) : ?>
                    <p><?php echo tp_kses( $settings['tp_product_description'] ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="top-product-nav mb-90">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <?php 
                        $count = 0;
                        foreach ( $filter_list as $key => $list ): 
                            $active = ($count == 0) ? 'active' : '';
                        ?>
                        <button class="nav-link ele-tab-buttons <?php echo esc_attr($active); ?>"
                            id="nav-all-tab-<?php echo esc_attr( $key ); ?>" data-bs-toggle="tab"
                            data-bs-target="#nav-all-<?php echo esc_attr( $key ); ?>" type="button" role="tab"
                            aria-controls="nav-all-<?php echo esc_attr( $key ); ?>"
                            aria-selected="true"><span><?php echo esc_html( ucwords(str_replace('-', ' ', $list)) ); ?></span></button>
                        <?php $count++; endforeach; ?>

                    </div>
                    </nav>
                </div>
            </div>
        </div>

        <?php if( !empty($filter_list) && count($filter_list) > 0 ) : ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="tab-content" id="nav-tabContent">

                    <?php
                        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';
                        foreach ($filter_list as $key => $list):
                        $active_tab = ($key == 0) ? 'active show' : '';
                    ?>

                    <div class="tab-pane product-style-2 fade <?php echo esc_attr($active_tab); ?>" id="nav-all-<?php echo esc_attr( $key ); ?>" role="tabpanel" aria-labelledby="nav-all-tab-<?php echo esc_attr( $key ); ?>">
                        <div class="row row-cols-xxl-3 row-cols-xl-3 row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1">

                            <?php
                                $post_args = [
                                    'post_status' => 'publish',
                                    'post_type' => 'product',
                                    'posts_per_page' => $posts_per_page,
                                    'tax_query' => array(
                                        array(
                                            'taxonomy' => 'product_cat',
                                            'field' => 'slug',
                                            'terms' => $list,
                                        ),
                                    ),
                                ];
                                $pro_query = new \WP_Query($post_args);
                                while ($pro_query->have_posts()) : 
                                $pro_query->the_post();
                                global $product;
                                global $post;
                                global $woocommerce;
                                $rating = wc_get_rating_html($product->get_average_rating());
                                $ratingcount = $product->get_review_count();
                                $attachment_ids = $product->get_gallery_image_ids();
                                $regular_price = $product->get_regular_price();

                                foreach( $attachment_ids as $key => $attachment_id ) {
                                    $image_link =  wp_get_attachment_url( $attachment_id );
                                    $arr[] = $image_link;
                                }
                                $categories = get_the_terms( $post->ID, 'product_cat' );
                            ?>
                            <div class="col">
                                <div class="product-7 mb-30">
                                    <?php if(has_post_thumbnail()) : ?>
                                    <div class="product-7-thumb text-center p-relative">
                                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                                        <div class="product-action-2 product-action d-flex flex-column flex-wrap">
                                            
                                            <?php woocommerce_template_loop_add_to_cart();?>

                                            <?php if( class_exists( 'WPCleverWoosq' )) : ?>
                                            <div class="product-action-btn text-start ">
                                                <?php echo do_shortcode('[woosq]'); ?>
                                            </div>
                                            <?php endif; ?>
                                            <?php if( function_exists( 'woosw_init' )) : ?>
                                            <div class="product-action-btn product-add-wishlist-btn text-start">
                                                <?php echo do_shortcode('[woosw]'); ?>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="product-7-content d-flex align-items-center justify-content-between">
                                        <div class="product-4-info">
                                            <?php if(!empty( $categories[0]->name )) : ?>
                                            <span><?php echo esc_html($categories[0]->name); ?></span>
                                            <?php endif; ?>
                                            <a href="<?php the_permalink(); ?>"><?php echo mb_strimwidth(get_the_title(), 0, 25, '..'); ?></a> 
                                        </div>
                                        <div class="product-7-price">
                                            <h4 class="pricing"><?php echo wc_price($regular_price)?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; wp_reset_query(); ?>

                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ( !empty($settings['tp_product_btn_text']) ) : ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="top-product-all text-center pt-35 mb-30">
                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><?php echo tp_kses($settings['tp_product_btn_text']); ?></a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php else : ?>
    
<div class="row">
    <?php if ($query->have_posts()) :
        while ($query->have_posts()) : 
        $query->the_post();
        global $post;
        $categories = get_the_category($post->ID);
    ?>
    <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?>">
        <div class="product-item-3 mb-45">
            <?php if(has_post_thumbnail()) : ?>
            <div class="product-item-3-thumb w-img p-relative fix mb-15">
                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                
                <div class="product-action d-flex flex-column flex-wrap ">
                    <?php if( class_exists( 'WPCleverWoosq' )) : ?>
                    <div class="product-action-btn ">
                        <?php echo do_shortcode('[woosq]'); ?>
                    </div>
                    <?php endif; ?>
                    <?php if( function_exists( 'woosw_init' )) : ?>
                    <div class="product-action-btn product-add-wishlist-btn">
                        <?php echo do_shortcode('[woosw]'); ?>
                    </div>
                    <?php endif; ?>
                    <?php woocommerce_template_loop_add_to_cart();?>
                </div>
                <div class="product-add ">
                    <a href="<?php the_permalink(); ?>" class="product-add-select"><?php echo esc_html__('View Product', 'tpcore'); ?></a>
                </div>
            </div>
            <?php endif; ?>
            <div class="product-item-3-content">
                <span class="product-item-3-title mb-5"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
                <?php 
                global $product;
                $regular_price = $product->get_regular_price();
                $sale_price = $product->get_sale_price();

                if(!empty($sale_price)) :
                ?>
                    <span class="product-item-3-price"><del><?php echo wc_price($sale_price);?></del><?php echo wc_price($regular_price)?></span>
                <?php
                else :
                ?>
                    <span class="product-item-3-price"><?php echo wc_price($regular_price)?></span>
                <?php
                endif;
                
                ?>
            </div>
        </div>
    </div>
    <?php endwhile; wp_reset_query(); endif; ?>
</div>

<?php endif;  
	}

}

$widgets_manager->register( new TP_Product() );