<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_history_timeline extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-history-timeline';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'History Timeline', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    }


    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls_section() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_year',
            [
                'label' => esc_html__( 'Year', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__( 'Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'List Content' , 'tpcore' ),
                'show_label' => false,
            ]
        );

        $repeater->add_control(
            'list_btn_txt',
            [
                'label' => esc_html__( 'Button Text', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Know More', 'tpcore' ),
                'placeholder' => esc_html__( 'Type your title here', 'tpcore' ),
            ]
        );

       $repeater->add_control(
            'list_btn_link',
            [
                'label' => esc_html__( 'Link', 'tpcore' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                        
                    ],
                    [
                        'list_title' => esc_html__( 'Title #2', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ], 
                    [
                        'list_title' => esc_html__( 'Title #3', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .history-block_one-heading' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .history-block_one-heading',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .history-block_one-text p' => 'color: {{VALUE}}',
                ],
            ]
        );
      

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .history-block_one-text p',
            ]
        );


        $this->end_controls_section();


        

    }

    protected function style_tab_content(){
        $this->tp_basic_style_controls('footer_title', 'Title Style', '.tp-el-title');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
     ?>


     <section class="history-one">
        <div class="history-one_circle"></div>
        <div class="history-one_circle-two"></div>
        <div class="auto-container">
            <div class="inner-container">
                <div class="history-one_slider swiper-container">
                    <div class="swiper-wrapper">
                        <?php foreach (  $settings['list'] as $key => $item ) : ?>
                        <!-- Slide -->
                        <div class="swiper-slide">
                            <!-- History Block One -->
                            <div class="history-block_one">
                                <div class="history-block_one-inner">
                                    <div class="history-block_one-year"><?php echo $item['list_year']; ?></div>
                                    <div class="history-block_one-circle"></div>
                                    <div class="history-block_one-content">
                                        <h4 class="history-block_one-heading"><?php echo $item['list_title']; ?></h4>
                                        <div class="history-block_one-text"><?php echo $item['list_content']; ?></div>
                                    </div>
                                    <div class="history-block_one-more"><a href="<?php echo $item['list_btn_link']['url']; ?>"><?php echo $item['list_btn_txt']; ?> <i class="fa-solid fa-angle-right fa-fw"></i></a></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach ; ?>
                    </div>
                    <!-- History One Arrows -->
                    <div class="history-one-arrow">
                        <!-- If we need navigation buttons -->
                        <div class="history-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                        <div class="history-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
                    </div>
                    <div class="history-one_carousel-pagination"></div>

                </div>

            </div>
        </div>
    </section>

    
     <?php
    }
}

$widgets_manager->register( new TP_history_timeline() );
