<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Testimonial extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-testimonial';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Testimonial', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'list_name',
            [
                'label' => esc_html__( 'Name', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Peter Anderson ' , 'tpcore' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'list_designation',
            [
                'label' => esc_html__( 'Designation', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Lead Generation' , 'tpcore' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'List Content' , 'tpcore' ),
                'show_label' => false,
            ]
        );



        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_name' => esc_html__( 'Peter Anderson', 'tpcore' ),
                        'list_designation' => esc_html__( 'Lead Generation', 'tpcore' ),

                    ],
                    [
                        'list_name' => esc_html__( 'Peter Anderson', 'tpcore' ),
                        'list_designation' => esc_html__( 'Lead Generation', 'tpcore' ),
                    ], 
                    [
                        'list_name' => esc_html__( 'Peter Anderson', 'tpcore' ),
                        'list_designation' => esc_html__( 'Lead Generation', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_name }}}',
            ]
        );

        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => esc_html__( 'Name Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block_one-author strong' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-block_three-author strong' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .testimonial-block_one-author strong',
                'selector' => '{{WRAPPER}} .testimonial-block_three-author strong',
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label' => esc_html__( 'Designation Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block_one-author' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-block_three-author' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'designation_typography',
                'selector' => '{{WRAPPER}} .testimonial-block_one-author',
                'selector' => '{{WRAPPER}} .testimonial-block_three-author',
            ]
        );



        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block_one-text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-block_three-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .testimonial-block_one-text p',
                'selector' => '{{WRAPPER}} .testimonial-block_three-text p',
            ]
        );


        $this->end_controls_section();

    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

        <?php if ($settings['design_style'] == 'layout-1') { ?> 
        <section class="testimonial-two">
            <div class="carousel-column">
                <div class="inner-column">
                    <div class="testimonial-two_carousel swiper-container">
                        <div class="swiper-wrapper">
                           <?php foreach (  $settings['list'] as $key => $item ) : ?>
                            <!-- Slide -->
                            <div class="swiper-slide">
                                <!-- Testimonial Block Two -->
                                <div class="testimonial-block_two">
                                    <div class="testimonial-block_two-inner">
                                        <div class="testimonial-block_two-rating">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        </div>
                                        <div class="testimonial-block_two-text"><?php echo $item['list_content']; ?></div>
                                        <div class="testimonial-block_two-author">
                                            <span><img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="author" /></span>
                                            <strong><?php echo $item['list_name'] ; ?></strong>
                                            <?php echo $item['list_designation']; ?>
                                        </div>
                                        <div class="testimonial-block_two-quote fa-solid fa-quote-right fa-fw"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach ; ?>
                    </div>

                    <!-- Testimonial Two Arrows -->
                    <div class="testimonial-two-arrow">
                        <div class="testimonial-two_carousel-pagination"></div>
                        <!-- If we need navigation buttons -->
                        <div class="testimonial-two_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                        <div class="testimonial-two_carousel-next fa-solid fa-angle-right fa-fw"></div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php } elseif($settings['design_style'] == 'layout-2') { ?>
    <section class="testimonial-four">
        <div class="auto-container">
            <div class="row clearfix">
                <?php foreach (  $settings['list'] as $key => $item ) : ?>
                <!-- Testimonial Block Two -->
                <div class="testimonial-block_three col-lg-4 col-md-6 col-sm-12">
                    <div class="testimonial-block_three-inner">
                        <div class="testimonial-block_three-quote fa-solid fa-quote-right fa-fw"></div>
                        <div class="testimonial-block_three-author">
                            <span><img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="" /></span>
                            <strong><?php echo $item['list_name'] ; ?></strong>
                            <?php echo $item['list_designation']; ?>
                        </div>
                        <div class="testimonial-block_three-text"><?php echo $item['list_content']; ?></div>
                        <div class="testimonial-block_three-rating">
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                        </div>
                    </div>
                </div>
                <?php endforeach ; ?>
            </div>

            <!-- Styled Pagination -->
           <!--  <ul class="styled-pagination text-center">
                <li><a href="#" class="active">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li class="next"><a href="#"><span class="fa-solid fa-angle-right fa-fw"></span></a></li>
            </ul> -->
            <!-- End Styled Pagination -->

        </div>
    </section>
    <?php } else { ?> 
    <section class="testimonial-three">
        <div class="auto-container">
            <div class="testimonial-three_carousel swiper-container">
                <div class="swiper-wrapper">
                    <?php foreach (  $settings['list'] as $key => $item ) : ?>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <!-- Testimonial Block Two -->
                        <div class="testimonial-block_three">
                            <div class="testimonial-block_three-inner">
                                <div class="testimonial-block_three-quote fa-solid fa-quote-right fa-fw"></div>
                                <div class="testimonial-block_three-author">
                                    <span><img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="author" /></span>
                                    <strong><?php echo $item['list_name'] ; ?></strong>
                                    <?php echo $item['list_designation']; ?>
                                </div>
                                <div class="testimonial-block_three-text"><?php echo $item['list_content']; ?></div>
                                <div class="testimonial-block_three-rating">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                     <?php endforeach ; ?>
                </div>

                <!-- Testimonial Three Arrows -->
                <div class="testimonial-three-arrow">
                    <!-- If we need navigation buttons -->
                    <div class="testimonial-three_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                    <div class="testimonial-three_carousel-next fa-solid fa-angle-right fa-fw"></div>
                </div>
                <div class="testimonial-three_carousel-pagination"></div>

            </div>
        </div>
    </section>
    <?php } ?>
    <?php
}
}

$widgets_manager->register( new TP_Testimonial() );
