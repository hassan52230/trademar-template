<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Utils;
use \Elementor\Control_Media;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Repeater;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Header_01 extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-header';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Header Builder', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}


    /**
     * Menu index.
     *
     * @access protected
     * @var $nav_menu_index
     */
    protected $nav_menu_index = 1;

    /**
     * Retrieve the menu index.
     *
     * Used to get index of nav menu.
     *
     * @since 1.3.0
     * @access protected
     *
     * @return string nav index.
     */
    protected function get_nav_menu_index() {
        return $this->nav_menu_index++;
    }

    /**
     * Retrieve the list of available menus.
     *
     * Used to get the list of available menus.
     *
     * @since 1.3.0
     * @access private
     *
     * @return array get WordPress menus list.
     */
    private function get_available_menus() {

        $menus = wp_get_nav_menus();

        $options = [];

        foreach ( $menus as $menu ) {
            $options[ $menu->slug ] = $menu->name;
        }

        return $options;
    }



     protected static function get_profile_names()
     {
         return [
             '500px' => esc_html__('500px', 'tpcore'),
             'apple' => esc_html__('Apple', 'tpcore'),
             'behance' => esc_html__('Behance', 'tpcore'),
             'bitbucket' => esc_html__('BitBucket', 'tpcore'),
             'codepen' => esc_html__('CodePen', 'tpcore'),
             'delicious' => esc_html__('Delicious', 'tpcore'),
             'deviantart' => esc_html__('DeviantArt', 'tpcore'),
             'digg' => esc_html__('Digg', 'tpcore'),
             'dribbble' => esc_html__('Dribbble', 'tpcore'),
             'email' => esc_html__('Email', 'tpcore'),
             'facebook' => esc_html__('Facebook', 'tpcore'),
             'flickr' => esc_html__('Flicker', 'tpcore'),
             'foursquare' => esc_html__('FourSquare', 'tpcore'),
             'github' => esc_html__('Github', 'tpcore'),
             'houzz' => esc_html__('Houzz', 'tpcore'),
             'instagram' => esc_html__('Instagram', 'tpcore'),
             'jsfiddle' => esc_html__('JS Fiddle', 'tpcore'),
             'linkedin' => esc_html__('LinkedIn', 'tpcore'),
             'medium' => esc_html__('Medium', 'tpcore'),
             'pinterest' => esc_html__('Pinterest', 'tpcore'),
             'product-hunt' => esc_html__('Product Hunt', 'tpcore'),
             'reddit' => esc_html__('Reddit', 'tpcore'),
             'slideshare' => esc_html__('Slide Share', 'tpcore'),
             'snapchat' => esc_html__('Snapchat', 'tpcore'),
             'soundcloud' => esc_html__('SoundCloud', 'tpcore'),
             'spotify' => esc_html__('Spotify', 'tpcore'),
             'stack-overflow' => esc_html__('StackOverflow', 'tpcore'),
             'tripadvisor' => esc_html__('TripAdvisor', 'tpcore'),
             'tumblr' => esc_html__('Tumblr', 'tpcore'),
             'twitch' => esc_html__('Twitch', 'tpcore'),
             'twitter' => esc_html__('Twitter', 'tpcore'),
             'vimeo' => esc_html__('Vimeo', 'tpcore'),
             'vk' => esc_html__('VK', 'tpcore'),
             'website' => esc_html__('Website', 'tpcore'),
             'whatsapp' => esc_html__('WhatsApp', 'tpcore'),
             'wordpress' => esc_html__('WordPress', 'tpcore'),
             'xing' => esc_html__('Xing', 'tpcore'),
             'yelp' => esc_html__('Yelp', 'tpcore'),
             'youtube' => esc_html__('YouTube', 'tpcore'),
         ];
     }
     


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    } 

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                    'layout-5' => esc_html__('Layout 5', 'tpcore'),
                    'layout-6' => esc_html__('Layout 6', 'tpcore'),
                    'layout-7' => esc_html__('Layout 7', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // layout Panel
        $this->start_controls_section(
            'tp_header_top',
            [
                'label' => esc_html__('Header Info', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_header_top_show',
            [
                'label' => esc_html__( 'Header Topbar Switch', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'tp_design_style' => ['layout-1','layout-4','layout-7'],
                ],
            ]
        );        

        $this->add_control(
            'tp_header_right_switch',
            [
                'label' => esc_html__( 'Header Right Switch', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );        

        $this->add_control(
            'tp_header_search_switch',
            [
                'label' => esc_html__( 'Header Search Switch', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'tp_design_style!' => ['layout-4'],
                ],
            ]
        );        

        $this->add_control(
            'tp_header_wishlist_switch',
            [
                'label' => esc_html__( 'Header Wishlist Switch', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'tp_design_style!' => ['layout-2','layout-3','layout-4','layout-7'],
                ],
            ]
        );        

        $this->add_control(
            'tp_header_cart_switch',
            [
                'label' => esc_html__( 'Header Cart Switch', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'tp_design_style!' => ['layout-2','layout-3','layout-4','layout-6'],
                ],
            ]
        );

        $this->add_control(
            'tp_header_intro',
            [
                'label' => esc_html__('Intro Text', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Free shipping on orders over $25', 'tpcore'),
                'placeholder' => esc_html__('Type intro text here', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_design_style' => ['layout-4','layout-4','layout-7'],
                ],
            ]
        );

        $this->add_control(
            'tp_wishlist_url',
            [
                'label' => esc_html__('Wishlist URL', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'placeholder' => esc_html__('#', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_design_style' => ['layout-1','layout-5','layout-6'],
                ],
            ]
        );

        $this->add_control(
            'tp_btn_image',
            [
                'label' => esc_html__( 'Button Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_design_style' => ['layout-6'],
                ],
            ]
        );

        $this->end_controls_section();

		// _tp_image
		$this->start_controls_section(
            '_tp_image',
            [
                'label' => esc_html__('Site Logo', 'tp-core'),
            ]
        );

        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'tp_image_size',
				'label'   => __( 'Image Size', 'header-footer-elementor' ),
				'default' => 'medium',
			]
		);

        $this->end_controls_section();


		$this->start_controls_section(
            'section_menu',
            [
                'label' => __( 'Menu', 'header-footer-elementor' ),
            ]
        );

        $menus = $this->get_available_menus();

        if ( ! empty( $menus ) ) {
            $this->add_control(
                'menu',
                [
                    'label'        => __( 'Menu', 'header-footer-elementor' ),
                    'type'         => Controls_Manager::SELECT,
                    'options'      => $menus,
                    'default'      => array_keys( $menus )[0],
                    'save_default' => true,
                    /* translators: %s Nav menu URL */
                    'description'  => sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'header-footer-elementor' ), admin_url( 'nav-menus.php' ) ),
                ]
            );
        } else {
            $this->add_control(
                'menu',
                [
                    'type'            => Controls_Manager::RAW_HTML,
                    /* translators: %s Nav menu URL */
                    'raw'             => sprintf( __( '<strong>There are no menus in your site.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'header-footer-elementor' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                ]
            );
        }

        $this->add_control(
            'menu_last_item',
            [
                'label'     => __( 'Last Menu Item', 'header-footer-elementor' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'none' => __( 'Default', 'header-footer-elementor' ),
                    'cta'  => __( 'Button', 'header-footer-elementor' ),
                ],
                'default'   => 'none',
                'condition' => [
                    'layout!' => 'expandible',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'tp_phone',
            [
                'label' => esc_html__('Phone Number', 'tpcore'),
                'condition' => [
                    'tp_design_style' => ['layout-2','layout-4','layout-7'],
                ],
            ]
        );

        $this->add_control(
            'tp_phone_label',
            [
                'label' => esc_html__('Phone Label', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Call Us Now', 'tpcore'),
                'placeholder' => esc_html__('Type phone label', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_phone_number',
            [
                'label' => esc_html__('Phone Number', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('(839) 367 025', 'tpcore'),
                'placeholder' => esc_html__('Type phone number', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_phone_url',
            [
                'label' => esc_html__('Phone Number URL', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Phone Number URL', 'tpcore'),
                'placeholder' => esc_html__('Type phone url', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'tp_email',
            [
                'label' => esc_html__('Email Info', 'tpcore'),
                'condition' => [
                    'tp_design_style' => ['layout-7'],
                ],
            ]
        );

        $this->add_control(
            'tp_email_id',
            [
                'label' => esc_html__('Email ID', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('support@gmail.com ', 'tpcore'),
                'placeholder' => esc_html__('Type Email ID', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_email_url',
            [
                'label' => esc_html__('Phone Email URL', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('support@gmail.com ', 'tpcore'),
                'placeholder' => esc_html__('Type email url', 'tpcore'),
                'label_block' => true,
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_social',
            [
                'label' => esc_html__('Social Profiles', 'tpcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-4'],
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Profile Name', 'tpcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'select2options' => [
                    'allowClear' => false,
                ],
                'options' => self::get_profile_names()
            ]
        );

        $repeater->add_control(
            'link', [
                'label' => esc_html__('Profile Link', 'tpcore'),
                'placeholder' => esc_html__('Add your profile link', 'tpcore'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'autocomplete' => false,
                'show_external' => false,
                'condition' => [
                    'name!' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $this->add_control(
            'profiles',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(name.slice(0,1).toUpperCase() + name.slice(1)) #>',
                'default' => [
                    [
                        'link' => ['url' => 'https://facebook.com/'],
                        'name' => 'facebook'
                    ],
                    [
                        'link' => ['url' => 'https://linkedin.com/'],
                        'name' => 'linkedin'
                    ],
                    [
                        'link' => ['url' => 'https://twitter.com/'],
                        'name' => 'twitter'
                    ]
                ],
            ]
        );

        $this->add_control(
            'show_profiles',
            [
                'label' => esc_html__('Show Profiles', 'tpcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'tpcore'),
                'label_off' => esc_html__('Hide', 'tpcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();

		$this->tp_button_render('tpbtn', 'Button', ['layout-3','layout-4','layout-6']);
		


        // side Panel
        $this->start_controls_section(
            'tp_header_side_info',
            [
                'label' => esc_html__('Offcanvas Side Info', 'tpcore'),
            ]
        );

        $this->add_control(
            'tp_side_logo',
            [
                'label' => esc_html__( 'Side Logo', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );     

        $this->add_control(
            'tp_header_side_intro',
            [
                'label' => esc_html__('Side Intro Text', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Your body LOVE IT. GET THE BEST FOR YOURSELF', 'tpcore'),
                'placeholder' => esc_html__('Type side intro text here', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_design_style' => ['layout-3','layout-7'],
                ],
            ]
        );

        $this->add_control(
            'tp_header_side_label',
            [
                'label' => esc_html__('Side Label', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('we are here', 'tpcore'),
                'placeholder' => esc_html__('Type label text', 'tpcore'),
                'label_block' => true,
            ]
        );        

        $this->add_control(
            'tp_header_side_address',
            [
                'label' => esc_html__('Side Address', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('1489 Langley Ave Grand Forks Afb, North.', 'tpcore'),
                'placeholder' => esc_html__('Type address text', 'tpcore'),
                'label_block' => true,
            ]
        );

		$this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tpcore'),
                'title' => esc_html__('Enter button text', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'tpcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tpcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'tpcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'tp_header_side_social_info',
            [
                'label' => esc_html__('Offcanvas Social Info', 'tpcore'),
            ]
        );
        
		$repeater = new Repeater();

        $repeater->add_control(
            'side_social_name',
            [
                'label' => esc_html__('Profile Name', 'tpcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'select2options' => [
                    'allowClear' => false,
                ],
                'options' => self::get_profile_names()
            ]
        );

        $repeater->add_control(
            'side_social_link', [
                'label' => esc_html__('Side Profile Link', 'tpcore'),
                'placeholder' => esc_html__('Add your profile link', 'tpcore'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'autocomplete' => false,
                'show_external' => false,
                'condition' => [
                    'side_social_name!' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $this->add_control(
            'side_social_profiles',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(side_social_name.slice(0,1).toUpperCase() + side_social_name.slice(1)) #>',
                'default' => [
                    [
                        'side_social_link' => ['url' => 'https://facebook.com/'],
                        'side_social_name' => 'facebook'
                    ],
                    [
                        'side_social_link' => ['url' => 'https://linkedin.com/'],
                        'side_social_name' => 'linkedin'
                    ],
                    [
                        'side_social_link' => ['url' => 'https://twitter.com/'],
                        'side_social_name' => 'twitter'
                    ]
                ],
            ]
        );

        $this->add_control(
            'side_social_show_profiles',
            [
                'label' => esc_html__('Show Social Profiles', 'tpcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'tpcore'),
                'label_off' => esc_html__('Hide', 'tpcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();

        // Review group
        $this->start_controls_section(
            'side_gallery_list',
            [
                'label' => esc_html__( 'Offcanvas Gallery', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-3','layout-7'],
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'side_gallery_image',
            [
                'label' => esc_html__( 'Gallery Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'gallery_list',
            [
                'label' => esc_html__( 'Gallery List', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' =>  $repeater->get_controls(),
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail_size',
                'default' => 'thumbnail',
                'exclude' => ['custom'],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();

	}

    protected function style_tab_content(){
        
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$control_id = 'tpbtn';
        $menus = $this->get_available_menus();

        if ( empty( $menus ) ) {
            return false;
        }

        require_once get_parent_theme_file_path(). '/inc/class-navwalker.php';

        $args = [
            'echo'        => false,
            'menu'        => $settings['menu'],
            'menu_class'  => 'tp-nav-menu',
            'menu_id'     => 'menu-' . $this->get_nav_menu_index() . '-' . $this->get_id(),
            'fallback_cb' => 'vamary_Navwalker_Class::fallback',
            'container'   => '',
            'walker'         => new vamary_Navwalker_Class,
        ];

        $menu_html = wp_nav_menu( $args );

        // group image size
        $size = $settings['tp_image_size_size'];
		if ( 'custom' !== $size ) {
			$image_size = $size;
		} else {
        	require_once ELEMENTOR_PATH . 'includes/libraries/bfi-thumb/bfi-thumb.php';
			$image_dimension = $settings['tp_image_size_custom_dimension'];
			$image_size = [
				// Defaults sizes.
				0           => null, // Width.
				1           => null, // Height.

				'bfi_thumb' => true,
				'crop'      => true,
			];
			$has_custom_size = false;
			if ( ! empty( $image_dimension['width'] ) ) {
				$has_custom_size = true;
				$image_size[0]   = $image_dimension['width'];
			}

			if ( ! empty( $image_dimension['height'] ) ) {
				$has_custom_size = true;
				$image_size[1]   = $image_dimension['height'];
			}

			if ( ! $has_custom_size ) {
				$image_size = 'full';
			}
		}



		// Side Button Link
        if ('2' == $settings['tp_btn_link_type']) {
            $this->add_render_attribute('tp-button-side', 'href', get_permalink($settings['tp_btn_page_link']));
            $this->add_render_attribute('tp-button-side', 'target', '_self');
            $this->add_render_attribute('tp-button-side', 'rel', 'nofollow');
            $this->add_render_attribute('tp-button-side', 'class', 'tp-btn-offcanvas');
        } else {
            if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'tp-button-side', $settings['tp_btn_link'] );
                $this->add_render_attribute('tp-button-side', 'class', 'tp-btn-offcanvas ');
            }
        }



	    if ( !empty($settings['tp_image']['url']) ) {
	        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $image_size, true) : $settings['tp_image']['url'];
	        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
	    }	    

	    if ( !empty($settings['tp_side_logo']['url']) ) {
	        $tp_side_logo = !empty($settings['tp_side_logo']['id']) ? wp_get_attachment_image_url( $settings['tp_side_logo']['id'], $image_size, true) : $settings['tp_side_logo']['url'];
	        $tp_side_logo_alt = get_post_meta($settings["tp_side_logo"]["id"], "_wp_attachment_image_alt", true);
	    }

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ):?>
      <!-- header area start -->
      <header>
         <div class="header__area header-1 theme-bg tp-header-height">
            <div class="header__bottom-wrap theme-bg" id="header-sticky">
               <div class="container">
                  <div class="row align-items-center">
		          	<?php if ( !empty($tp_image) ) : ?>
		             <div class="ol-xxl-3 col-xl-2 col-lg-6 col-md-4 col-6">
		                <div class="logo">
		                   <a href="<?php print esc_url( home_url( '/' ) );?>">
		                      <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
		                   </a>
		                </div>
		             </div>
		             <?php endif; ?>

                     <div class="col-xxl-6 col-xl-7 d-none d-xl-block">
                        <div class="main-menu  menu-position">
                           <nav id="mobile-menu" class="tp-main-menu-content">
                              <?php echo $menu_html; ?>
                           </nav>
                        </div>
                     </div>

                     <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
                     <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-8 col-6">
                        <div class="header__bottom-right d-flex justify-content-end align-items-center">
                           <div class="d-none d-md-block">
                              <div class="header__right d-flex justify-content-end align-items-center">
                              	<?php if ( !empty($settings['tp_header_search_switch']) ) : ?>
                                 <div class="header__search tp-search-toggle">
                                    <i>
                                       <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M10.5 20C15.7467 20 20 15.7467 20 10.5C20 5.25329 15.7467 1 10.5 1C5.25329 1 1 5.25329 1 10.5C1 15.7467 5.25329 20 10.5 20Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M21 21L19 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </i>
                                 </div>
                                 <?php endif; ?>
                                 <?php if ( !empty($settings['tp_header_cart_switch']) ) : ?>
                                 <div class="header__phone">
                                    <a href="tel:0123456789">
                                       <i>
                                          <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M20.97 17.33C20.97 17.69 20.89 18.06 20.72 18.42C20.55 18.78 20.33 19.12 20.04 19.44C19.55 19.98 19.01 20.37 18.4 20.62C17.8 20.87 17.15 21 16.45 21C15.43 21 14.34 20.76 13.19 20.27C12.04 19.78 10.89 19.12 9.75 18.29C8.6 17.45 7.51 16.52 6.47 15.49C5.44 14.45 4.51 13.36 3.68 12.22C2.86 11.08 2.2 9.94 1.72 8.81C1.24 7.67 1 6.58 1 5.54C1 4.86 1.12 4.21 1.36 3.61C1.6 3 1.98 2.44 2.51 1.94C3.15 1.31 3.85 1 4.59 1C4.87 1 5.15 1.06 5.4 1.18C5.66 1.3 5.89 1.48 6.07 1.74L8.39 5.01C8.57 5.26 8.7 5.49 8.79 5.71C8.88 5.92 8.93 6.13 8.93 6.32C8.93 6.56 8.86 6.8 8.72 7.03C8.59 7.26 8.4 7.5 8.16 7.74L7.4 8.53C7.29 8.64 7.24 8.77 7.24 8.93C7.24 9.01 7.25 9.08 7.27 9.16C7.3 9.24 7.33 9.3 7.35 9.36C7.53 9.69 7.84 10.12 8.28 10.64C8.73 11.16 9.21 11.69 9.73 12.22C10.27 12.75 10.79 13.24 11.32 13.69C11.84 14.13 12.27 14.43 12.61 14.61C12.66 14.63 12.72 14.66 12.79 14.69C12.87 14.72 12.95 14.73 13.04 14.73C13.21 14.73 13.34 14.67 13.45 14.56L14.21 13.81C14.46 13.56 14.7 13.37 14.93 13.25C15.16 13.11 15.39 13.04 15.64 13.04C15.83 13.04 16.03 13.08 16.25 13.17C16.47 13.26 16.7 13.39 16.95 13.56L20.26 15.91C20.52 16.09 20.7 16.3 20.81 16.55C20.91 16.8 20.97 17.05 20.97 17.33Z" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                                             <path d="M17.5 8C17.5 7.4 17.03 6.48 16.33 5.73C15.69 5.04 14.84 4.5 14 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                             <path d="M21 8C21 4.13 17.87 1 14 1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                          </svg>
                                       </i>
                                    </a>
                                 </div>
                                 <?php endif; ?>

                                 <?php if ( !empty($settings['tp_phone_number']) ) : ?>
                                 <div class="header__phone">
                                    <a href="tel:<?php echo esc_attr( $settings['tp_phone_url'] ); ?>">
                                       <i>
                                          <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M20.97 17.33C20.97 17.69 20.89 18.06 20.72 18.42C20.55 18.78 20.33 19.12 20.04 19.44C19.55 19.98 19.01 20.37 18.4 20.62C17.8 20.87 17.15 21 16.45 21C15.43 21 14.34 20.76 13.19 20.27C12.04 19.78 10.89 19.12 9.75 18.29C8.6 17.45 7.51 16.52 6.47 15.49C5.44 14.45 4.51 13.36 3.68 12.22C2.86 11.08 2.2 9.94 1.72 8.81C1.24 7.67 1 6.58 1 5.54C1 4.86 1.12 4.21 1.36 3.61C1.6 3 1.98 2.44 2.51 1.94C3.15 1.31 3.85 1 4.59 1C4.87 1 5.15 1.06 5.4 1.18C5.66 1.3 5.89 1.48 6.07 1.74L8.39 5.01C8.57 5.26 8.7 5.49 8.79 5.71C8.88 5.92 8.93 6.13 8.93 6.32C8.93 6.56 8.86 6.8 8.72 7.03C8.59 7.26 8.4 7.5 8.16 7.74L7.4 8.53C7.29 8.64 7.24 8.77 7.24 8.93C7.24 9.01 7.25 9.08 7.27 9.16C7.3 9.24 7.33 9.3 7.35 9.36C7.53 9.69 7.84 10.12 8.28 10.64C8.73 11.16 9.21 11.69 9.73 12.22C10.27 12.75 10.79 13.24 11.32 13.69C11.84 14.13 12.27 14.43 12.61 14.61C12.66 14.63 12.72 14.66 12.79 14.69C12.87 14.72 12.95 14.73 13.04 14.73C13.21 14.73 13.34 14.67 13.45 14.56L14.21 13.81C14.46 13.56 14.7 13.37 14.93 13.25C15.16 13.11 15.39 13.04 15.64 13.04C15.83 13.04 16.03 13.08 16.25 13.17C16.47 13.26 16.7 13.39 16.95 13.56L20.26 15.91C20.52 16.09 20.7 16.3 20.81 16.55C20.91 16.8 20.97 17.05 20.97 17.33Z" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
                                             <path d="M17.5 8C17.5 7.4 17.03 6.48 16.33 5.73C15.69 5.04 14.84 4.5 14 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                             <path d="M21 8C21 4.13 17.87 1 14 1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                          </svg>
                                       </i>
                                    </a>
                                 </div>
                                 <div class="header__contact">
                                    <span><?php echo tp_kses( $settings['tp_phone_label'] ); ?></span>
                                    <a href="tel:<?php echo esc_attr( $settings['tp_phone_url'] ); ?>"><?php echo tp_kses( $settings['tp_phone_number'] ); ?></a>
                                 </div>
                                 <?php endif; ?>
                              </div>
                           </div>
                           <div class="offcanvas-btn d-xl-none ml-20">
                              <button class="offcanvas-open-btn"><i class="fa-solid fa-bars"></i></button>
                           </div>
                        </div>
                     </div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

      <!-- offcanvas area start -->
      <?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-1.php'); ?>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ):
	$this->tp_button_controls_render('tpbtn', 'tp-btn-header-3', $this->get_settings());

?>

      <!-- header area start -->
      <header>
         <div class="transparent__header header__area tp-header-height">
            <div class="header__bottom-wrap header-2" id="header-sticky">
               <div class="container-fluid">
                  <div class="header__area-2 pl-180 pr-180">
                     <div class="row align-items-center">
                     	<?php if ( !empty($tp_image) ) : ?>
                        <div class="col-xxl-3 col-xl-2 col-lg-4 col-md-6 col-6">
                           <div class="logo">
								<a href="<?php print esc_url( home_url( '/' ) );?>">
			                      <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
			                   </a>
                           </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-xxl-5 col-xl-5 col-lg-8 d-none d-xl-block">
                           <div class="main-menu menu-position">
                              <nav id="mobile-menu" class="tp-main-menu-content">
                                 <?php echo $menu_html; ?>
                              </nav>
                           </div>
                        </div>
                        <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
                        <div class="col-xxl-4 col-xl-5 col-lg-8 col-md-6 col-6">
                           <div class="header__bottom-right header__bottom-right-2 d-flex justify-content-end align-items-center">
                              <div class="header__right d-flex justify-content-end align-items-center pt-15">
                              	<?php if (!empty($settings['tp_' . $control_id .'_btn_text']) || $settings['tp_' . $control_id .'_btn_button_show'] == 'yes') : ?>
                                 <div class="header__appoinment d-none d-lg-block">
						            <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>> <?php echo $settings['tp_' . $control_id .'_btn_text']; ?> </a>
                                 </div>
                                 <?php endif; ?>
                                 <?php if ( !empty($settings['tp_header_search_switch']) ) : ?>
                                 <div class="header__search tp-search-toggle d-none d-sm-block">
                                    <i>
                                       <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M10.5 20C15.7467 20 20 15.7467 20 10.5C20 5.25329 15.7467 1 10.5 1C5.25329 1 1 5.25329 1 10.5C1 15.7467 5.25329 20 10.5 20Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M21 21L19 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </i>
                                 </div>
                                 <?php endif; ?>
                                 <div class="header__phone offcanvas-open-btn">
                                    <i>
                                       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M8 4C8 6.20914 6.20914 8 4 8C1.79086 8 0 6.20914 0 4C0 1.79086 1.79086 0 4 0C6.20914 0 8 1.79086 8 4Z" fill="currentColor"/>
                                          <path d="M8 20C8 22.2091 6.20914 24 4 24C1.79086 24 0 22.2091 0 20C0 17.7909 1.79086 16 4 16C6.20914 16 8 17.7909 8 20Z" fill="currentColor"/>
                                          <path d="M24 4C24 6.20914 22.2091 8 20 8C17.7909 8 16 6.20914 16 4C16 1.79086 17.7909 0 20 0C22.2091 0 24 1.79086 24 4Z" fill="currentColor"/>
                                          <path d="M24 20C24 22.2091 22.2091 24 20 24C17.7909 24 16 22.2091 16 20C16 17.7909 17.7909 16 20 16C22.2091 16 24 17.7909 24 20Z" fill="currentColor"/>
                                       </svg>
                                    </i>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

	<!-- offcanvas area start -->
      <?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-2.php'); ?>


<?php elseif ( $settings['tp_design_style']  == 'layout-4' ):
	$this->tp_button_controls_render('tpbtn', 'tp-btn', $this->get_settings());
?>
      <!-- header area start -->
      <header>
         <div class="header__area header-3 tp-header-height">
            <?php if ( !empty($settings['tp_header_top_show']) ) : ?>
            <div class="header__top theme-bg-5 d-none d-md-block">
               <div class="container">
                  <div class="row align-items-center">
                    <?php if ( !empty($settings['tp_header_intro']) ) : ?>
                     <div class="col-xl-6 col-lg-5 col-md-5">
                        <div class="header-top-right">
                           <span><?php echo tp_kses($settings['tp_header_intro']); ?></span>
                        </div>
                     </div>
                     <?php endif; ?>
                     <div class="col-xl-6 col-lg-7 col-md-7">
                        <div class="header__top-right d-flex justify-content-end align-items-center">
                           <div class="header__social">
                              <ul>
                              	<?php if ( !empty($settings['tp_phone_number']) ) : ?>
                                 <li><a href="tel:<?php echo esc_attr( $settings['tp_phone_url'] ); ?>"><i class="fa-light fa-phone"></i> <?php echo tp_kses( $settings['tp_phone_label'] ); ?> <?php echo tp_kses( $settings['tp_phone_number'] ); ?></a></li>
                                 <?php endif; ?>
                                 <?php if ($settings['show_profiles'] && is_array($settings['profiles'])) : ?>
                                    <?php
                                        foreach ($settings['profiles'] as $profile) :
                                            $icon = $profile['name'];
                                            $url = esc_url($profile['link']['url']);
                                            
                                            printf('<li><a target="_blank" rel="noopener"  href="%s" class="tp-el-box-social-link ele-social-button elementor-repeater-item-%s"><i class="fa-brands fa-%s" aria-hidden="true"></i></a></li>',
                                                $url,
                                                esc_attr($profile['_id']),
                                                esc_attr($icon)
                                            );
                                        endforeach; 
                                    ?>
                                 <?php endif; ?>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <?php endif; ?>
            <div class="header__bottom-wrap theme-bg-6" id="header-sticky">
               <div class="container">
                  <div class="header__border-3">
                     <div class="row align-items-center">
                     	<?php if ( !empty($tp_image) ) : ?>
                        <div class="col-xxl-3 col-xl-2 col-lg-6 col-md-6 col-6">
                           <div class="logo">
                              <a href="<?php print esc_url( home_url( '/' ) );?>">
			                      <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
			                   </a>
                           </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-xxl-6 col-xl-7  d-none d-xl-block">
                           <div class="main-menu main-menu-3">
                              <nav id="mobile-menu" class="tp-main-menu-content">
                                 <?php echo $menu_html; ?>
                              </nav>
                           </div>
                        </div>
                        <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
                        <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-6">
                           <div class="header__bottom-right d-flex justify-content-end align-items-center">
                           		<?php if (!empty($settings['tp_' . $control_id .'_btn_text']) || $settings['tp_' . $control_id .'_btn_button_show'] == 'yes') : ?>
                              <div class="header__right d-flex justify-content-end align-items-center">
                                 <div class="header__btn-3 d-none d-md-block">
                                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>> <?php echo $settings['tp_' . $control_id .'_btn_text']; ?> </a>
                                 </div>
                              </div>
                              <?php endif; ?>

                              <div class="offcanvas-btn d-xl-none ml-20">
                                 <button class="offcanvas-open-btn"><i class="fa-solid fa-bars"></i></button>
                              </div>
                           </div>
                        </div>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

      <!-- offcanvas area start -->
      <?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-1.php'); ?>

<?php elseif ( $settings['tp_design_style']  == 'layout-5' ):?>
      <!-- header area start -->
      <header>
         <div class="header__area header-4 tp-header-height">
            <div class="header__bottom transparent__header-4" id="header-sticky">
               <div class="container">
                  <div class="row align-items-center">
                  	<?php if ( !empty($tp_image) ) : ?>
                     <div class="col-xxl-3 col-xl-2 col-lg-6 col-md-6 col-6">
                        <div class="logo">
                           <a href="<?php print esc_url( home_url( '/' ) );?>">
			                      <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
			                </a>      
                        </div>
                     </div>
                     <?php endif; ?>
                     <div class="col-xxl-6 col-xl-7 d-none d-xl-block">
                        <div class="main-menu main-menu-4">
                           <nav id="mobile-menu" class="tp-main-menu-content">
                              <?php echo $menu_html; ?>
                           </nav>
                        </div>
                     </div>
                     <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
                     <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-6">
                        <div class="header__bottom-right d-flex justify-content-end align-items-center">
                           <div class="d-none d-sm-block">
                              <div class="header__right header-3__right header__opacity d-flex justify-content-end align-items-center">
                              	<?php if ( !empty($settings['tp_header_search_switch']) ) : ?>
                                 <button class="tp-search-toggle">
                                    <span>
                                       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </span>
                                 </button>
                                 <?php endif; ?>
                                 <?php if ( !empty($settings['tp_header_wishlist_switch']) ) : ?>
                                 <a href="<?php echo esc_url($settings['tp_wishlist_url']); ?>">
                                    <span>
                                       <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M11.62 18.8096C11.28 18.9296 10.72 18.9296 10.38 18.8096C7.48 17.8196 1 13.6896 1 6.68961C1 3.59961 3.49 1.09961 6.56 1.09961C8.38 1.09961 9.99 1.97961 11 3.33961C12.01 1.97961 13.63 1.09961 15.44 1.09961C18.51 1.09961 21 3.59961 21 6.68961C21 13.6896 14.52 17.8196 11.62 18.8096Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </span>
                                 </a>
                                 <?php endif; ?>
                                 <?php if ( !empty($settings['tp_header_cart_switch']) ) : ?>
                                 <div class="cart-list-wrap">
                                    <a href="<?php echo wc_get_cart_url(); ?>" class="cart-list-wrapper">
                                       <span>
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M8.81141 2L5.19141 5.63" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                             <path d="M15.1914 2L18.8114 5.63" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                             <path d="M2 7.84961C2 5.99961 2.99 5.84961 4.22 5.84961H19.78C21.01 5.84961 22 5.99961 22 7.84961C22 9.99961 21.01 9.84961 19.78 9.84961H4.22C2.99 9.84961 2 9.99961 2 7.84961Z" stroke="currentColor" stroke-width="1.5"/>
                                             <path d="M9.76172 14V17.55" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                             <path d="M14.3594 14V17.55" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                             <path d="M3.5 10L4.91 18.64C5.23 20.58 6 22 8.86 22H14.89C18 22 18.46 20.64 18.82 18.76L20.5 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                          </svg>                                       
                                       </span>
                                    </a>
                                 </div>
                                 <?php endif; ?>
                              </div>
                           </div>
                           <div class="offcanvas-btn header__offcanvas-btn d-xl-none ml-20">
                              <button class="offcanvas-open-btn"><i class="fa-solid fa-bars"></i></button>
                           </div>
                        </div>
                     </div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

      <!-- offcanvas area start -->
      <?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-1.php'); ?>

<?php elseif ( $settings['tp_design_style']  == 'layout-6' ):
    if ( !empty($settings['tp_btn_image']['url']) ) {
        $tp_btn_image = !empty($settings['tp_btn_image']['id']) ? wp_get_attachment_image_url( $settings['tp_btn_image']['id'], 'full') : $settings['tp_btn_image']['url'];
        $tp_btn_image_alt = get_post_meta($settings["tp_btn_image"]["id"], "_wp_attachment_image_alt", true);
    }

    $this->tp_button_controls_render('tpbtn', 'need-help d-none d-md-block', $this->get_settings());
?>
      <!-- header area start -->
      <header>
         <div class="header__area tp-header-height">
            <div class="header__bottom-wrap header-5 tpbanner-4" id="header-sticky">
               <div class="container">
                  <div class="header-5-border">
                     <div class="row align-items-center">
                    <?php if ( !empty($tp_image) ) : ?>
                     <div class="col-xxl-3 col-xl-2 col-lg-6 col-md-4 col-6">
                        <div class="logo">
                           <a href="<?php print esc_url( home_url( '/' ) );?>">
                                  <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
                            </a>      
                        </div>
                     </div>
                     <?php endif; ?>

                        <div class="col-xxl-5 col-xl-6 col-lg-8 d-none d-xl-block">
                           <div class="main-menu main-menu-5 main-menu-4">
                              <nav id="mobile-menu" class="tp-main-menu-content">
                                 <?php echo $menu_html; ?>
                              </nav>
                           </div>
                        </div>
                        <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
                        <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-8 col-6">
                           <div class="header__bottom-right d-flex justify-content-end align-items-center">
                              <div class="header__right header-5__right header__opacity d-flex justify-content-end align-items-center">
                                 <?php if ( !empty($settings['tp_header_search_switch']) ) : ?>
                                 <button class="tp-search-toggle d-none d-sm-block">
                                    <span>
                                       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </span>
                                 </button>
                                 <?php endif; ?>
                                 <?php if ( !empty($settings['tp_header_wishlist_switch']) ) : ?>
                                 <a class="d-none d-sm-block" href="<?php echo esc_url($settings['tp_wishlist_url']); ?>">
                                    <span>
                                       <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M11.62 18.8096C11.28 18.9296 10.72 18.9296 10.38 18.8096C7.48 17.8196 1 13.6896 1 6.68961C1 3.59961 3.49 1.09961 6.56 1.09961C8.38 1.09961 9.99 1.97961 11 3.33961C12.01 1.97961 13.63 1.09961 15.44 1.09961C18.51 1.09961 21 3.59961 21 6.68961C21 13.6896 14.52 17.8196 11.62 18.8096Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </span>
                                 </a>
                                 <?php endif; ?>
                                 <?php if (!empty($settings['tp_' . $control_id .'_btn_text']) || $settings['tp_' . $control_id .'_btn_button_show'] == 'yes') : ?>
                                 <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                                    <?php if ( !empty($tp_btn_image) ) : ?>
                                    <img src="<?php echo esc_url($tp_btn_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
                                    <?php endif; ?>
                                    <span>
                                       <?php echo $settings['tp_' . $control_id .'_btn_text']; ?>                                       
                                    </span>
                                 </a>
                                 <?php endif; ?>
                              </div>
                              <div class="offcanvas-btn offcanvas-btn-5 d-xl-none ml-20">
                                 <button class="offcanvas-open-btn "><i class="fa-solid fa-bars"></i></button>
                              </div>
                           </div>
                        </div>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

      <!-- offcanvas area start -->
      <?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-1.php'); ?>

<?php elseif ( $settings['tp_design_style']  == 'layout-7' ):?>

      <!-- header area start -->
      <header>
         <div class="header__area header-7">
            <?php if ( !empty($settings['tp_header_top_show']) ) : ?>
            <div class="header__top theme-bg-8 d-none d-lg-block">
               <div class="container-fluid">
                  <div class="row">
                    <?php if ( !empty($settings['tp_header_intro']) ) : ?>
                     <div class="col-xl-6 col-lg-6">
                        <div class="header__top-content">
                           <span><?php echo tp_kses($settings['tp_header_intro']); ?></span>
                        </div>
                     </div>
                     <?php endif; ?>
                     <div class="col-xl-6 col-lg-6">
                        <div class="header__top-content text-end">
                            <?php if ( !empty($settings['tp_phone_number']) ) : ?>
                           <a href="tel:<?php echo esc_attr( $settings['tp_phone_url'] ); ?>">
                              <span>
                                 <svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M11.9609 1.08301C15.0451 1.42551 17.4818 3.85884 17.8276 6.94301" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M11.9609 4.03516C13.4368 4.32182 14.5901 5.47599 14.8776 6.95182" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M9.19424 9.39333C12.5184 12.7166 13.2725 8.87194 15.389 10.987C17.4295 13.027 18.6031 13.4357 16.017 16.0203C15.6932 16.2805 13.6357 19.4116 6.40502 12.1827C-0.826536 4.95301 2.30261 2.89338 2.56292 2.56963C5.15444 -0.0221207 5.55699 1.15749 7.59746 3.19745C9.71308 5.31342 5.87008 6.07002 9.19424 9.39333Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                              </span>
                              <?php echo tp_kses( $settings['tp_phone_number'] ); ?>
                           </a>
                           <?php endif; ?>

                           <?php if ( !empty($settings['tp_email_id']) ) : ?>
                           <a href="mailto:<?php echo esc_attr( $settings['tp_email_url'] ); ?>">
                              <span>
                                 <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.9217 6.37598L11.219 9.38684C10.5194 9.94184 9.53513 9.94184 8.83555 9.38684L5.10156 6.37598" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M14.092 16.5C16.6265 16.507 18.3346 14.4246 18.3346 11.8653V6.14168C18.3346 3.58235 16.6265 1.5 14.092 1.5H5.91058C3.37612 1.5 1.66797 3.58235 1.66797 6.14168V11.8653C1.66797 14.4246 3.37612 16.507 5.91058 16.5H14.092Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                 </svg>
                              </span>
                              <?php echo tp_kses( $settings['tp_email_id'] ); ?>
                           </a>
                           <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <?php endif; ?>
            <div class="header__bottom theme-bg-8 header-7-sticky" id="header-sticky">
               <div class="container-fluid p-0">
                  <div class="row gx-0 align-items-center">
                  	<?php if ( !empty($tp_image) ) : ?>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-8">
                        <div class="logo">
                           <a href="<?php print esc_url( home_url( '/' ) );?>">
			                      <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
			                </a>      
                        </div>
                     </div>
                     <?php endif; ?>

                     <div class="col-xl-6  d-none d-xl-block">
                        <div class="main-menu menu-6 text-center">
                           <nav id="mobile-menu" class="tp-main-menu-content">
                              <?php echo $menu_html; ?>
                           </nav>
                        </div>
                     </div>
                     <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
                     <div class="col-xl-3 col-lg-8 col-md-6 col-4">
                        <div class="header__bottom-right d-flex justify-content-end align-items-center">
                           <div class="header__right header-3__right header__opacity d-flex justify-content-end align-items-center">
                              <?php if ( !empty($settings['tp_header_search_switch']) ) : ?>
                              <button class="tp-search-toggle d-none d-md-block">
                                 <span>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       <path d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                 </span>
                              </button>
                              <?php endif; ?>
                              <?php if ( !empty($settings['tp_header_cart_switch']) ) : ?>
                              <div class="cart-7 d-none d-sm-block">
                                 <div class="cart-list-wrap">
                                    <a href="<?php echo wc_get_cart_url(); ?>" class="cart-list-wrapper">
                                       <span>
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M8.81141 2L5.19141 5.63" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                             <path d="M15.1914 2L18.8114 5.63" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                             <path d="M2 7.84961C2 5.99961 2.99 5.84961 4.22 5.84961H19.78C21.01 5.84961 22 5.99961 22 7.84961C22 9.99961 21.01 9.84961 19.78 9.84961H4.22C2.99 9.84961 2 9.99961 2 7.84961Z" stroke="currentColor" stroke-width="1.5"/>
                                             <path d="M9.76172 14V17.55" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                             <path d="M14.3594 14V17.55" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                             <path d="M3.5 10L4.91 18.64C5.23 20.58 6 22 8.86 22H14.89C18 22 18.46 20.64 18.82 18.76L20.5 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                          </svg>                                       
                                       </span>
                                    </a>
                                 </div>
                              </div>
                              <?php endif; ?>
                              <button class="offcanvas-open-btn offcanvas-open-btn-7">
                                 <span>
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M6.65741 3.7037C6.65741 5.33499 5.33499 6.65741 3.7037 6.65741C2.07242 6.65741 0.75 5.33499 0.75 3.7037C0.75 2.07242 2.07242 0.75 3.7037 0.75C5.33499 0.75 6.65741 2.07242 6.65741 3.7037ZM6.65741 20C6.65741 21.6313 5.33499 22.9537 3.7037 22.9537C2.07242 22.9537 0.75 21.6313 0.75 20C0.75 18.3687 2.07242 17.0463 3.7037 17.0463C5.33499 17.0463 6.65741 18.3687 6.65741 20ZM6.65741 36.2963C6.65741 37.9276 5.33499 39.25 3.7037 39.25C2.07242 39.25 0.75 37.9276 0.75 36.2963C0.75 34.665 2.07242 33.3426 3.7037 33.3426C5.33499 33.3426 6.65741 34.665 6.65741 36.2963ZM22.9537 3.7037C22.9537 5.33499 21.6313 6.65741 20 6.65741C18.3687 6.65741 17.0463 5.33499 17.0463 3.7037C17.0463 2.07242 18.3687 0.75 20 0.75C21.6313 0.75 22.9537 2.07242 22.9537 3.7037ZM39.25 3.7037C39.25 5.33499 37.9276 6.65741 36.2963 6.65741C34.665 6.65741 33.3426 5.33499 33.3426 3.7037C33.3426 2.07242 34.665 0.75 36.2963 0.75C37.9276 0.75 39.25 2.07242 39.25 3.7037ZM22.9537 20C22.9537 21.6313 21.6313 22.9537 20 22.9537C18.3687 22.9537 17.0463 21.6313 17.0463 20C17.0463 18.3687 18.3687 17.0463 20 17.0463C21.6313 17.0463 22.9537 18.3687 22.9537 20ZM22.9537 36.2963C22.9537 37.9276 21.6313 39.25 20 39.25C18.3687 39.25 17.0463 37.9276 17.0463 36.2963C17.0463 34.665 18.3687 33.3426 20 33.3426C21.6313 33.3426 22.9537 34.665 22.9537 36.2963ZM39.25 20C39.25 21.6313 37.9276 22.9537 36.2963 22.9537C34.665 22.9537 33.3426 21.6313 33.3426 20C33.3426 18.3687 34.665 17.0463 36.2963 17.0463C37.9276 17.0463 39.25 18.3687 39.25 20ZM39.25 36.2963C39.25 37.9276 37.9276 39.25 36.2963 39.25C34.665 39.25 33.3426 37.9276 33.3426 36.2963C33.3426 34.665 34.665 33.3426 36.2963 33.3426C37.9276 33.3426 39.25 34.665 39.25 36.2963Z" stroke="white" stroke-width="1.5"/>
                                       </svg>
                                 </span>
                              </button>
                           </div>
                        </div>
                     </div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

      <!-- offcanvas area start -->
      <?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-2.php'); ?>
<?php else: ?>

<!-- header area start -->
<header>
 <div class="header__area header-6">
    <?php if ( !empty($settings['tp_header_top_show']) ) : ?>
    <div class="header__top theme-bg">
       <div class="container">
          <div class="row">
             <div class="col-lg-12">
                <?php if ( !empty($settings['tp_header_intro']) ) : ?>
                <div class="header__top-content text-center">
                   <span><?php echo tp_kses($settings['tp_header_intro']); ?></span>
                </div>
                <?php endif; ?>
             </div>
          </div>
       </div>
    </div>
    <?php endif; ?>


    <div class="header__bottom" id="header-sticky">
       <div class="container">
          <div class="row align-items-center">
          	<?php if ( !empty($tp_image) ) : ?>
             <div class="col-xxl-3 col-xl-2 col-lg-6 col-md-6 col-6">
                <div class="logos">
                   <a href="<?php print esc_url( home_url( '/' ) );?>">
                      <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
                   </a>
                </div>
             </div>
             <?php endif; ?>
             <div class="col-xxl-7 col-xl-8 d-none d-xl-block">
                <div class="main-menu menu-position">
                   <nav id="mobile-menu" class="tp-main-menu-content">
                      <?php echo $menu_html; ?>
                   </nav>
                </div>
             </div>

             <?php if ( !empty($settings['tp_header_right_switch']) ) : ?>
             <div class="col-xxl-2 col-xl-2 col-lg-6 col-md-6 col-6">
                <div class="header__bottom-right d-flex justify-content-end align-items-center">
                   <div class="d-none d-sm-block">
                      <div class="header__right header-3__right header__opacity d-flex justify-content-end align-items-center">
                         <?php if ( !empty($settings['tp_header_search_switch']) ) : ?>
                         <button class="tp-search-toggle">
                            <span>
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                  <path d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                               </svg>
                            </span>
                         </button>
                         <?php endif; ?>

                         <?php if ( !empty($settings['tp_header_wishlist_switch']) ) : ?>
                         <a href="<?php echo esc_url($settings['tp_wishlist_url']); ?>">
                            <span>
                               <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M11.62 18.8096C11.28 18.9296 10.72 18.9296 10.38 18.8096C7.48 17.8196 1 13.6896 1 6.68961C1 3.59961 3.49 1.09961 6.56 1.09961C8.38 1.09961 9.99 1.97961 11 3.33961C12.01 1.97961 13.63 1.09961 15.44 1.09961C18.51 1.09961 21 3.59961 21 6.68961C21 13.6896 14.52 17.8196 11.62 18.8096Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                               </svg>
                            </span>
                         </a>
                         <?php endif; ?>

                         <?php if ( !empty($settings['tp_header_cart_switch']) ) : ?>
                         <div class="cart-list-wrap">
                            <a href="<?php echo wc_get_cart_url(); ?>" class="cart-list-wrapper">
                               <span>
                                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                     <path d="M8.81141 2L5.19141 5.63" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                     <path d="M15.1914 2L18.8114 5.63" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                     <path d="M2 7.84961C2 5.99961 2.99 5.84961 4.22 5.84961H19.78C21.01 5.84961 22 5.99961 22 7.84961C22 9.99961 21.01 9.84961 19.78 9.84961H4.22C2.99 9.84961 2 9.99961 2 7.84961Z" stroke="currentColor" stroke-width="1.5"/>
                                     <path d="M9.76172 14V17.55" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                     <path d="M14.3594 14V17.55" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                     <path d="M3.5 10L4.91 18.64C5.23 20.58 6 22 8.86 22H14.89C18 22 18.46 20.64 18.82 18.76L20.5 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                  </svg>                                       
                               </span>
                            </a>
                         </div>
                         <?php endif; ?>
                      </div>
                   </div>
                   <div class="offcanvas-btn header__offcanvas-btn d-xl-none ml-20">
                      <button class="offcanvas-open-btn"><i class="fa-solid fa-bars"></i></button>
                   </div>
                </div>
             </div>
             <?php endif; ?>
          </div>
       </div>
    </div>
 </div>
</header>
<!-- header area end -->
<?php include(TPCORE_ELEMENTS_PATH . '/header-side/header-side-1.php'); ?>




<?php endif; 
	}
}

$widgets_manager->register( new TP_Header_01() );
