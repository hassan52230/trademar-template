<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Service_One extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-service-one';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Service One', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__( 'Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'List Content' , 'tpcore' ),
                'show_label' => false,
            ]
        );

        $repeater->add_control(
            'list_image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

         $repeater->add_control(
            'list_link',
            [
                'label' => esc_html__( 'Link', 'tpcore' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_icon',
            [
                'label' => esc_html__( 'Icon', 'tpcore' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-circle',
                    'library' => 'fa-solid',
                ],
                'recommended' => [
                    'fa-solid' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                    'fa-regular' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                ],
            ]
        );


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                        
                    ],
                    [
                        'list_title' => esc_html__( 'Title #2', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ], 
                    [
                        'list_title' => esc_html__( 'Title #3', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Title #3', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Title #3', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-block_one-heading' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_four-heading' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_five-heading' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .service-block_one-heading',
                'selector' => '{{WRAPPER}} .service-block_four-heading',
                'selector' => '{{WRAPPER}} .service-block_five-heading',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-block_one-text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_four-text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_five-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .service-block_one-text p',
                'selector' => '{{WRAPPER}} .service-block_four-text p',
                'selector' => '{{WRAPPER}} .service-block_five-text p',
            ]
        );


        $this->end_controls_section();


        

    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $pattern_shape = $settings['image']['url'];


     ?>
    <?php if ($settings['design_style'] == 'layout-1') { ?> 
    <section class="services-one">
        <div class="auto-container">
            <div class="services-one_carousel swiper-container">
                <div class="swiper-wrapper">
                    <?php foreach (  $settings['list'] as $key => $item ) : ?>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <!-- Service Block One -->
                        <div class="service-block_one">
                            <div class="service-block_one-inner">
                                <div class="service-block_one-hover"></div>
                                <div class="service-block_one_pattern" style="background-image:url(<?php echo $pattern_shape; ?>)"></div>
                                <div class="service-block_one-background"></div>
                                <div class="service-block_one-icon">
                                    <i class="<?php echo esc_attr ( $item['list_icon']['value'] ); ?>"></i>
                                </div>
                                <h4 class="service-block_one-heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_title']; ?></a></h4>
                                <div class="service-block_one-text"><?php echo $item['list_content']; ?></div>
                            </div>
                        </div>
                    </div>
                   <?php endforeach ; ?>
                </div>
                <!-- Slider One Arrows -->
                <div class="services-one-arrow">
                    <!-- If we need navigation buttons -->
                    <div class="services-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                    <div class="services-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
                </div>
                <div class="services-one_carousel-pagination"></div>
            </div>

        </div>
    </section>
    <?php } elseif ($settings['design_style'] == 'layout-2') { ?>
    <section class="services-four">
        <div class="auto-container">
            <div class="services-one_carousel swiper-container">
                <div class="swiper-wrapper">
                <?php foreach (  $settings['list'] as $key => $item ) : ?>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <!-- Service Block Four -->
                        <div class="service-block_four">
                            <div class="service-block_four-inner">
                                <h4 class="service-block_four-heading"><?php echo $item['list_title']; ?></h4>
                                <div class="service-block_four-text"><?php echo $item['list_content']; ?></div>
                                <div class="service-block_four-icon">
                                    <i class="<?php echo esc_attr ( $item['list_icon']['value'] ); ?>"></i>
                                </div>
                                <div class="service-block_four-number">0<?php echo $key + 1; ?></div>
                                <div class="service-block_four-overlay">
                                    <div class="service-block_four-overlay_number">0<?php echo $key + 1; ?></div>
                                    <div class="service-block_four-overlay_icon">
                                        <i class="<?php echo esc_attr ( $item['list_icon']['value'] ); ?>"></i>
                                    </div>
                                    <h4 class="service-block_four-heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_title']; ?></a></h4>
                                    <div class="service-block_four-text_two"><?php echo $item['list_content']; ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach ; ?>
                </div>

                <!-- Slider One Arrows -->
                <div class="services-one-arrow">
                    <!-- If we need navigation buttons -->
                    <div class="services-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                    <div class="services-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
                </div>
                <div class="services-one_carousel-pagination"></div>

            </div>
            
        </div>
    </section>
   
    <?php } else { ?> 
     <section class="services-five">
        <div class="auto-container">
            <div class="four-item_carousel swiper-container">
                <div class="swiper-wrapper">
                    <?php foreach (  $settings['list'] as $key => $item ) : ?>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <!-- Service Block Five -->
                        <div class="service-block_five">
                            <div class="service-block_five-inner">
                                <div class="service-block_five-image">
                                    <img src="<?php echo $item['list_image']['url']; ?>" alt="shape" />
                                    <div class="service-block_five-content">
                                        <div class="service-block_five-icon">
                                            <i class="<?php echo esc_attr ( $item['list_icon']['value'] ); ?>"></i>
                                        </div>
                                        <h5 class="service-block_five-heading"><?php echo $item['list_title']; ?></h5>
                                    </div>
                                    <div class="service-block_five-overlay" style="background-image:url(<?php echo $pattern_shape; ?>)">
                                        <div class="service-block_five-overlay_inner">
                                            <div class="service-block_five-icon_two">
                                                <i class="icon-controlxpert_svgrepocom-3"></i>
                                            </div>
                                            <h4 class="service-block_five-overlay_heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_title']; ?></a></h4>
                                            <div class="service-block_five-text"><?php echo $item['list_content']; ?></div>
                                            <a class="service-block_five-more" href="<?php echo $item['list_link']['url']; ?>">Read More<i class="fa-solid fa-angle-right fa-fw"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach ; ?>
                </div>

                <!-- History One Arrows -->
                <div class="services-five-arrow">
                    <!-- If we need navigation buttons -->
                    <div class="four-item_carousel-prev fa-solid fa-angle-left fa-fw"></div>
                    <div class="four-item_carousel-next fa-solid fa-angle-right fa-fw"></div>
                </div>
                <div class="four-item_carousel-pagination"></div>

            </div>
        </div>
    </section>
    <?php } ?>
    
     <?php
    }
}

$widgets_manager->register( new TP_Service_One() );



