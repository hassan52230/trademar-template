<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Blog extends Widget_Base {

	use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
    	return 'tp-blog';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
    	return __( 'Blog', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
    	return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
    	return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
    	return [ 'tpcore'];
    }


   /**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

   protected function register_controls() {

   	$this->start_controls_section(
   		'layout',
   		[
   			'label' => esc_html__('Design Layout', 'tpcore'),
   		]
   	);
   	$this->add_control(
   		'design_style',
   		[
   			'label' => esc_html__('Select Layout', 'tpcore'),
   			'type' => Controls_Manager::SELECT,
   			'options' => [
   				'layout-1' => esc_html__('Layout 1', 'tpcore'),
   				'layout-2' => esc_html__('Layout 2', 'tpcore'),
   				'layout-3' => esc_html__('Layout 3', 'tpcore'),
   			],
   			'default' => 'layout-1',
   		]
   	);

   	$this->end_controls_section();


   }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$args = array(
			'posts_per_page'   => 6,
			'post_type'        => 'post',
			 'order'		   => 'DESC',
		);
		$the_query = new \WP_Query( $args );

		?>
		<?php if( $settings['design_style'] == 'layout-1') { ?>
			<section class="news-one">
				<div class="auto-container">
					<div class="news-one_carousel swiper-container">
						<div class="swiper-wrapper">

							<?php if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
								global $post;
								$categories = get_the_category($post->ID);
								$commentcount = get_comments_number( $post->ID );
								$imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
								?>

								<div class="swiper-slide">
									<!-- News Block -->
									<div class="news-block_one">
										<div class="news-block_one-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
											<div class="news-block_one-image">
												<div class="news-block_one-date"><?php echo get_the_date('j'); ?> <span><?php echo get_the_date('M, Y'); ?></span></div>
												<a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo esc_url($imgSrc); ?>" alt="" /></a>
											</div>
											<div class="news-block_one-content">
												<ul class="news-block_one-meta d-flex align-items-center flex-wrap">
													<li><span class="icon fa-regular fa-user fa-fw"></span><?php echo esc_html($categories[0]->name); ?></li>
													<li><span class="icon fa-regular fa-comment-dots fa-fw"></span><?php echo $commentcount; ?> Comments</li>
												</ul>
												<h4 class="news-block_one-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
												<a class="news-block_one-more" href="<?php echo get_the_permalink(); ?>">read more<i class="fa-solid fa-angle-right fa-fw"></i></a>
											</div>
										</div>
									</div>
								</div>

							<?php endwhile; wp_reset_query(); endif; ?>

						</div>

						<!-- News One Arrows -->
						<div class="news-one-arrow">
							<!-- If we need navigation buttons -->
							<div class="news-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
							<div class="news-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
						</div>
						<div class="news-one_carousel-pagination"></div>

					</div>

				</div>
			</section>
		<?php } elseif ( $settings['design_style'] == 'layout-2' ) { ?>
			<section class="news-two">
				<div class="auto-container">
					<div class="row clearfix">
						<?php 
						$args = array(
			'posts_per_page'   => 3,
			'post_type'        => 'post',
		);
		$the_query = new \WP_Query( $args );
						if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
							global $post;
							$categories = get_the_category($post->ID);
							$commentcount = get_comments_number( $post->ID );
							$imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
							$user = wp_get_current_user();
							?>
							<!-- News Block Two -->
							<div class="news-block_two col-lg-4 col-md-6 col-sm-12">
								<div class="news-block_two-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
									<div class="news-block_two-image">
										<a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo esc_url($imgSrc); ?>" alt="" /></a>
									</div>
									<div class="news-block_two-content">
										<div class="news-block_two-date"><i class="icon-date_svgrepocom"></i> <?php echo get_the_date('M j, Y'); ?></div>
										<h4 class="news-block_two-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
										<div class="news-block_two-author">
											<div class="news-block_two-author-image">
												<img src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?> "/>" alt="" />
											</div>
											<i>By</i> <?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?>
										</div>
									</div>
								</div>
							</div>
						<?php endwhile; wp_reset_query(); endif; ?>
					</div>
				</div>
			</section>
		<?php } else { ?>
			<section class="news-one">
				<div class="auto-container">
					<div class="row clearfix">
						<div class="column col-lg-6">
							<?php
							$args = array(
								'posts_per_page'   => 1,
								'post_type'        => 'post',
							);
							$the_query = new \WP_Query( $args );
							if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
								global $post;
								$categories = get_the_category($post->ID);
								$commentcount = get_comments_number( $post->ID );
								$imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
								$user = wp_get_current_user();
								function reading_time() {
									$content = get_post_field( 'post_content', get_the_ID('ID') );
									$word_count = str_word_count( strip_tags( $content ) );
									$readingtime = ceil($word_count / 200);

									if ($readingtime == 1) {
										$timer = " minute";
									} else {
										$timer = " minutes";
									}
									$totalreadingtime = $readingtime . $timer;

									return $totalreadingtime;
								}
								?>

								<!-- News Block Three -->
								<div class="news-block_three">
									<div class="news-block_three-inner">
										<div class="news-block_three-image">
											<img src="<?php echo esc_url($imgSrc); ?>" alt="" />
											<div class="news-block_three-content">
												<h4 class="news-block_three-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
												<div class="news-block_three-author d-flex align-items-center flex-wrap">
													<div class="news-block_three-author-image">
														<img src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="" />
													</div>
													<i>By</i> <?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?>
													<span><?php echo reading_time(); ?> Read</span>
												</div>
											</div>
										</div>
									</div>
								</div>

							<?php endwhile; wp_reset_query(); endif; ?>
						</div>
						<!-- Column -->
						<div class="column col-lg-6">
							<?php 
							$args = array(
								'posts_per_page'   => 3,
								'post_type'        => 'post',
							);
							$the_query = new \WP_Query( $args );
							if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
								global $post;
								$categories = get_the_category($post->ID);
								$commentcount = get_comments_number( $post->ID );
								$imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
								$user = wp_get_current_user();
								?>
								<!-- News Block Four -->
								<div class="news-block_four">
									<div class="news-block_four-inner d-flex align-items-center flex-wrap">
										<div class="news-block_four-image">
											<a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo esc_url($imgSrc); ?>" alt="" /></a>
										</div>
										<div class="news-block_four-content">
											<h4 class="news-block_four-heading"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
											<div class="news-block_four-author d-flex align-items-center flex-wrap">
												<div class="news-block_four-author-image">
													<img src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="" />
												</div>
												<i>By</i> <?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?>
												<span><?php echo reading_time(); ?> Read</span>
											</div>
										</div>
									</div>
								</div>
								<?php endwhile; wp_reset_query(); endif; ?>
							</div>
						</div>
					</div>
				</section>
			<?php } ?>


			<?php
		}
	}

	$widgets_manager->register( new TP_Blog() );












