<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Instagram extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-instagram';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Instagram List ', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


        // brand section
		$this->start_controls_section(
            'tp_brand_section',
            [
                'label' => __( 'Instagram Item', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'tp_brand_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'tpcore' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'tp_brand_slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => esc_html__( 'Brand Item', 'tpcore' ),
                'default' => [
                    [
                        'tp_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'tp_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
	}


    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('brand_section', 'Section Style', '.ele-section');
        $this->tp_basic_style_controls('brand_sub_title', 'Sub Heading Style', '.ele-sub-heading');
        $this->tp_basic_style_controls('brand_title', 'Heading Style', '.ele-heading');
        $this->tp_basic_style_controls('brand_des', 'Content Style', '.ele-description');

        $this->tp_basic_style_controls('brand_subs_sub_title', 'Subscriber Sub Title Style', '.ele-subs-sub-title');
        $this->tp_basic_style_controls('brand_subs_title', 'Subscriber Title Style', '.ele-subs-title');
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'tpsection-title ele-heading');
?>

         <div class="section instagram-area theme-bg-6 pt-20 pb-80">
            <div class="instagram-3-active splide">
               <div class="splide__track">
                  <div class="splide__list">
                    <?php foreach ($settings['tp_brand_slides'] as $item) :
                        if ( !empty($item['tp_brand_image']['url']) ) {
                            $tp_brand_image_url = !empty($item['tp_brand_image']['id']) ? wp_get_attachment_image_url( $item['tp_brand_image']['id'], $settings['thumbnail_size']) : $item['tp_brand_image']['url'];
                            $tp_brand_image_alt = get_post_meta($item["tp_brand_image"]["id"], "_wp_attachment_image_alt", true);
                        }
                    ?>
                     <div class="splide__slide">
                        <div class="instagram-item">
                           <a class="popup-image" href="<?php echo esc_url($tp_brand_image_url); ?>">
                              <img src="<?php echo esc_url($tp_brand_image_url); ?>"
                        alt="<?php echo esc_url($tp_brand_image_alt); ?>">
                           </a>
                        </div>
                     </div>
                    <?php endforeach; ?>  
                  </div>
               </div>
            </div>
         </div>


<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : 
    $this->add_render_attribute('title_args', 'class', 'tp-section__title ele-heading');
?>


<?php else : 
    $this->add_render_attribute('title_args', 'class', 'award__title-4 tp-el-title');
?>

 <section class="brand-slider-area ele-section">
    <div class="brand-slider-wrap">
       <div class="brand-slide-active splide">
          <div class="splide__track">
             <div class="splide__list">
                <?php foreach ($settings['tp_brand_slides'] as $item) :
                    if ( !empty($item['tp_brand_image']['url']) ) {
                        $tp_brand_image_url = !empty($item['tp_brand_image']['id']) ? wp_get_attachment_image_url( $item['tp_brand_image']['id'], $settings['thumbnail_size']) : $item['tp_brand_image']['url'];
                        $tp_brand_image_alt = get_post_meta($item["tp_brand_image"]["id"], "_wp_attachment_image_alt", true);
                    }
                ?>
                <div class="splide__slide">
                   <div class="brand-slider-item">
                      <h4 class="brand-slider-title"> 
                        <i><img src="<?php echo esc_url($tp_brand_image_url); ?>"
                        alt="<?php echo esc_url($tp_brand_image_alt); ?>"></i> 
                        <a href="<?php echo esc_url($item['tp_brand_url']); ?>"><?php echo tp_kses($item['tp_brand_title']); ?></a> </h4>
                   </div>
                </div>
                <?php endforeach; ?>    
             </div>
          </div>
       </div>
    </div>
 </section>


<?php endif; 
       
	}


}

$widgets_manager->register( new TP_Instagram() );