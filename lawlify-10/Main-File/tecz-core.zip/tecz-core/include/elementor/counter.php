<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Counter extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-counter';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Counter', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    }


    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls_section() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_number',
            [
                'label' => esc_html__( 'Number', 'tpcore' ),
                'type' => Controls_Manager::NUMBER,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'List Content' , 'tpcore' ),
                'show_label' => false,
            ]
        );


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'Title 01', 'tpcore' ),
                        'list_content' => esc_html__( 'Years of Experienced', 'tpcore' ),
                        
                    ],
                    [
                        'list_title' => esc_html__( 'Title 01', 'tpcore' ),
                        'list_content' => esc_html__( 'Total Completed Case', 'tpcore' ),
                    ], 
                    [
                        'list_title' => esc_html__( 'Title 01', 'tpcore' ),
                        'list_content' => esc_html__( 'Happy Customers', 'tpcore' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Title 01', 'tpcore' ),
                        'list_content' => esc_html__( 'Case Success Rate', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-one_counter-heading' => 'color: {{VALUE}}',
                ],
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .counter-one_counter-heading',
            ]
        );


        $this->end_controls_section();


        

    }

    protected function style_tab_content(){
        $this->tp_basic_style_controls('footer_title', 'Title Style', '.tp-el-title');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

     ?>

     <section class="counter-one">
        <div class="auto-container">
            <div class="row clearfix">
                <?php foreach (  $settings['list'] as $key => $item ) : ?>
                <!-- Column -->
                <div class="counter-one_column col-lg-3 col-md-6 col-sm-12">
                    <div class="counter-one_column-outer">
                        <span class="counter odometer" data-count="<?php echo $item['list_number']; ?>"></span><i>+</i>
                        <h5 class="counter-one_counter-heading"><?php echo $item['list_content']; ?></h5>
                    </div>
                </div>
                <?php endforeach ; ?>

            </div>
        </div>
    </section>
    
     <?php
    }
}

$widgets_manager->register( new TP_Counter() );



