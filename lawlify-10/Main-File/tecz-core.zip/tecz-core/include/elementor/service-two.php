<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Service_Two extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-service-two';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Service Two', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    }


    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls_section() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__( 'Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'List Content' , 'tpcore' ),
                'show_label' => false,
            ]
        );


       $repeater->add_control(
			'list_btn_txt',
			[
				'label' => esc_html__( 'Button Text', 'tpcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Know More', 'tpcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'tpcore' ),
			]
		);

       $repeater->add_control(
			'list_link',
			[
				'label' => esc_html__( 'Link', 'tpcore' ),
				'type' => Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'label_block' => true,
			]
		);

       $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'tpcore' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'dot-circle',
						'square-full',
					],
				],
			]
		);


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                        
                    ],
                    [
                        'list_title' => esc_html__( 'Title #2', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ], 
                    [
                        'list_title' => esc_html__( 'Title #3', 'tpcore' ),
                        'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-block_two-heading a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .service-block_two-heading a',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-block_two-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .service-block_two-text p',
            ]
        );


        $this->end_controls_section();


        

    }

    protected function style_tab_content(){
        $this->tp_basic_style_controls('footer_title', 'Title Style', '.tp-el-title');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $bgIMG = $settings['image']['url'];


     ?>
          <!-- Services Two -->
	<section class="services-two">
		<div class="auto-container">
			<div class="row clearfix">
              <?php foreach (  $settings['list'] as $key => $item ) : ?>

              	<div class="service-block_two col-lg-4 col-md-6 col-sm-12">
					<div class="service-block_two-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="service-block_two-image" style="background-image:url(<?php echo $bgIMG; ?>)"></div>
						<div class="upper-box">
							<div class="d-flex justify-content-between flex-wrap">
								<div class="service-block_two-number">0<?php echo $key + 1; ?></div>
								<div class="service-block_two-icon">
									<i class="<?php echo esc_attr ( $item['list_icon']['value'] ); ?>" aria-hidden="true"></i>
								</div>
							</div>
							<h4 class="service-block_two-heading"><a href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_title']; ?></a></h4>
							<div class="service-block_two-text"><?php echo $item['list_content']; ?></div>
						</div>
						<div class="lower-box">
							<div class="d-flex justify-content-between align-items-center flex-wrap">
								<a href="<?php echo $item['list_link']['url']; ?>">
									<i class="service-block_two-arrow <?php echo esc_attr ( $item['list_icon']['value'] ); ?>" aria-hidden="true"></i>
								</a>
								<a class="service-block_two-more" href="<?php echo $item['list_link']['url']; ?>"><?php echo $item['list_btn_txt']; ?></a>
							</div>
						</div>
					</div>
				</div>

				<?php endforeach ; ?>
			</div>
		</div>
	</section>
	<!-- End Services Two -->
    
     <?php
    }
}

$widgets_manager->register( new TP_Service_Two() );



