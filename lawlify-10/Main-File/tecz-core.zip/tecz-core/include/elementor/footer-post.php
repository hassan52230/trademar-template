<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Footer_Post extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'footer-post';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Footer Post', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        
        // Blog Query
		$this->tp_query_controls('blog', 'Blog');


	}

    // style_tab_content
    protected function style_tab_content(){
		$this->tp_section_style_controls('blog_section', 'Section Style', '.tp-el-section');
        $this->tp_basic_style_controls('blog_post_sub_title', 'Blog - Sub - Title', '.tp-el-sub-title');
        $this->tp_basic_style_controls('blog_post_title', 'Blog - Title', '.tp-el-title');
        $this->tp_basic_style_controls('blog_post_description', 'Blog - Description', '.tp-el-content');
        
        $this->tp_link_controls_style('blog_box_date', 'Blog - Box - Date Meta', '.tp-el-box-date');
        $this->tp_basic_style_controls('blog_box_title', 'Blog - Box - Title', '.tp-el-box-title');
        $this->tp_basic_style_controls('blog_box_desc', 'Blog - Box - Description', '.tp-el-box-desc');
        $this->tp_link_controls_style('blog_box_btn', 'Blog - Box - Button', '.tp-el-box-btn');
        
        $this->tp_basic_style_controls('blog_cta_title', 'Blog - CTA - Title', '.tp-el-cta-title');
        $this->tp_link_controls_style('blog_cta_btn', 'Blog - Cta - Button', '.tp-el-cta-btn');
    }



	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        /**
         * Setup the post arguments.
        */
        $query_args = TP_Helper::get_query_args('post', 'category', $this->get_settings());

        // The Query
        $query = new \WP_Query($query_args);


        $filter_list = $settings['category'];

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ): 

?>
<div class="footer-post footer-top-5">
    <?php if ($query->have_posts()) : ?>
    <?php while ($query->have_posts()) : 
        $query->the_post();
        global $post;
        $categories = get_the_category($post->ID);
    ?>

  <div class="footer-post-3-item d-flex align-items-center mb-35">
    <?php if(has_post_thumbnail()) : ?>
     <div class="footer-post-3-thumb">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
     </div>
     <?php endif; ?>
     <div class="footer-post-3-content">
        <span class="footer-post-3-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></span>
        <span class="footer-post-3-date">
           <i>
            <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1.31934 7.05334H14.6873" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M11.3312 9.98205H11.3382" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M8.00311 9.98205H8.01005" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M4.66815 9.98205H4.67509" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M11.3312 12.8971H11.3382" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M8.00311 12.8971H8.01005" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M4.66815 12.8971H4.67509" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M11.0329 1.5V3.96809" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M4.97435 1.5V3.96809" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.1787 2.68457H4.82822C2.6257 2.68457 1.25 3.91152 1.25 6.16684V12.9541C1.25 15.2449 2.6257 16.5002 4.82822 16.5002H11.1718C13.3812 16.5002 14.75 15.2661 14.75 13.0108V6.16684C14.7569 3.91152 13.3882 2.68457 11.1787 2.68457Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
             </svg>
           </i>
           <?php the_time( 'j F, Y' ); ?>
        </span>
     </div>
  </div>
    <?php endwhile; wp_reset_query(); ?>
    <?php endif; ?>
</div>
<?php else: ?>


<div class="footer-post">
    <?php if ($query->have_posts()) : ?>
    <?php while ($query->have_posts()) : 
        $query->the_post();
        global $post;
        $categories = get_the_category($post->ID);
    ?>

  <div class="footer-post-3-item d-flex align-items-center mb-35">
    <?php if(has_post_thumbnail()) : ?>
     <div class="footer-post-3-thumb">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
     </div>
     <?php endif; ?>
     <div class="footer-post-3-content">
        <span class="footer-post-3-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></span>
        <span class="footer-post-3-date">
           <i>
              <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <path d="M1.31934 7.05334H14.6873" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M11.3312 9.98205H11.3382" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M8.00311 9.98205H8.01005" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M4.66815 9.98205H4.67509" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M11.3312 12.8971H11.3382" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M8.00311 12.8971H8.01005" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M4.66815 12.8971H4.67509" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M11.0329 1.5V3.96809" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M4.97435 1.5V3.96809" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path fill-rule="evenodd" clip-rule="evenodd" d="M11.1787 2.68457H4.82822C2.6257 2.68457 1.25 3.91152 1.25 6.16684V12.9541C1.25 15.2449 2.6257 16.5002 4.82822 16.5002H11.1718C13.3812 16.5002 14.75 15.2661 14.75 13.0108V6.16684C14.7569 3.91152 13.3882 2.68457 11.1787 2.68457Z" stroke="#6A5952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
           </i>
           <?php the_time( 'j F, Y' ); ?>
        </span>
     </div>
  </div>
    <?php endwhile; wp_reset_query(); ?>
    <?php endif; ?>
</div>


<?php endif;  
	}

}

$widgets_manager->register( new TP_Footer_Post() );