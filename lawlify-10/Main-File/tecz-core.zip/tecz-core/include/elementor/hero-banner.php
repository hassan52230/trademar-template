<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Repeater;
use \Elementor\Utils;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;
use TPCore\Elementor\Controls\Group_Control_TPGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Hero_Banner extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-hero-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Hero Banner', 'tp-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tp-core' ];
	}
    protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'tp-core'),
            'behance' => esc_html__('Behance', 'tp-core'),
            'bitbucket' => esc_html__('BitBucket', 'tp-core'),
            'codepen' => esc_html__('CodePen', 'tp-core'),
            'delicious' => esc_html__('Delicious', 'tp-core'),
            'deviantart' => esc_html__('DeviantArt', 'tp-core'),
            'digg' => esc_html__('Digg', 'tp-core'),
            'dribbble' => esc_html__('Dribbble', 'tp-core'),
            'email' => esc_html__('Email', 'tp-core'),
            'facebook' => esc_html__('Facebook', 'tp-core'),
            'flickr' => esc_html__('Flicker', 'tp-core'),
            'foursquare' => esc_html__('FourSquare', 'tp-core'),
            'github' => esc_html__('Github', 'tp-core'),
            'houzz' => esc_html__('Houzz', 'tp-core'),
            'instagram' => esc_html__('Instagram', 'tp-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'tp-core'),
            'linkedin' => esc_html__('LinkedIn', 'tp-core'),
            'medium' => esc_html__('Medium', 'tp-core'),
            'pinterest' => esc_html__('Pinterest', 'tp-core'),
            'product-hunt' => esc_html__('Product Hunt', 'tp-core'),
            'reddit' => esc_html__('Reddit', 'tp-core'),
            'slideshare' => esc_html__('Slide Share', 'tp-core'),
            'snapchat' => esc_html__('Snapchat', 'tp-core'),
            'soundcloud' => esc_html__('SoundCloud', 'tp-core'),
            'spotify' => esc_html__('Spotify', 'tp-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'tp-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'tp-core'),
            'tumblr' => esc_html__('Tumblr', 'tp-core'),
            'twitch' => esc_html__('Twitch', 'tp-core'),
            'twitter' => esc_html__('Twitter', 'tp-core'),
            'vimeo' => esc_html__('Vimeo', 'tp-core'),
            'vk' => esc_html__('VK', 'tp-core'),
            'website' => esc_html__('Website', 'tp-core'),
            'whatsapp' => esc_html__('WhatsApp', 'tp-core'),
            'wordpress' => esc_html__('WordPress', 'tp-core'),
            'xing' => esc_html__('Xing', 'tp-core'),
            'yelp' => esc_html__('Yelp', 'tp-core'),
            'youtube' => esc_html__('YouTube', 'tp-core'),
        ];
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tp-core'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tp-core'),
                    'layout-2' => esc_html__('Layout 2', 'tp-core'),
                    'layout-3' => esc_html__('Layout 3', 'tp-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'tp-core'),
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_subtitle',
            [
                'label' => esc_html__('Sub Title', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Sub Title', 'tp-core'),
                'placeholder' => esc_html__('Type Heading Text', 'tp-core'),
                'label_block' => true,
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-3']
                ]
            ]
        );

        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('TP Title', 'tp-core'),
                'placeholder' => esc_html__('Type Heading Text', 'tp-core'),
                'label_block' => true,
            ]
        );        

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('TP section description here', 'tp-core'),
                'placeholder' => esc_html__('Type section description here', 'tp-core'),
            ]
        );        

        $this->add_control(
            'tp_custom_url',
            [
                'label' => esc_html__('Button URL', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('#', 'tp-core'),
                'placeholder' => esc_html__('Button URL', 'tp-core'),
                'condition' => [
                    'tp_design_style' => 'layout-3'
                ]
            ]
        );

        $this->add_responsive_control(
            'tp_align',
            [
                'label' => esc_html__('Alignment', 'tp-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'text-left' => [
                        'title' => esc_html__('Left', 'tp-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'text-center' => [
                        'title' => esc_html__('Center', 'tp-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'text-right' => [
                        'title' => esc_html__('Right', 'tp-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => false,
            ]
        );
        $this->end_controls_section();
        
        $this->tp_button_render('banner', 'Button', ['layout-1','layout-2','layout-3']); 

        // tp_section_title
        $this->start_controls_section(
            'tp_video_ctrl',
            [
                'label' => esc_html__('Video', 'tp-core'),
                'condition' => [
                    'tp_design_style' => ['layout-1','layout-2','layout-3']
                ]
            ]
        );
        $this->add_control(
            'tp_video_url',
            [
                'label' => esc_html__('Video URL', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('https://www.youtube.com/watch?v=TYYf8zYjP5k', 'tp-core'),
                'placeholder' => esc_html__('Video URL Here', 'tp-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_video_text',
            [
                'label' => esc_html__('Video Text', 'tp-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Watch Our
                Showcase', 'tp-core'),
                'label_block' => true,
                'condition' => [
                    'tp_design_style' => 'layout-3'
                ]
            ]
        );


        $this->end_controls_section();

        // tp_section_title
        $this->start_controls_section(
            'tp_case_sec',
            [
                'label' => esc_html__('Case Story', 'tp-core'),
                'condition' => [
                    'tp_design_style' => 'layout-4'
                ]
            ]
        );

        $this->add_control(
            'tp_case_image',
            [
                'label' => esc_html__( 'Chose Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'tp_case_text',
            [
                'label' => esc_html__('Text', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('25k+ Cases Done', 'tp-core'),
                'placeholder' => esc_html__('25k+ Cases Done', 'tp-core'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();
        
        // _tp_image
		$this->start_controls_section(
            '_tp_image',
            [
                'label' => esc_html__('Thumbnail', 'tp-core'),
            ]
        );

        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
        $this->add_control(
            'tp_image_two',
            [
                'label' => esc_html__( 'Choose Image 2', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_design_style' => 'layout-3'
                ]
            ]
        );
        
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'tp_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->add_control(
            'tp_shape_show',
            [
                'label' => esc_html__( 'Bg Show', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();
        // _tp_image
		$this->start_controls_section(
            'hero_tp_contact',
            [
                'label' => esc_html__('Hero Contact info ', 'tp-core'),
                'condition' => [
                    'tp_design_style' => ['layout-2']
                ]
            ]
        );
        $this->add_control(
            'tp_hero_contat_switch',
            [
                'label' => __( 'Show Social Links?', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'tpcore' ),
                'label_off' => __( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'style_transfer' => true,
            ]
        );

        $this->add_control(
            'tp_hero_contat_number',
            [
                'label' => esc_html__('Hero Number', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+2700231798', 'tp-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_hero_contat_email',
            [
                'label' => esc_html__('Hero Email', 'tp-core'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('teczhelp@gmail.com', 'tp-core'),
                'label_block' => true,
            ]
        );
        $this->end_controls_section();
        // About Repeater
        $this->start_controls_section(
         'tp_banner_list',
             [
               'label' => esc_html__( 'Banner List', 'tpcore' ),
               'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-6']
                ]
             ]
        );
        
        $repeater = new \Elementor\Repeater();


         $repeater->add_control(
         'banner_list_title',
           [
             'label'   => esc_html__( 'List Title', 'tpcore' ),
             'type'        => \Elementor\Controls_Manager::TEXT,
             'default'     => esc_html__( 'See the action in live', 'tpcore' ),
             'label_block' => true,
           ]
         );
         

         $this->add_control(
           'about_features_list',
           [
             'label'       => esc_html__( 'About List', 'tpcore' ),
             'type'        => \Elementor\Controls_Manager::REPEATER,
             'fields'      => $repeater->get_controls(),
             'default'     => [
               [
                 'banner_list_title'   => esc_html__( 'See the action in live', 'tpcore' ),
               ],
               [
                 'banner_list_title'   => esc_html__( 'Intuitive dashboard', 'tpcore' ),
               ],
             ],
             'title_field' => '{{{ banner_list_title }}}',
           ]
         );
        
        $this->end_controls_section();
 // Slider Bottom Panel
 $this->start_controls_section(
    'tp_slider_bottom_info',
    [
        'label' => esc_html__('Slider Info', 'tpcore'),
        'condition' => [
            'tp_design_style' => ['layout-1', 'layout-2', 'layout-3']
       ]
    ]
);
$this->add_control(
    'show_social',
    [
        'label' => __( 'Show Social Links?', 'tpcore' ),
        'type' => Controls_Manager::SWITCHER,
        'label_on' => __( 'Yes', 'tpcore' ),
        'label_off' => __( 'No', 'tpcore' ),
        'return_value' => 'yes',
        'style_transfer' => true,
    ]
);
$this->add_control(
    'social_title',
    [
        'label' => __( 'Social Title', 'tpcore' ),
        'description' => tp_get_allowed_html_desc( 'basic' ),
        'type' => Controls_Manager::TEXT,
        'default' => esc_html__('Follow us _', 'tp-core'),
        'label_block' => true,
    ]
);

$this->add_control(
    'web_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Website Address', 'tpcore' ),
        'placeholder' => __( 'Add your profile link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'email_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Email', 'tpcore' ),
        'placeholder' => __( 'Add your email link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);           

$this->add_control(
    'phone_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Phone', 'tpcore' ),
        'placeholder' => __( 'Add your phone link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'facebook_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Facebook', 'tpcore' ),
        'default' => __( '#', 'tpcore' ),
        'placeholder' => __( 'Add your facebook link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);                

$this->add_control(
    'twitter_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Twitter', 'tpcore' ),
        'default' => __( '#', 'tpcore' ),
        'placeholder' => __( 'Add your twitter link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);

$this->add_control(
    'instagram_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Instagram', 'tpcore' ),
        'default' => __( '#', 'tpcore' ),
        'placeholder' => __( 'Add your instagram link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);       

$this->add_control(
    'linkedin_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'LinkedIn', 'tpcore' ),
        'placeholder' => __( 'Add your linkedin link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'youtube_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Youtube', 'tpcore' ),
        'placeholder' => __( 'Add your youtube link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'googleplus_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Google Plus', 'tpcore' ),
        'placeholder' => __( 'Add your Google Plus link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'flickr_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Flickr', 'tpcore' ),
        'placeholder' => __( 'Add your flickr link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'vimeo_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Vimeo', 'tpcore' ),
        'placeholder' => __( 'Add your vimeo link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);

$this->add_control(
    'behance_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Behance', 'tpcore' ),
        'placeholder' => __( 'Add your hehance link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'dribble_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Dribbble', 'tpcore' ),
        'placeholder' => __( 'Add your dribbble link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);        

$this->add_control(
    'pinterest_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Pinterest', 'tpcore' ),
        'placeholder' => __( 'Add your pinterest link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
);

$this->add_control(
    'gitub_title',
    [
        'type' => Controls_Manager::TEXT,
        'label_block' => false,
        'label' => __( 'Github', 'tpcore' ),
        'placeholder' => __( 'Add your github link', 'tpcore' ),
        'dynamic' => [
            'active' => true,
        ]
    ]
); 

$this->end_controls_section();


	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('banner_section', 'Section Style', '.ele-section');
        $this->tp_icon_style('banner_icon', 'Banner - Icon/Image/SVG', '.tp-banner-icon');
        $this->tp_basic_style_controls('banner_sub_title', 'Sub Heading Style', '.ele-sub-heading');
        $this->tp_basic_style_controls('banner_title', 'Heading Style', '.ele-heading');
        $this->tp_basic_style_controls('banner_des', 'Content Style', '.ele-description');
        $this->tp_basic_style_controls('banner_list', 'Features Style', '.ele-features');
        $this->tp_link_controls_style('banner_btn_1', 'Button Style 1', '.ele-btn-1');
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    // thumbnail
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }

    // banner button Link
    if ('2' == $settings['tp_banner_btn_link_type']) {
        $this->add_render_attribute('tp_banner-button-arg', 'href', get_permalink($settings['tp_banner_btn_page_link']));
        $this->add_render_attribute('tp_banner-button-arg', 'target', '_self');
        $this->add_render_attribute('tp_banner-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp_banner-button-arg', 'class', 'tp-btn');
    } else {
        if ( ! empty( $settings['tp_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp_banner-button-arg', $settings['tp_banner_btn_link'] );
            $this->add_render_attribute('tp_banner-button-arg', 'class', 'tp-btn');
        }
    }
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_slider_image_url = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_slider_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
<!-- baner-area-start -->
<section id="video-bg" class="banner-area tp-banner-two-wrapper tp-banner-two-overlay p-relative test-xy ele-section">
<div class="player" data-property="{videoURL:'<?php echo esc_url( $settings['tp_video_url'] ); ?>',containment:'#video-bg', showControls:false, autoPlay:true, loop:true, mute:true, startAt:0, opacity:1, quality:'default'}"></div>
    <?php if( !empty($settings['tp_shape_show'] ) ) : ?>
        <div class="tp-banner-two-bg" style="background-image:url(<?php echo esc_url($tp_slider_image_url); ?>)"></div>
    <?php endif; ?>
    <div class="container">
        <div class="row"> 
            <div class="col-lg-12">
                <div class="tp-banner-two">
                    <?php if( !empty($settings['tp_section_title_show'] ) ) : ?>
                        <?php if ( !empty($settings['tp_title']) ) : ?> 
                            <h2 class="tp-banner-two-title wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s"> <?php echo tp_kses( $settings['tp_title' ] ); ?></h2>
                        <?php endif; ?> 
                        <div class="tp-banner-two-content d-flex align-items-center wow fadeInUp" data-wow-duration="1s"
                        data-wow-delay=".7s">
                        <?php if ( !empty($settings['tp_desctiption']) ) : ?> 
                        <p><?php echo tp_kses( $settings['tp_desctiption'] ); ?></p>
                        <?php endif; ?> 
                        <?php if ( !empty($settings['tp_banner_btn_text']) ) : ?> 
                            <div class="tp-banner-btn">
                                <a  <?php echo $this->get_render_attribute_string( 'tp_banner-button-arg' ); ?>><?php echo tp_kses($settings['tp_banner_btn_text']); ?></a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if( !empty($settings['tp_hero_contat_switch'] ) ) : ?>
    <div class="tp-banner-social d-none d-lg-block">
        <?php if ( !empty($settings['tp_hero_contat_number']) ) : ?> 
            <a href="tel:<?php echo esc_attr($settings['tp_hero_contat_number'] ); ?>"><?php echo tp_kses($settings['tp_hero_contat_number']); ?></a>
        <?php endif; ?>
        <?php if ( !empty($settings['tp_hero_contat_email']) ) : ?> 
            <a href="mailto:<?php echo tp_kses($settings['tp_hero_contat_email']); ?>"><?php echo tp_kses($settings['tp_hero_contat_email']); ?></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if( !empty($settings['show_social'] ) ) : ?>
    <div class="tp-banner-two-social d-none d-md-block">
         <?php if( !empty($settings['web_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['web_title'] ); ?>"><i class="fa-sharp fa-light fa-browser"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['phone_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['phone_title'] ); ?>"><i class="fa-sharp fa-solid fa-phone"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['facebook_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['facebook_title'] ); ?>"><i class="fa-brands fa-facebook-f"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['twitter_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['twitter_title'] ); ?>"><i class="fa-brands fa-twitter"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['linkedin_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['linkedin_title'] ); ?>"><i class="fa-brands fa-linkedin-in"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['instagram_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['instagram_title'] ); ?>"><i class="fa-brands fa-instagram"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['youtube_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['youtube_title'] ); ?>"><i class="fa-brands fa-youtube"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['googleplus_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['googleplus_title'] ); ?>"><i class="fa-brands fa-google-plus-g"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['flickr_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['flickr_title'] ); ?>"><i class="fa-brands fa-flickr"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['vimeo_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['vimeo_title'] ); ?>"><i class="fa-brands fa-vimeo-v"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['behance_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['behance_title'] ); ?>"><i class="fa-brands fa-behance"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['dribble_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['dribble_title'] ); ?>"><i class="fa-regular fa-basketball"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['pinterest_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['pinterest_title'] ); ?>"><i class="fa-brands fa-pinterest-p"></i></a>
        <?php endif; ?>
        <?php if( !empty($settings['gitub_title'] ) ) : ?>
            <a href="<?php echo esc_url( $settings['gitub_title'] ); ?>"><i class="fa-brands fa-square-github"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</section>
<!-- baner-area-end -->

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : 
    // thumbnail
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_slider_image_url = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_slider_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['tp_image_two']['url']) ) {
        $tp_image = !empty($settings['tp_image_two']['id']) ? wp_get_attachment_image_url( $settings['tp_image_two']['id'], $settings['tp_image_size_size']) : $settings['tp_image_two']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image_two"]["id"], "_wp_attachment_image_alt", true);
    }    
    // banner button Link
    if ('2' == $settings['tp_banner_btn_link_type']) {
        $this->add_render_attribute('tp_banner-button-arg', 'href', get_permalink($settings['tp_banner_btn_page_link']));
        $this->add_render_attribute('tp_banner-button-arg', 'target', '_self');
        $this->add_render_attribute('tp_banner-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp_banner-button-arg', 'class', 'tp-btn-red');
    } else {
        if ( ! empty( $settings['tp_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp_banner-button-arg', $settings['tp_banner_btn_link'] );
            $this->add_render_attribute('tp_banner-button-arg', 'class', 'tp-btn-red');
        }
    }
?>
 <!-- banner-area-start -->
 <section class="banner-area tp-banner-5-bg"  style="background-image:url(<?php echo esc_url($tp_image ); ?>)">
         <div class="container">
            <div class="row align-items-end">
               <div class="col-lg-6">
               <?php if( !empty($settings['tp_section_title_show'] ) ) : ?>
                <div class="tp-banner-5-wrapper">
                  <?php if ( !empty($settings['tp_subtitle']) ) : ?> 
                     <span class="tp-banner-5-sub-title wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s"><?php echo tp_kses( $settings['tp_subtitle' ] ); ?></span>
                    <?php endif; ?>                   
                    <?php if ( !empty($settings['tp_title']) ) : ?> 
                     <h4 class="tp-banner-5-title wow fadeInUp" data-wow-duration="1.2s" data-wow-delay=".7s"><?php echo tp_kses( $settings['tp_title' ] ); ?></h4>
                     <?php endif; ?>
                     <div class="tp-banner-5-info d-flex align-items-center wow fadeInUp" data-wow-duration="1.4s"
                        data-wow-delay=".9s">
                        <?php if ( !empty($settings['tp_title']) ) : ?>
                        <div class="tp-banner-5-btn">
                           <a <?php echo $this->get_render_attribute_string( 'tp_banner-button-arg' ); ?>><?php echo tp_kses($settings['tp_banner_btn_text']); ?></a>
                        </div>
                        <?php endif; ?>
                        <?php if ( !empty($settings['tp_video_text']) ) : ?>
                        <div class="tp-banner-5-video d-flex align-items-center">
                           <a class="popup-video" href="<?php echo tp_kses( $settings['tp_video_url'] ); ?>"><i
                                 class="flaticon-play"></i></a>
                           <span><?php echo tp_kses( $settings['tp_video_text'] ); ?></span>
                        </div>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
               <?php endif; ?>
               <div class="col-lg-6">
               <?php if( !empty($settings['tp_shape_show'] ) ) : ?>
                  <div class="tp-banner-5-thumb">
                     <div class="tp-banner-5-thumb-1">
                        <img src="<?php echo esc_url($tp_slider_image_url); ?>" alt="">
                     </div>
                  </div>
                  <?php endif; ?>
               </div>
            </div>
         </div>
         <?php if( !empty($settings['show_social'] ) ) : ?>
         <div class="tp-slider-2-social d-none d-lg-block">
            <?php if( !empty($settings['social_title'] ) ) : ?>
                <span><?php echo tp_kses( $settings['social_title'] ); ?></span>
            <?php endif; ?>
            <?php if( !empty($settings['web_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['web_title'] ); ?>"><?php echo esc_html__("We","tpcore") ?>
            <?php endif; ?>
            <?php if( !empty($settings['phone_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['phone_title'] ); ?>"><?php echo esc_html__("Ph","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['facebook_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['facebook_title'] ); ?>"><?php echo esc_html__("Fa","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['twitter_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['twitter_title'] ); ?>"><?php echo esc_html__("Tw","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['linkedin_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['linkedin_title'] ); ?>"><?php echo esc_html__("Li","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['instagram_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['instagram_title'] ); ?>"><?php echo esc_html__("In","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['youtube_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['youtube_title'] ); ?>"><?php echo esc_html__("Yo","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['googleplus_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['googleplus_title'] ); ?>"><?php echo esc_html__("Go","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['flickr_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['flickr_title'] ); ?>"><?php echo esc_html__("Fl","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['vimeo_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['vimeo_title'] ); ?>"><?php echo esc_html__("Vi","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['behance_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['behance_title'] ); ?>"><?php echo esc_html__("Be","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['dribble_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['dribble_title'] ); ?>"><?php echo esc_html__("Dr","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['pinterest_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['pinterest_title'] ); ?>"><?php echo esc_html__("Pi","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['gitub_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['gitub_title'] ); ?>"><?php echo esc_html__("Gi","tpcore") ?></a>
            <?php endif; ?>
         </div>
         <?php endif; ?>
      </section>
      <!-- banner-area-end -->
 

<?php else :

    // thumbnail
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }

    // thumbnail
    if ( !empty($settings['tp_video_image']['url']) ) {
        $tp_video_image = !empty($settings['tp_video_image']['id']) ? wp_get_attachment_image_url( $settings['tp_video_image']['id'], 'full') : $settings['tp_video_image']['url'];
        $tp_video_image_alt = get_post_meta($settings["tp_video_image"]["id"], "_wp_attachment_image_alt", true);
    }

    // banner button Link
    if ('2' == $settings['tp_banner_btn_link_type']) {
        $this->add_render_attribute('tp_banner-button-arg', 'href', get_permalink($settings['tp_banner_btn_page_link']));
        $this->add_render_attribute('tp_banner-button-arg', 'target', '_self');
        $this->add_render_attribute('tp_banner-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp_banner-button-arg', 'class', 'tp-btn');
    } else {
        if ( ! empty( $settings['tp_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp_banner-button-arg', $settings['tp_banner_btn_link'] );
            $this->add_render_attribute('tp_banner-button-arg', 'class', 'tp-btn');
        }
    }
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_slider_image_url = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['thumbnail_size']) : $settings['tp_image']['url'];
        $tp_slider_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'tp-hero-2__title');

?>
      <!-- baner-area-start -->
      <section class="banner-area tp-banner-bg theme-bg p-relative ele-section">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="tp-banner">
                        <?php if( !empty($settings['tp_section_title_show'] ) ) : ?>
                            <?php if ( !empty($settings['tp_subtitle']) ) : ?> 
                                <span class="tp-banner-sub-title wow fadeInUp" data-wow-duration="1s"
                                    data-wow-delay=".5s"><?php echo tp_kses( $settings['tp_subtitle' ] ); ?></span>
                                <?php endif; ?>
                            <?php if ( !empty($settings['tp_title']) ) : ?> 
                                <h2 class="tp-banner-title wow fadeInUp" data-wow-duration="1.2s" data-wow-delay=".7s">
                                <?php echo tp_kses( $settings['tp_title' ] ); ?></h2>
                            <?php endif; ?>

                            <?php if ( !empty($settings['tp_banner_btn_text']) ) : ?> 
                            <div class="tp-banner-btn wow fadeInUp" data-wow-duration="1.4s" data-wow-delay=".9s">
                                <a  <?php echo $this->get_render_attribute_string( 'tp_banner-button-arg' ); ?>><?php echo tp_kses($settings['tp_banner_btn_text']); ?></a>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                  </div>
              
               </div>
            </div>
         </div>
         <?php if( !empty($settings['show_social'] ) ) : ?>
         <div class="tp-banner-social d-none d-lg-block">
            <?php if( !empty($settings['web_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['web_title'] ); ?>"><?php echo esc_html__("WEBSITE","tpcore") ?>
            <?php endif; ?>
            <?php if( !empty($settings['phone_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['phone_title'] ); ?>"><?php echo esc_html__("PHONE","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['facebook_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['facebook_title'] ); ?>"><?php echo esc_html__("FACEBOOK","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['twitter_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['twitter_title'] ); ?>"><?php echo esc_html__("TWITTER","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['linkedin_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['linkedin_title'] ); ?>"><?php echo esc_html__("LINKEDIN","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['instagram_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['instagram_title'] ); ?>"><?php echo esc_html__("INSTAGRAM","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['youtube_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['youtube_title'] ); ?>"><?php echo esc_html__("YOUTUBE","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['googleplus_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['googleplus_title'] ); ?>"><?php echo esc_html__("GOOGLE PLUS","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['flickr_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['flickr_title'] ); ?>"><?php echo esc_html__("FLICKR","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['vimeo_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['vimeo_title'] ); ?>"><?php echo esc_html__("VIMEO","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['behance_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['behance_title'] ); ?>"><?php echo esc_html__("BEHANCE","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['dribble_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['dribble_title'] ); ?>"><?php echo esc_html__("DRIBBLE","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['pinterest_title'] ) ) : ?>
               <a href="<?php echo esc_url( $settings['pinterest_title'] ); ?>"><?php echo esc_html__("PINTEREST","tpcore") ?></a>
            <?php endif; ?>
            <?php if( !empty($settings['gitub_title'] ) ) : ?>
                <a href="<?php echo esc_url( $settings['gitub_title'] ); ?>"><?php echo esc_html__("GITHUB","tpcore") ?></a>
            <?php endif; ?>
         </div>
         <?php endif; ?>
         <div class="tp-banner-shape">
            <div class="tp-banner-shape-one">
               <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner/one/banner-one-shape-1.png" alt="">
            </div>
            <div class="tp-banner-shape-two">
               <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner/one/banner-one-shape-2.png" alt="">
            </div>
         </div>
         <div class="tp-banner-scroll-down">
            <div class="tp-banner-scroll-shape">
               <span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="238" height="70.594" viewBox="0 0 238 70.594">
                     <defs>
                        <style>
                           .cls-1 {
                              fill: #fff;
                              fill-rule: evenodd;
                           }
                        </style>
                     </defs>
                     <path id="scrolldown-shape-1.svg" class="cls-1"
                        d="M847,980s40.865-5.656,69-43,81.412-36.188,103,0,66,43,66,43H847Z"
                        transform="translate(-847 -909.406)" />
                  </svg>
               </span>
            </div>
         </div>
         <div class="tp-banner-scroll-mouse">
            <a href="#project-id">
               <span>
                  <svg id="scroll-down.svg" xmlns="http://www.w3.org/2000/svg" width="16" height="26"
                     viewBox="0 0 16 26">
                     <defs>
                        <style>
                           .cls-5,
                           .cls-6 {
                              fill: none;
                              stroke: #131023;
                              stroke-width: 1px;
                           }

                           .cls-6 {
                              fill-rule: evenodd;
                           }
                        </style>
                     </defs>
                     <circle class="cls-5" cx="8.5" cy="7.5" r="2" />
                     <path class="cls-6"
                        d="M963,922h5a5,5,0,0,1,5,5v15a5,5,0,0,1-5,5h-5a5,5,0,0,1-5-5V927A5,5,0,0,1,963,922Z"
                        transform="translate(-957.5 -921.5)" />
                  </svg>
               </span>
            </a>
            <p>Scroll Down</p>
         </div>
         <?php if ( !empty($settings['tp_video_url']) ) : ?> 
         <div class="tp-banner-video d-none d-md-block">
            <a class="popup-video" href="<?php echo tp_kses( $settings['tp_video_url'] ); ?>"><i class="flaticon-play"></i></a>
         </div>
         <?php endif; ?>
         <?php if( !empty($settings['tp_shape_show'] ) ) : ?>
         <div class="tp-banner-bg-shape" style="background-image:url(<?php echo esc_url($tp_slider_image_url); ?>)"></div>
         <?php endif; ?>
      </section>
      <!-- baner-area-end -->
<?php endif;
        
	}

}

$widgets_manager->register( new TP_Hero_Banner() );