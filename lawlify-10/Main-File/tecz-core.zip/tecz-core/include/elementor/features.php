<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Features extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'features';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Features', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                    'layout-5' => esc_html__('Layout 5', 'tpcore'),
                    'layout-6' => esc_html__('Layout 6', 'tpcore'),
                    'layout-7' => esc_html__('Layout 7', 'tpcore'),
                    'layout-8' => esc_html__('Layout 8', 'tpcore'),
                    'layout-9' => esc_html__('Layout 9', 'tpcore'),
                    'layout-10' => esc_html__('Layout 10', 'tpcore'),
                    'layout-11' => esc_html__('Layout 11', 'tpcore'),
                ],
                'default' => 'layout-1',
            ] 
        );

        $this->end_controls_section();
        
        // title/content
        $this->tp_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-5', 'layout-6'] );

        // Features group
        $this->start_controls_section(
            'tp_features',
            [
                'label' => esc_html__('Features List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'tpfeatures_title', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_design_style' => ['layout-2']
               ]
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                    'style_3' => __( 'Style 3', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );
        $repeater->add_control(
            'tp_features_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],
            ]
        );

        $repeater->add_control(
            'tp_features_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_features_icon_type' => 'image',
                ]

            ]
        );

        $repeater->add_control(
            'tp_features_icon_svg',
            [
                    'show_label' => false,
                    'type' => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                    'condition' => [
                        'tp_features_icon_type' => 'svg'
                    ]
            ]
        );

        if (tp_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'tp_features_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'tp_features_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'tp_features_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'tp_features_icon_type' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'tp_features_title_link', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_2']
                ]
            ]
        );
        $repeater->add_control(
            'tp_features_image_bg',
            [
                'label' => esc_html__('Upload Bg Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => ['style_2']
                ]

            ]
        );

        $repeater->add_control(
            'tp_features_title', [
                'label' => esc_html__('Features link', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'tp_features_description',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Donec felis sapien, lacinia at pulvinar quis',
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_2']
                ]
             
            ]
        );
        
        $repeater->add_control(
            'tp_features_back_text',
            [
                'label' => esc_html__('Back Text', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Y',
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_3']
                ]
            ]
        );
        

        $repeater->add_control(
            'tp_features_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'tp_features_btn_text',
            [
                'label' => esc_html__('Button Text', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tpcore'),
                'title' => esc_html__('Enter button text', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_features_link_switcher' => 'yes',
                    'repeater_condition' => 'style_2'
                ],
            ]
        );
        $repeater->add_control(
            'tp_features_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'tp_features_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'tp_features_link',
            [
                'label' => esc_html__( 'Service Link link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'tpcore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'tp_features_link_type' => '1',
                    'tp_features_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'tp_features_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_features_link_type' => '2',
                    'tp_features_link_switcher' => 'yes',
                ]
            ]
        );
        
        // creative animation
        $repeater->add_control(
			'tp_creative_anima_switcher',
			[
				'label' => esc_html__( 'Active Animation', 'tpcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tpcore   ' ),
				'label_off' => esc_html__( 'No', 'tpcore   ' ),
				'return_value' => 'yes',
				'default' => '0',
                'separator' => 'before',
                'condition' => [
                    'repeater_condition' => ['style_1']
                ]
			]
		);

        $repeater->add_control(
            'tp_anima_type',
            [
                'label' => __( 'Animation Type', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'bounceIn' => __( 'bounceIn', 'tpcore' ),
                    'bounceInUp' => __( 'bounceInUp', 'tpcore' ),
                    'bounceInRight' => __( 'bounceInRight', 'tpcore' ),
                    'bounceInLeft' => __( 'bounceInLeft', 'tpcore' ),
                    'bounceInDown' => __( 'bounceInDown', 'tpcore' ),
                    'fadeInDown' => __( 'fadeInDown', 'tpcore' ),
                    'fadeInLeft' => __( 'fadeInLeft', 'tpcore' ),
                    'fadeInRight' => __( 'fadeInRight', 'tpcore' ),
                ],
                'default' => 'fadeInUp',
                'frontend_available' => true,
                'style_transfer' => true,
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1']
                ],
            ]
        );
        
        $repeater->add_control(
            'tp_anima_dura', [
                'label' => esc_html__('Animation Duration', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.3s', 'tpcore'),
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1']
                ],
            ]
        );
        
        $repeater->add_control(
            'tp_anima_delay', [
                'label' => esc_html__('Animation Delay', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.6s', 'tpcore'),
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1']
                ],
            ]
        );

        $this->add_control(
            'tp_features_list',
            [
                'label' => esc_html__('Features - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_features_title' => esc_html__('Discover', 'tpcore'),
                    ],
                    [
                        'tp_features_title' => esc_html__('Define', 'tpcore')
                    ],
                    [
                        'tp_features_title' => esc_html__('Develop', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_features_title }}}',
            ]
        );
        $this->end_controls_section();
        // _tp_image
		$this->start_controls_section(
            '_tp_image', 
            [
                'label' => esc_html__('Thumbnail', 'tp-core'),
                'condition' => [
                    'tp_design_style' => ['layout-1','layout-2','layout-3','layout-4','layout-5','layout-6','layout-7']
                ]
            ]
         
        );

        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );
        $this->add_control(
            'tp_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_design_style' => ['layout-6',]
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'tp_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();
           // video
           $this->start_controls_section(
            'tp_video',
                [
                    'label' => esc_html__( 'Video', 'tpcore' ),
                    'condition' => [
                        'tp_design_style' => ['layout-6']
                    ]
                ]
            );
            $this->add_control(
                'video_url',
                [
                    'label'       => esc_html__( 'Video URL', 'tpcore' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => esc_html__( 'https://www.youtube.com/watch?v=EW4ZYb3mCZk', 'tpcore' ),
                    'label_block' => true,
                ]
            );

            $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('features_section', 'Section - Style', '.tp-el-section'); 
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>
    
<!-- feature-area-start -->
<section class="feature-area tp-feature-3-bg" data-background="<?php echo get_template_directory_uri(); ?>/assets/img/feature/three/feature-3-bg-1.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-feature-3-wrapper d-flex align-items-center justify-content-between">
                <?php foreach ($settings['tp_features_list'] as $key => $item) :
                    // Link
                    if ('2' == $item['tp_features_link_type']) {
                        $link = get_permalink($item['tp_features_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                        $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
                    }

                    // thumbnail image
                    if ( !empty($item['tp_features_main_image']['url']) ) {
                        $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
                        $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                    }
                ?>
                <div class="tp-feature-3-item text-center mb-60 wow <?php echo esc_attr($item['tp_anima_type']); ?>" data-wow-duration="<?php echo esc_attr($item['tp_anima_dura']); ?>" data-wow-delay="<?php echo esc_attr($item['tp_anima_delay']); ?>">
                    <div class="tp-feature-3-item-icon">
                        <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                        <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                        <div class="shape">
                            <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                        </div>
                        <?php endif; ?>
                        <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                        <?php if (!empty($item['tp_features_image']['url'])): ?>
                        <div class="shape">
                            <img src="<?php echo $item['tp_features_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        </div>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['tp_features_icon_svg'])): ?>
                        <div class="shape">
                            <?php echo $item['tp_features_icon_svg']; ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="tp-feature-3-item-content">
                    <?php if (!empty($item['tp_features_title' ])): ?>
                        <h4 class="tp-feature-3-item-title">
                        <?php echo tp_kses($item['tp_features_title' ]); ?>
                        </h4>
                        <?php endif; ?>
                        <span><?php echo tp_kses($item['tp_features_back_text']);?></span>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tp-feature-3-details text-center">
                <span><?php echo tp_kses($settings['tpfeatures_title']);?></span>
                </div>
            </div>
        </div>
    </div>
</section>
 <!-- feature-area-end -->

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : ?>

<!-- feature-area-start -->
<section class="feature-area pb-40">
    <div class="container">
    <div class="row">
        <?php foreach ($settings['tp_features_list'] as $key => $item) :
            // Link
            if ('2' == $item['tp_features_link_type']) {
                $link = get_permalink($item['tp_features_page_link']);
                $target = '_self';
                $rel = 'nofollow';
            } else {
                $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
            }

            // thumbnail image
            if ( !empty($item['tp_features_image_bg']['url']) ) {
                $tp_features_image_bg = !empty($item['tp_features_image_bg']['id']) ? wp_get_attachment_image_url( $item['tp_features_image_bg']['id'], 'full' ) : $item['tp_features_image_bg']['url'];
                $tp_features_main_image_alt = get_post_meta($item["tp_features_image_bg"]["id"], "_wp_attachment_image_alt", true);
            }
        ?>
        <div class="col-lg-4 col-md-6">
            <div class="tp-feature-4-item mb-80">
                <div class="tp-feature-4-thumb" style='background-image: url("<?php echo esc_url($tp_features_image_bg); ?>");'>
                </div>
                <div class="tp-feature-4-item-wrapper">
                <div class="tp-feature-4-item-icon">
                    <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                    <div class="shape">
                        <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                    </div>
                    <?php endif; ?>
                    <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['tp_features_image']['url'])): ?>
                    <div class="shape">
                        <img src="<?php echo $item['tp_features_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($item['tp_features_icon_svg'])): ?>
                    <div class="shape">
                        <?php echo $item['tp_features_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="tp-feature-4-item-content">
                <?php if (!empty($item['tp_features_title' ])): ?>
                    <h4 class="tp-feature-4-item-title">
                        <?php if (!empty($link)) : ?>
                        <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_features_title' ]); ?></a>
                        <?php else : ?>
                        <?php echo tp_kses($item['tp_features_title' ]); ?>
                        <?php endif; ?>
                    </h4>
                    <?php endif; ?>
                    <?php if (!empty($item['tp_features_description' ])): ?>
                    <p><?php echo tp_kses($item['tp_features_description']); ?></p>
                <?php endif; ?>
                </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    </div>
</section>


<!-- feature-area-end -->
<?php elseif ( $settings['tp_design_style']  == 'layout-4' ) : ?>
<!-- feature-area-start -->
<section class="feature-area tp-feature-5-wrap pt-120 pb-80">
    <div class="container">
    <div class="row">
    <?php foreach ($settings['tp_features_list'] as $key => $item) :
        // Link
        if ('2' == $item['tp_features_link_type']) {
            $link = get_permalink($item['tp_features_page_link']);
            $target = '_self';
            $rel = 'nofollow';
        } else {
            $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
            $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
            $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
        }

        // thumbnail image
        if ( !empty($item['tp_features_main_image']['url']) ) {
            $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
            $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
        }
        if ( !empty($item['tp_features_image_bg']['url']) ) {
            $tp_features_image_bg = !empty($item['tp_features_image_bg']['id']) ? wp_get_attachment_image_url( $item['tp_features_image_bg']['id'], $settings['tp_image_size_size']) : $item['tp_itp_features_image_bgmage']['url'];
            $tp_bg_image_alt = get_post_meta($item["tp_features_image_bg"]["id"], "_wp_attachment_image_alt", true);
        }
        ?>
        <div class="col-lg-4 col-md-6">
            <div class="tp-feature-5 mb-40">
                <div class="tp-feature-5-item">
                <div class="tp-feature-5-front d-flex align-items-center">
                    <div class="tp-feature-5-front-icon">
                        <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                            <div class="shape">
                                <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                            </div>
                            <?php endif; ?>
                            <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['tp_features_image']['url'])): ?>
                            <div class="shape">
                                <img src="<?php echo $item['tp_features_image']['url']; ?>"
                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            </div>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['tp_features_icon_svg'])): ?>
                            <div class="shape">
                                <?php echo $item['tp_features_icon_svg']; ?>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="tp-feature-5-front-content">
                    <?php if (!empty($item['tp_features_title_link'])): ?>
                        <h5 class="tp-feature-5-front-title"> <?php echo tp_kses($item['tp_features_title_link']);?></h5>
                        <?php endif; ?>
            
                    </div>
                </div>
                <div class="tp-feature-5-back">
                    <div class="tp-feature-5-back-bg"
                    style="background-image: url(<?php echo esc_url($tp_features_image_bg); ?>);">
                        <div class="tp-feature-5-back-content text-center">
                        <?php if (!empty($item['tp_features_description' ])): ?>
                            <p><?php echo tp_kses($item['tp_features_description']); ?></p>
                        <?php endif; ?>
                            <?php if (!empty($link)) : ?>
                            <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_features_title' ]); ?></a>
                            <?php else : ?>
                            <?php echo tp_kses($item['tp_features_title' ]); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    </div>
    <div class="tp-feature-5-shape-1">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape/line-5-shape-1.png" alt="">
    </div>
</section>
<!-- feature-area-end -->


<?php elseif ( $settings['tp_design_style']  == 'layout-5' ) :
$this->add_render_attribute('title_args', 'class', 'tp-section-title');  
if ( !empty($settings['tp_image']['url']) ) {
    $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
    $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
}    
?>
     <!-- solve-area-start -->
<section class="solve-area tp-solve-overlay pt-115 pb-60">
        <div class="tp-solve-bg" style='background-image: url("<?php echo esc_url($tp_image); ?>");'></div>        
        <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8">
                <div class="tp-section tp-section-white text-center mb-100">
                <?php if ( !empty($settings['tp_section_sub_title']) ) : ?>
                    <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_section_sub_title']); ?></span>
                <?php endif; ?>
                <?php
                    if ( !empty($settings['tp_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_section_title' ] )
                        );
                    endif;
                ?>
                </div>
            </div>
        </div>
        <div class="row">
        <?php foreach ($settings['tp_features_list'] as $key => $item) :
            // Link
            if ('2' == $item['tp_features_link_type']) {
                $link = get_permalink($item['tp_features_page_link']);
                $target = '_self';
                $rel = 'nofollow';
            } else {
                $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
            }

            // thumbnail image
            if ( !empty($item['tp_features_main_image']['url']) ) {
                $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
                $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
            }

        ?>
            <div class="col-lg-2 col-md-4 col-sm-6">
                <a href="<?php echo esc_url($link); ?>" class="tp-solve-item mb-60 wow bounceIn" data-wow-duration=".6s"
                    data-wow-delay=".6s">
                    <div class="tp-solve-icon">
                    <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                    <div class="shape">
                        <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                    </div>
                    <?php endif; ?>
                    <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['tp_features_image']['url'])): ?>
                    <div class="shape">
                        <img src="<?php echo $item['tp_features_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($item['tp_features_icon_svg'])): ?>
                    <div class="shape">
                        <?php echo $item['tp_features_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    </div>
                    <div class="tp-solve-content">
                    <h5 class="tp-solve-title"><?php echo tp_kses($item['tp_features_title' ]); ?></h5>
                    </div>
                    <div class="tp-solve-shape">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape/solve-shape-1.png" alt="">
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
        </div>
        </div>
</section>
    <!-- solve-area-end -->   



    <?php elseif ( $settings['tp_design_style']  == 'layout-6' ) :
$this->add_render_attribute('title_args', 'class', 'tp-section-title');  
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }   
    if ( !empty($settings['tp_image_2']['url']) ) {
        $tp_image_2 = !empty($settings['tp_image_2']['id']) ? wp_get_attachment_image_url( $settings['tp_image_2']['id'], $settings['tp_image_size_size']) : $settings['tp_image_2']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image_2"]["id"], "_wp_attachment_image_alt", true);
    }   
?>
     <!-- industry-area-start -->
     <section class="industry-area tp-industry-bg pt-115 pb-60" style='background-image: url("<?php echo esc_url($tp_image); ?>");'>
         <div class="tp-industry-bg-2" style='background-image: url("<?php echo esc_url($tp_image_2); ?>");'></div>
         <div class="container">
            <div class="row">
               <div class="col-lg-6">
                  <div class="tp-section tp-section-red-white mb-150 wow fadeInRight" data-wow-duration="1s"
                     data-wow-delay=".5s">
                     <?php if ( !empty($settings['tp_section_sub_title']) ) : ?>
                    <span class="tp-section-sub-title"><?php echo tp_kses($settings['tp_section_sub_title']); ?></span>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['tp_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_section_title' ] )
                            );
                        endif;
                    ?>
                     <div class="tp-section-title-wrapper">
                     <?php if ( !empty($settings['tp_section_description']) ) : ?>
                         <p><?php echo tp_kses( $settings['tp_section_description'] ); ?></p>
                    <?php endif; ?>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="tp-industry-4-video">
                     <div class="tp-industry-4-video-shape-1">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/shape/industry-4-shape-1.png" alt="">
                     </div>
                     <div class="tp-industry-4-video-shape-2">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/shape/industry-4-shape-2.png" alt="">
                     </div>
                     <div class="tp-industry-4-video-icon">
                        <a class="popup-video" href="<?php echo esc_url($settings['video_url']);?>"><i
                              class="flaticon-play"></i></a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
            <?php foreach ($settings['tp_features_list'] as $key => $item) :
                // Link
                if ('2' == $item['tp_features_link_type']) {
                    $link = get_permalink($item['tp_features_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                    $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['tp_features_main_image']['url']) ) {
                    $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
                    $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }

            ?>
               <div class="col-lg-2 col-md-4 col-sm-6">
                  <a href="<?php echo esc_url($link); ?>" class="tp-solve-item mb-60 wow bounceIn" data-wow-duration=".6s"
                     data-wow-delay=".6s">
                     <div class="tp-solve-icon">
                        <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                        <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                        <div class="shape">
                            <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                        </div>
                        <?php endif; ?>
                        <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                        <?php if (!empty($item['tp_features_image']['url'])): ?>
                        <div class="shape">
                            <img src="<?php echo $item['tp_features_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        </div>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['tp_features_icon_svg'])): ?>
                        <div class="shape">
                            <?php echo $item['tp_features_icon_svg']; ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                     </div>
                     <div class="tp-solve-content">
                        <h5 class="tp-solve-title"><?php echo tp_kses($item['tp_features_title' ]); ?></h5>
                     </div>
                     <div class="tp-solve-shape">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/shape/solve-4-shape-1.png" alt="">
                     </div>
                  </a>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </section>
      <!-- industry-area-end --> 



<?php elseif ( $settings['tp_design_style']  == 'layout-7' ) :
// shape image
if ( !empty($settings['tp_shape_image_1']['url']) ) {
$tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
$tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
}    
$this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
?>
    <!-- feature-area-start -->
<section class="feature-area pt-120 pb-90 p-relative feature-inner-bg"  style="background-image:url('<?php echo get_template_directory_uri(  ); ?>/assets/img/feature/inner/feature-inner-bg-1.jpg')">
<div class="container">
<div class="row">
<?php foreach ($settings['tp_features_list'] as $key => $item) :
    // Link
    if ('2' == $item['tp_features_link_type']) {
        $link = get_permalink($item['tp_features_page_link']);
        $target = '_self';
        $rel = 'nofollow';
    } else {
        $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
        $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
        $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
    }

    // thumbnail image
    if ( !empty($item['tp_features_main_image']['url']) ) {
        $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
        $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
    }

?>
    <div class="col-lg-4 col-md-6">
        <div class="tp-feature-item mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".4s">
        <div class="tp-feature-icon">
        <?php if($item['tp_features_icon_type'] == 'icon') : ?>
        <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
        <div class="shape">
            <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
        </div>
        <?php endif; ?>
        <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
        <?php if (!empty($item['tp_features_image']['url'])): ?>
        <div class="shape">
            <img src="<?php echo $item['tp_features_image']['url']; ?>"
                alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
        </div>
        <?php endif; ?>
        <?php else : ?>
        <?php if (!empty($item['tp_features_icon_svg'])): ?>
        <div class="shape">
            <?php echo $item['tp_features_icon_svg']; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        </div>
        <div class="tp-feature-content">
        <?php if (!empty($item['tp_features_title' ])): ?>
            <h4 class="tp-feature-content-title">
            <?php if (!empty($link)) : ?>
                <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_features_title' ]); ?></a>
                <?php else : ?>
                <?php echo tp_kses($item['tp_features_title' ]); ?>
                <?php endif; ?>
            </h4>
        <?php endif; ?>
        <?php if (!empty($item['tp_features_description' ])): ?>
            <p><?php echo tp_kses($item['tp_features_description']); ?></p>
        <?php endif; ?>
        </div>
        <div class="tp-feature-shape-two">
            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/feature/one/feature-shape-1.png" alt="">
        </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
</div>
<div class="tp-feature-shape">
<div class="tp-feature-shape-one w-img">
    <img src="<?php echo get_template_directory_uri(  ); ?>/assets/img/feature/one/features-bg.png" alt="">
</div>
</div>
</section>


<!-- feature-area-end -->
<?php elseif ( $settings['tp_design_style']  == 'layout-8' ) :
// shape image
if ( !empty($settings['tp_shape_image_1']['url']) ) {
$tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
$tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
}    
$this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
?>
 <div class="tp-faq-inner-2-item mb-30">
    <?php foreach ($settings['tp_features_list'] as $key => $item) :
        // Link
        if ('2' == $item['tp_features_link_type']) {
            $link = get_permalink($item['tp_features_page_link']);
            $target = '_self';
            $rel = 'nofollow';
        } else {
            $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
            $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
            $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
        }

        // thumbnail image
        if ( !empty($item['tp_features_main_image']['url']) ) {
            $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
            $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
        }

    ?>
    <a href="<?php echo esc_url($link); ?>" class="tp-faq-inner-2-feature d-flex align-items-center mb-10">
        <div class="tp-faq-inner-2-feature-icon">
            <?php if($item['tp_features_icon_type'] == 'icon') : ?>
            <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
            <div class="shape">
                <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
            </div>
            <?php endif; ?>
            <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
            <?php if (!empty($item['tp_features_image']['url'])): ?>
            <div class="shape">
                <img src="<?php echo $item['tp_features_image']['url']; ?>"
                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
            </div>
            <?php endif; ?>
            <?php else : ?>
            <?php if (!empty($item['tp_features_icon_svg'])): ?>
            <div class="shape">
                <?php echo $item['tp_features_icon_svg']; ?>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php if (!empty($item['tp_features_title' ])): ?>
            <h5 class="tp-faq-inner-2-feature-title"><?php echo tp_kses($item['tp_features_title' ]); ?></h5>
        <?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>


<?php elseif ( $settings['tp_design_style']  == 'layout-9' ) :
// shape image
if ( !empty($settings['tp_shape_image_1']['url']) ) {
$tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
$tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
}    
$this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
?>
<div class="tp-services-details-item-wrap mt-60">
    <div class="row">
         <?php foreach ($settings['tp_features_list'] as $key => $item) :
            // Link
            if ('2' == $item['tp_features_link_type']) {
                $link = get_permalink($item['tp_features_page_link']);
                $target = '_self';
                $rel = 'nofollow';
            } else {
                $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
            }

        ?>
        <div class="col-lg-4">
            <div class="tp-services-details-item-wrapper mb-40">
                <div class="tp-services-details-item-icon">
                    <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                    <div class="shape">
                        <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                    </div>
                    <?php endif; ?>
                    <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['tp_features_image']['url'])): ?>
                    <div class="shape">
                        <img src="<?php echo $item['tp_features_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($item['tp_features_icon_svg'])): ?>
                    <div class="shape">
                        <?php echo $item['tp_features_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if (!empty($item['tp_features_title' ])): ?>
                    <h4 class="tp-services-details-item-title"><?php echo tp_kses($item['tp_features_title' ]); ?></h4>
                <?php endif; ?>
                <?php if (!empty($item['tp_features_description' ])): ?>
                    <p><?php echo tp_kses($item['tp_features_description']); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

    <?php elseif ( $settings['tp_design_style']  == 'layout-10' ) :
    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
    $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
    $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }    
    $this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
    ?>

    <div class="tp-services-details-faq">
        <div class="row">
             <?php foreach ($settings['tp_features_list'] as $key => $item) :
                // Link
                if ('2' == $item['tp_features_link_type']) {
                    $link = get_permalink($item['tp_features_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                    $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['tp_features_main_image']['url']) ) {
                    $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
                    $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }

            ?>
            <div class="col-lg-6">
                <div class="tp-services-details-faq-item d-flex align-items-center mb-50">
                    <div class="tp-services-details-faq-item-icon">
                    <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                    <div class="shape">
                        <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                    </div>
                    <?php endif; ?>
                    <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['tp_features_image']['url'])): ?>
                    <div class="shape">
                        <img src="<?php echo $item['tp_features_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($item['tp_features_icon_svg'])): ?>
                    <div class="shape">
                        <?php echo $item['tp_features_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    </div>
                    <div class="tp-services-details-faq-item-content">
                    <?php if (!empty($item['tp_features_title' ])): ?>
                        <h4 class="tp-services-details-faq-title"><?php echo tp_kses($item['tp_features_title' ]); ?></h4>
                    <?php endif; ?>
                    <?php if (!empty($item['tp_features_description' ])): ?>
                    <span><?php echo tp_kses($item['tp_features_description']); ?></span>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>


    <?php elseif ( $settings['tp_design_style']  == 'layout-11' ) :
    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
    $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
    $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }    
    $this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
    ?>
    <div class="tp-services-details-check d-flex align-items-center mt-50">
        <?php foreach ($settings['tp_features_list'] as $key => $item) :
            // Link
            if ('2' == $item['tp_features_link_type']) {
                $link = get_permalink($item['tp_features_page_link']);
                $target = '_self';
                $rel = 'nofollow';
            } else {
                $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
            }

            // thumbnail image
            if ( !empty($item['tp_features_main_image']['url']) ) {
                $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
                $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
            }

        ?>
        <div class="tp-services-details-check-item d-flex align-items-center mb-55">
            <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                <div class="shape">
                    <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                </div>
                <?php endif; ?>
                <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                <?php if (!empty($item['tp_features_image']['url'])): ?>
                <div class="shape">
                    <img src="<?php echo $item['tp_features_image']['url']; ?>"
                        alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                </div>
                <?php endif; ?>
                <?php else : ?>
                <?php if (!empty($item['tp_features_icon_svg'])): ?>
                <div class="shape">
                    <?php echo $item['tp_features_icon_svg']; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (!empty($item['tp_features_title' ])): ?>
                <span><?php echo tp_kses($item['tp_features_title']); ?></span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>


<?php else: 

    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
        $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
        $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }
    
    $this->add_render_attribute('title_args', 'class', 'tp-section-title'); 
?>

      <!-- feature-area-start -->
      <section class="feature-area pt-140 pb-90 mb-160 p-relative">
         <div class="container">
            <div class="row">
            <?php foreach ($settings['tp_features_list'] as $key => $item) :
                // Link
                if ('2' == $item['tp_features_link_type']) {
                    $link = get_permalink($item['tp_features_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['tp_features_link']['url']) ? $item['tp_features_link']['url'] : '';
                    $target = !empty($item['tp_features_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['tp_features_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['tp_features_main_image']['url']) ) {
                    $tp_features_main_image = !empty($item['tp_features_main_image']['id']) ? wp_get_attachment_image_url( $item['tp_features_main_image']['id'], 'full' ) : $item['tp_features_main_image']['url'];
                    $tp_features_main_image_alt = get_post_meta($item["tp_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }

            ?>
               <div class="col-lg-4 col-md-6">
                  <div class="tp-feature-item mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".4s">
                     <div class="tp-feature-icon">
                     <?php if($item['tp_features_icon_type'] == 'icon') : ?>
                        <?php if (!empty($item['tp_features_icon']) || !empty($item['tp_features_selected_icon']['value'])) : ?>
                        <div class="shape">
                            <?php tp_render_icon($item, 'tp_features_icon', 'tp_features_selected_icon'); ?>
                        </div>
                        <?php endif; ?>
                        <?php elseif( $item['tp_features_icon_type'] == 'image' ) : ?>
                        <?php if (!empty($item['tp_features_image']['url'])): ?>
                        <div class="shape">
                            <img src="<?php echo $item['tp_features_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        </div>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['tp_features_icon_svg'])): ?>
                        <div class="shape">
                            <?php echo $item['tp_features_icon_svg']; ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                     </div>
                     <div class="tp-feature-content">
                        <?php if (!empty($item['tp_features_title' ])): ?>
                            <h4 class="tp-feature-content-title">
                                <?php if (!empty($link)) : ?>
                                <a href="<?php echo esc_url($link); ?>"><?php echo tp_kses($item['tp_features_title' ]); ?></a>
                                <?php else : ?>
                                <?php echo tp_kses($item['tp_features_title' ]); ?>
                                <?php endif; ?>
                            </h4>
                        <?php endif; ?>
                        <?php if (!empty($item['tp_features_description' ])): ?>
                            <p><?php echo tp_kses($item['tp_features_description']); ?></p>
                        <?php endif; ?>
                     </div>
                     <div class="tp-feature-shape-two">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/feature/one/feature-shape-1.png" alt="">
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
         <div class="tp-feature-shape">
            <div class="tp-feature-shape-one w-img">
               <img src="<?php echo get_template_directory_uri(); ?>/assets/img/feature/one/features-bg.png" alt="">
            </div>
         </div>
      </section>
      <!-- feature-area-end -->

<?php endif;
	}
}

$widgets_manager->register( new TP_Features() );