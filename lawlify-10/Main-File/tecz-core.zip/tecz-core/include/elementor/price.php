<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Price extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-price';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Price', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    }


    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'header_title',
            [
                'label' => esc_html__( 'Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Starter Protection Plan' , 'tpcore' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'header_sub_title',
            [
                'label' => esc_html__( 'Sub Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'We are a team of the dedicated patent professionals acros.' , 'tpcore' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'header_price',
            [
                'label' => esc_html__( 'Price', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '30' , 'tpcore' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'header_duration',
            [
                'label' => esc_html__( 'Duration', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Month' , 'tpcore' ),
                'label_block' => true,
            ]
        );

         $this->add_control(
            'footer_btn_txt',
            [
                'label' => esc_html__( 'Button Text', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Get this Plan Now', 'tpcore' ),
                'placeholder' => esc_html__( 'Type your title here', 'tpcore' ),
            ]
        );

       $this->add_control(
            'footer_btn_link',
            [
                'label' => esc_html__( 'Link', 'tpcore' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_feature_title',
            [
                'label' => esc_html__( 'List Text', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

         $repeater->add_control(
            'list_feature_icon',
            [
                'label' => esc_html__( 'Icon', 'tpcore' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-circle',
                    'library' => 'fa-solid',
                ],
                'recommended' => [
                    'fa-solid' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                    'fa-regular' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                ],
            ]
        );

      

      


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_feature_title' => esc_html__( 'Patent Search', 'tpcore' ),
                        
                    ],
                    [
                        'list_feature_title' => esc_html__( 'Patent Filing', 'tpcore' ),
                    ], 
                    [
                        'list_feature_title' => esc_html__( 'Trademark Search', 'tpcore' ),
                    ],
                    [
                        'list_feature_title' => esc_html__( 'Trademark Filing', 'tpcore' ),
                    ], 
                    [
                        'list_feature_title' => esc_html__( 'Copyright Registration', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_feature_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'price_block_title',
            [
                'label' => esc_html__( 'Header Title Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-block_one-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .price-block_one-title',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Header SubTitle Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-block_one-text' => 'color: {{VALUE}}',
                ],
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .price-block_one-text',
            ]
        );


        $this->end_controls_section();


        

    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
     ?>

	<section class="price-one">
        <div class="auto-container">
            <div class="row clearfix">
                <!-- Price Block One -->
                <div class="price-block_one col-lg-12">
                    <div class="price-block_one-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="price-block_one-title"><?php echo esc_html($settings['header_title']); ?></div>
                        <div class="price-block_one-price"><sup>$</sup><?php echo esc_html($settings['header_price']); ?><sub>/ <?php echo esc_html($settings['header_duration']); ?></sub></div>
                        <div class="price-block_one-text"><?php echo esc_html($settings['header_sub_title']); ?></div>
                        <div class="price-block_one-content">
                            <ul class="price-block_one-list">
                                <?php foreach (  $settings['list'] as $key => $item ) : ?>
                                <li><i class="<?php echo esc_attr ( $item['list_feature_icon']['value'] ); ?>"></i><?php echo esc_html($item['list_feature_title']); ?></li>
                                <?php endforeach ; ?>
                            </ul>
                        </div>
                        <div class="price-block_one-button-box">
                            <a class="price-block_one-button" href="<?php echo $settings['footer_btn_link']['url']; ?>"><?php echo esc_html($settings['footer_btn_txt']); ?> <i class="fa-solid fa-angle-right fa-fw"></i></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    
     <?php
    }
}

$widgets_manager->register( new TP_Price() );



