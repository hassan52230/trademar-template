<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Hero_One extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-hero-one';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero One', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore'];
    }


    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'list_img_pattern1',
            [
                'label' => esc_html__( 'Image Shape 1', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        ); 

        $this->add_control(
            'list_img_pattern2',
            [
                'label' => esc_html__( 'Image Shape 2', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        ); 

        $this->add_control(
            'list_img_pattern3',
            [
                'label' => esc_html__( 'Scroll Down', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        ); 
       
        $repeater = new Repeater();

        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__( 'Title', 'tpcore' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'List Title' , 'tpcore' ),
                'label_block' => true,
            ]
        );

         $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__( 'Content', 'tpcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna' , 'tpcore' ),
                'show_label' => false,
            ]
        );

         $repeater->add_control(
            'list_img_user',
            [
                'label' => esc_html__( 'User Image', 'tpcore' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

       $repeater->add_control(
			'list_btn_txt',
			[
				'label' => esc_html__( 'Button Text', 'tpcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Find Out More', 'tpcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'tpcore' ),
			]
		);

       $repeater->add_control(
			'list_btn_link',
			[
				'label' => esc_html__( 'Link', 'tpcore' ),
				'type' => Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'label_block' => true,
			]
		);

       $repeater->add_control(
            'list_yt_link',
            [
                'label' => esc_html__( 'YT Link', 'tpcore' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

  


        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Repeater List', 'tpcore' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_content' => esc_html__( 'Content #1.', 'tpcore' ),
                        
                    ],
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_content' => esc_html__( 'Content #1.', 'tpcore' ),
                    ], 
                    [
                        'list_title' => esc_html__( 'Title #1', 'textdomain' ),
                        'list_content' => esc_html__( 'Content #1.', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );
  
        $this->end_controls_section();



        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Style', 'tpcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-one_heading' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .slider-one_heading',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-one_text p' => 'color: {{VALUE}}',
                ],
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .slider-one_text p',
            ]
        );

        $this->end_controls_section();

    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $list_img_pattern1 = $settings['list_img_pattern1']['url'];
        $list_img_pattern2 = $settings['list_img_pattern2']['url'];
        $list_img_pattern3 = $settings['list_img_pattern3']['url'];

     ?>

     <section class="slider-one">
        <div class="slider-one_pattern" style="background-image:url(<?php echo esc_url($list_img_pattern1); ?>)"></div>
        <div class="slider-one_pattern-two" style="background-image:url(<?php echo esc_url($list_img_pattern2); ?>)"></div>
        <div class="main-slider swiper-container">
            <div class="swiper-wrapper">
                 <?php foreach (  $settings['list'] as $key => $item ) : ?>
                <!-- Slide -->
                <div class="swiper-slide">
                    <div class="auto-container">
                        <div class="row clearfix">

                            <!-- Content Column -->
                            <div class="slider-one_content col-lg-6 col-md-12 col-sm-12">
                                <div class="slider-one_content-inner">
                                    <h1 class="slider-one_heading"><?php echo esc_html($item['list_title']); ?></h1>
                                    <div class="slider-one_text"><?php echo $item['list_content']; ?></div>
                                    <div class="slider-one_button">
                                        <a href="<?php echo esc_url($item['list_btn_link']['url']); ?>" class="theme-btn btn-style-one">
                                            <span class="btn-wrap">
                                                <span class="text-one"><?php echo esc_html($item['list_btn_txt']); ?> <i class="fa-solid fa-angle-right fa-fw"></i></span>
                                                <span class="text-two"><?php echo esc_html($item['list_btn_txt']); ?> <i class="fa-solid fa-angle-right fa-fw"></i></span>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Image Column -->
                            <div class="slider-one_image-column col-lg-6 col-md-12 col-sm-12">
                                <a href="<?php echo esc_url($item['list_yt_link']['url']); ?>" class="lightbox-video slider-one_play"><span class="fa fa-play"><i class="ripple"></i></span></a>
                                <div class="slider-one_image-inner">
                                    <div class="slider-one_image">
                                        <img src="<?php echo esc_url($item['list_img_user']['url']); ?>" alt="" />
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php endforeach ; ?>
            </div>
            <!-- Slider One Arrows -->
            <div class="slider-one-arrow">
                <!-- If we need navigation buttons -->
                <div class="main-slider-prev fas fa-arrow-left fa-fw"></div>
                <div class="main-slider-next fas fa-arrow-right fa-fw"></div>
            </div>

            <!-- Scroll Down -->
            <div class="slider-one_scroll-down scroll-to-target" data-target="#about">
                <img src="<?php echo esc_url($list_img_pattern3); ?>" alt="" />
            </div>
        </div>
    </section>



     <?php
    }
}

$widgets_manager->register( new TP_Hero_One() );



