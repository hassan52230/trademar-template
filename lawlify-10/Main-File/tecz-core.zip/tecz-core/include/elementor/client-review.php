<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Client_Review extends Widget_Base {

	use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
    	return 'tp-client-review';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
    	return __( 'Client Review', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
    	return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
    	return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
    	return [ 'tpcore'];
    }


    protected function register_controls(){
    	$this->register_controls_section();
    	$this->style_tab_content();
    } 

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls_section() {

    	$this->start_controls_section(
    		'content_section',
    		[
    			'label' => esc_html__( 'Content', 'tpcore' ),
    			'tab' => Controls_Manager::TAB_CONTENT,
    		]
    	);


    	$repeater = new Repeater();

    	$repeater->add_control(
    		'list_image',
    		[
    			'label' => esc_html__( 'Choose Image', 'tpcore' ),
    			'type' => Controls_Manager::MEDIA,
    			'default' => [
    				'url' => Utils::get_placeholder_image_src(),
    			],
    		]
    	);

    	$repeater->add_control(
    		'list_name',
    		[
    			'label' => esc_html__( 'Name', 'tpcore' ),
    			'type' => Controls_Manager::TEXT,
    			'default' => esc_html__( 'Peter Anderson ' , 'tpcore' ),
    			'label_block' => true,
    		]
    	);
    	$repeater->add_control(
    		'list_designation',
    		[
    			'label' => esc_html__( 'Designation', 'tpcore' ),
    			'type' => Controls_Manager::TEXT,
    			'default' => esc_html__( 'Lead Generation' , 'tpcore' ),
    			'label_block' => true,
    		]
    	);

    	$repeater->add_control(
    		'list_content',
    		[
    			'label' => esc_html__( 'Content', 'tpcore' ),
    			'type' => Controls_Manager::WYSIWYG,
    			'default' => esc_html__( 'List Content' , 'tpcore' ),
    			'show_label' => false,
    		]
    	);



    	$this->add_control(
    		'list',
    		[
    			'label' => esc_html__( 'Repeater List', 'tpcore' ),
    			'type' => Controls_Manager::REPEATER,
    			'fields' => $repeater->get_controls(),
    			'default' => [
    				[
    					'list_name' => esc_html__( 'Peter Anderson', 'tpcore' ),
    					'list_designation' => esc_html__( 'Lead Generation', 'tpcore' ),

    				],
    				[
    					'list_name' => esc_html__( 'Peter Anderson', 'tpcore' ),
    					'list_designation' => esc_html__( 'Lead Generation', 'tpcore' ),
    				], 
    				[
    					'list_name' => esc_html__( 'Peter Anderson', 'tpcore' ),
    					'list_designation' => esc_html__( 'Lead Generation', 'tpcore' ),
    				],
    			],
    			'title_field' => '{{{ list_name }}}',
    		]
    	);

    	$this->end_controls_section();



    	$this->start_controls_section(
    		'style_section',
    		[
    			'label' => esc_html__( 'Style', 'tpcore' ),
    			'tab' => Controls_Manager::TAB_STYLE,
    		]
    	);

    	$this->add_control(
    		'name_color',
    		[
    			'label' => esc_html__( 'Name Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .testimonial-block_one-author' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'name_typography',
    			'selector' => '{{WRAPPER}} .testimonial-block_one-author',
    		]
    	);

    	$this->add_control(
    		'designation_color',
    		[
    			'label' => esc_html__( 'Designation Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .testimonial-block_one-author span' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'designation_typography',
    			'selector' => '{{WRAPPER}} .testimonial-block_one-author span',
    		]
    	);

    	

    	$this->add_control(
    		'content_color',
    		[
    			'label' => esc_html__( 'Content Color', 'tpcore' ),
    			'type' => Controls_Manager::COLOR,
    			'selectors' => [
    				'{{WRAPPER}} .testimonial-block_one-text p' => 'color: {{VALUE}}',
    			],
    		]
    	);

    	$this->add_group_control(
    		Group_Control_Typography::get_type(),
    		[
    			'name' => 'content_typography',
    			'selector' => '{{WRAPPER}} .testimonial-block_one-text p',
    		]
    	);


    	$this->end_controls_section();




    }

     protected function style_tab_content(){
        $this->tp_basic_style_controls('footer_title', 'Title Style', '.tp-el-title');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
    	$settings = $this->get_settings_for_display();
    	?>

    	<section class="testimonial-one">
    		<div class="auto-container">
    			<div class="testimonial-one_carousel swiper-container">
    				<div class="swiper-wrapper">
    					<?php foreach (  $settings['list'] as $item ) : ?>
    						<div class="swiper-slide">
    							<div class="testimonial-block_one">
    								<div class="testimonial-block_one-inner">
    									<div class="row clearfix">
    										<div class="testimonial-block_one-image-column col-lg-4 col-md-4 col-sm-12">
    											<div class="testimonial-block_one-image-outer">
    												<div class="testimonial-block_one-image">
    													<div class="testimonial-block_one-quote fa-solid fa-quote-left fa-fw"></div>
    													<img src="<?php echo esc_url ( $item['list_image']['url'] ); ?>" alt="" />
    												</div>
    											</div>
    										</div>
    										<div class="testimonial-block_one-content-column col-lg-8 col-md-8 col-sm-12">
    											<div class="testimonial-block_one-content-outer">
    												<div class="testimonial-block_one-rating">
    													<span class="fa fa-star"></span>
    													<span class="fa fa-star"></span>
    													<span class="fa fa-star"></span>
    													<span class="fa fa-star"></span>
    													<span class="fa fa-star"></span>
    												</div>
    												<div class="testimonial-block_one-text"><?php echo $item['list_content']; ?></div>
    												<div class="testimonial-block_one-author">
    													<?php echo $item['list_name'] ; ?> <span><?php echo $item['list_designation']; ?></span>
    												</div>
    											</div>
    										</div>
    									</div>
    								</div>
    							</div>
    						</div>
    				<?php endforeach ; ?>
    				</div>
    				<div class="testimonial-one-arrow">
    					<div class="testimonial-one_carousel-pagination"></div>
    					<div class="testimonial-one_carousel-prev fa-solid fa-angle-left fa-fw"></div>
    					<div class="testimonial-one_carousel-next fa-solid fa-angle-right fa-fw"></div>
    				</div>

    			</div>
    		</div>
    	</section>

    	<?php
    }
}

$widgets_manager->register( new TP_Client_Review() );



