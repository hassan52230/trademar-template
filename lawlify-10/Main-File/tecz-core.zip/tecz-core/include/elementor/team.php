<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Team extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-team';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Team', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }
    protected function register_controls_section() {
        

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                    'layout-4' => esc_html__('Layout 4', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


        // tp_section_title
        $this->tp_section_title_render_controls('team', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1','layout-2','layout-3', 'layout-4']);

        

        // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'tp-core'),
                'condition' => [
                    'tp_design_style' => ['layout-4']
                ]
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'tp-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tp-core'),
                'title' => esc_html__('Enter button text', 'tp-core'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'tp-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tp-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'tp-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();

        // member list
        $this->start_controls_section(
            '_section_teams',
            [
                'label' => __( 'Members', 'tpcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                    'style_3' => __( 'Style 3', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->start_controls_tabs(
            '_tab_style_member_box_itemr'
        );

        $repeater->start_controls_tab(
            '_tab_member_info',
            [
                'label' => __( 'Information', 'tpcore' ),
            ]
        );

        $repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'tpcore' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                      

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Title', 'tpcore' ),
                'default' => __( 'TP Member Title', 'tpcore' ),
                'placeholder' => __( 'Type title here', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'designation',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Job Title', 'tpcore' ),
                'default' => __( 'TP Officer', 'tpcore' ),
                'placeholder' => __( 'Type designation here', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );   
        $repeater->add_control(
            'item_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => false,
                'placeholder' => __( 'Type link here', 'tpcore' ),
                'default' => __( '#', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        
        // creative animation
        $repeater->add_control(
			'tp_creative_anima_switcher',
			[
				'label' => esc_html__( 'Active Animation', 'tpcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'your-plugin' ),
				'label_off' => esc_html__( 'No', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => '0',
                'separator' => 'before',
                'condition' => [
                    'repeater_condition' => 'style_10'
                ]
			]
		);

        $repeater->add_control(
            'tp_anima_type',
            [
                'label' => __( 'Animation Type', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'fadeInUp' => __( 'fadeInUp', 'tpcore' ),
                    'fadeInDown' => __( 'fadeInDown', 'tpcore' ),
                    'fadeInLeft' => __( 'fadeInLeft', 'tpcore' ),
                    'fadeInRight' => __( 'fadeInRight', 'tpcore' ),
                ],
                'default' => 'fadeInUp',
                'frontend_available' => true,
                'style_transfer' => true,
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => 'style_10'
                ],
            ]
        );
        
        $repeater->add_control(
            'tp_anima_dura', [
                'label' => esc_html__('Animation Duration', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.3s', 'tpcore'),
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => 'style_10'
                ],
            ]
        );
        
        $repeater->add_control(
            'tp_anima_delay', [
                'label' => esc_html__('Animation Delay', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.6s', 'tpcore'),
                'condition' => [
                    'tp_creative_anima_switcher' => 'yes',
                    'repeater_condition' => 'style_10'
                ],
            ]
        );

        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            '_tab_member_links',
            [
                'label' => __( 'Links', 'tpcore' ),
            ]
        );

        $repeater->add_control(
            'show_social',
            [
                'label' => __( 'Show Options?', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'tpcore' ),
                'label_off' => __( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'web_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Website Address', 'tpcore' ),
                'placeholder' => __( 'Add your profile link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'email_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Email', 'tpcore' ),
                'placeholder' => __( 'Add your email link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );           

        $repeater->add_control(
            'phone_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Phone', 'tpcore' ),
                'placeholder' => __( 'Add your phone link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'facebook_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Facebook', 'tpcore' ),
                'default' => __( '#', 'tpcore' ),
                'placeholder' => __( 'Add your facebook link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                

        $repeater->add_control(
            'twitter_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Twitter', 'tpcore' ),
                'default' => __( '#', 'tpcore' ),
                'placeholder' => __( 'Add your twitter link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'instagram_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Instagram', 'tpcore' ),
                'default' => __( '#', 'tpcore' ),
                'placeholder' => __( 'Add your instagram link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );       

        $repeater->add_control(
            'linkedin_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'LinkedIn', 'tpcore' ),
                'placeholder' => __( 'Add your linkedin link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'youtube_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Youtube', 'tpcore' ),
                'placeholder' => __( 'Add your youtube link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'googleplus_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Google Plus', 'tpcore' ),
                'placeholder' => __( 'Add your Google Plus link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'flickr_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Flickr', 'tpcore' ),
                'placeholder' => __( 'Add your flickr link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'vimeo_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Vimeo', 'tpcore' ),
                'placeholder' => __( 'Add your vimeo link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'behance_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Behance', 'tpcore' ),
                'placeholder' => __( 'Add your hehance link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'dribble_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Dribbble', 'tpcore' ),
                'placeholder' => __( 'Add your dribbble link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'pinterest_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Pinterest', 'tpcore' ),
                'placeholder' => __( 'Add your pinterest link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'gitub_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Github', 'tpcore' ),
                'placeholder' => __( 'Add your github link', 'tpcore' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        ); 

        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();

        // REPEATER
        $this->add_control(
            'teams',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ]
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => __( 'Title HTML Tag', 'tpcore' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1'  => [
                        'title' => __( 'H1', 'tpcore' ),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2'  => [
                        'title' => __( 'H2', 'tpcore' ),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3'  => [
                        'title' => __( 'H3', 'tpcore' ),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4'  => [
                        'title' => __( 'H4', 'tpcore' ),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5'  => [
                        'title' => __( 'H5', 'tpcore' ),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6'  => [
                        'title' => __( 'H6', 'tpcore' ),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h3',
                'toggle' => false,
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => __( 'Alignment', 'tpcore' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'tpcore' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'tpcore' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'tpcore' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .single-carousel-item' => 'text-align: {{VALUE}};'
                ]
            ]
        );

        
        $this->add_control(
            'tp_shape_show',
            [
                'label' => esc_html__( 'Show Shape', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'tp_design_style' => 'layout-3'
                ]
            ]
        );

        $this->end_controls_section();

        
        // _tp_image
		$this->start_controls_section(
            '_tp_image',
            [
                'label' => esc_html__('Thumbnail', 'tp-core'),
                'condition' => [
                    'tp_design_style' => 'layout-10'
                ]
            ]
        );

        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'tp_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();

        // colum controls
        $this->tp_columns('col');
    }

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('team_section', 'Section - Style', '.tp-el-section');
        $this->tp_basic_style_controls('team_subtitle', 'Section - Subtitle', '.tp-el-subtitle');
        $this->tp_basic_style_controls('team_title', 'Section - Title', '.tp-el-title');
        $this->tp_basic_style_controls('team_description', 'Section - Description', '.tp-el-content');
        $this->tp_link_controls_style('team_btn', 'Team - Button', '.tp-el-btn');

        $this->tp_basic_style_controls('team_box_title', 'Team - Box - Title', '.tp-el-box-title');
        $this->tp_basic_style_controls('team_box_desi', 'Team - Box -  Designation', '.tp-el-box-desi');
        $this->tp_link_controls_style('team_box_link_btn', 'Team - Box - Social', '.tp-el-box-social');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

<!-- style 2 -->
<?php if ( $settings['tp_design_style'] === 'layout-2' ): 
    $this->add_render_attribute( 'title_args', 'class', 'tp-section-title tp-el-title' );
    $this->add_render_attribute( 'title_team', 'class', 'tp-team-3-title tp-el-box-title' );

    // Link
    if ('2' == $settings['tp_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
        }
    }
?>
<!-- team-area-start -->
<section class="team-area tp-team-3-border fix pt-115 pb-60 mb-115 tp-el-section">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="tp-team-3-wrapper">
            <div class="tp-section tp-section-3 mb-50 wow fadeInUp " data-wow-duration="1s" data-wow-delay=".4s">
                <?php if ( !empty($settings['tp_team_sub_title']) ) : ?>
                    <span class="tp-section-sub-title tp-el-subtitle"><?php echo tp_kses( $settings['tp_team_sub_title'] ); ?></span>
                <?php endif; ?>
                <?php
                    if ( !empty($settings['tp_team_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_team_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_team_title' ] )
                        );
                    endif;
                ?>
            </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="tp-team-3-wrap">
            <div class="swiper-container tp-team-3-active">
                <div class="swiper-wrapper">
                <?php foreach ( $settings['teams'] as $item ) :
                    $title = tp_kses( $item['title' ] );
                    $item_url = esc_url($item['item_url']);

                    if ( !empty($item['image']['url']) ) {
                        $tp_team_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size']) : $item['image']['url'];
                        $tp_team_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
                    }            
                ?>
                    <div class="swiper-slide">
                        <div class="tp-team-3-item mb-40">
                        <div class="tp-team-3-thumb">
                            <div class="tp-team-3-thumb-wrap tp-thumb-common fix">
                                <div class="tp-thumb-common-overlay wow"></div>
                                <?php if( !empty($tp_team_image_url) ) : ?>
                                    <img src="<?php echo esc_url($tp_team_image_url); ?>" alt="<?php echo esc_attr($tp_team_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="tp-team-3-thumb-social">
                            <?php if( !empty($item['web_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['web_title'] ); ?>"><span><i class="fa-regular fa-globe"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['phone_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="tel:<?php echo esc_url( $item['phone_title'] ); ?>"><span><i class="fa-regular fa-phone"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['facebook_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['facebook_title'] ); ?>"><span><i class="fa-brands fa-facebook-f"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['twitter_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['twitter_title'] ); ?>"><span><i class="fa-brands fa-twitter"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['instagram_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['instagram_title'] ); ?>"><span><i class="fa-brands fa-instagram"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['linkedin_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['linkedin_title'] ); ?>"><span><i class="fa-brands fa-linkedin-in"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['youtube_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['youtube_title'] ); ?>"><span><i class="fa-brands fa-youtube"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['googleplus_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['googleplus_title'] ); ?>"><span><i class="fa-brands fa-google-plus-g"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['flickr_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['flickr_title'] ); ?>"><span><i class="fa-brands fa-flickr"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['vimeo_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['vimeo_title'] ); ?>"><span><i class="fa-brands fa-vimeo-v"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['behance_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['behance_title'] ); ?>"><span><i class="fa-brands fa-behance"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['dribble_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['dribble_title'] ); ?>"><span><i class="fa-brands fa-dribbble"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['pinterest_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['pinterest_title'] ); ?>"><span><i class="fa-brands fa-pinterest-p"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['gitub_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['gitub_title'] ); ?>"><span><i class="fa-brands fa-github"></i></span></a>
                            <?php endif; ?>
                            </div>
                        </div>
                        <div class="tp-team-3-content">
                            <?php printf( '<%1$s %2$s><a href="%4$s">%3$s</a></%1$s>',
                                tag_escape( $settings['title_tag'] ),
                                $this->get_render_attribute_string( 'title_team' ),
                                $title,
                                $item_url
                            ); ?>
                        <?php if( !empty($item['designation']) ) : ?>
                            <span><?php echo tp_kses( $item['designation'] ); ?></span>
                        <?php endif; ?>
                        </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- team-area-end -->


<!-- style 3 -->
<?php elseif ( $settings['tp_design_style'] === 'layout-3' ): 
    $this->add_render_attribute( 'title_args', 'class', 'tp-section-title tp-el-title' );
    $this->add_render_attribute( 'title_team', 'class', 'tp-team-4-title tp-el-box-title ' );

    // Link
    if ('2' == $settings['tp_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
        }
    }

?>
     <!-- team-area-start -->
     <section class="team-area tp-team-4-bg pt-115 pb-55 tp-el-section">
         <div class="container tp-team-4-width">
            <div class="row">
               <div class="col-lg-12">
                  <div class="tp-section tp-section-red text-center mb-50">
                  <?php if ( !empty($settings['tp_team_sub_title']) ) : ?>
                        <span class="tp-section-sub-title tp-el-subtitle"><?php echo tp_kses( $settings['tp_team_sub_title'] ); ?></span>
                    <?php endif; ?>
                     <?php
                        if ( !empty($settings['tp_team_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_team_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_team_title' ] )
                            );
                        endif;
                    ?>
                  </div>
               </div>
            </div>
            <div class="row">
            <?php foreach ( $settings['teams'] as $item ) :
                    $title = tp_kses( $item['title' ] );
                    $item_url = esc_url($item['item_url']);

                    if ( !empty($item['image']['url']) ) {
                        $tp_team_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size']) : $item['image']['url'];
                        $tp_team_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
                    }            
                ?>
               <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                  <div class="tp-team-4-item mb-40">
                     <div class="tp-team-4-thumb tp-thumb-common">
                        <div class="tp-thumb-common-overlay-red wow"></div>
                       <img src="<?php echo esc_url($tp_team_image_url); ?>" alt="<?php echo esc_attr($tp_team_image_alt); ?>">
                        <div class="tp-team-4-social">
                        <?php if( !empty($item['web_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['web_title'] ); ?>"><span><i class="fa-regular fa-globe"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['phone_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="tel:<?php echo esc_url( $item['phone_title'] ); ?>"><span><i class="fa-regular fa-phone"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['facebook_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['facebook_title'] ); ?>"><span><i class="fa-brands fa-facebook-f"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['twitter_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['twitter_title'] ); ?>"><span><i class="fa-brands fa-twitter"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['instagram_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['instagram_title'] ); ?>"><span><i class="fa-brands fa-instagram"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['linkedin_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['linkedin_title'] ); ?>"><span><i class="fa-brands fa-linkedin-in"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['youtube_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['youtube_title'] ); ?>"><span><i class="fa-brands fa-youtube"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['googleplus_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['googleplus_title'] ); ?>"><span><i class="fa-brands fa-google-plus-g"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['flickr_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['flickr_title'] ); ?>"><span><i class="fa-brands fa-flickr"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['vimeo_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['vimeo_title'] ); ?>"><span><i class="fa-brands fa-vimeo-v"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['behance_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['behance_title'] ); ?>"><span><i class="fa-brands fa-behance"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['dribble_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['dribble_title'] ); ?>"><span><i class="fa-brands fa-dribbble"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['pinterest_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['pinterest_title'] ); ?>"><span><i class="fa-brands fa-pinterest-p"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['gitub_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['gitub_title'] ); ?>"><span><i class="fa-brands fa-github"></i></span></a>
                            <?php endif; ?>
                        </div>
                     </div>
                     <div class="tp-team-4-content d-flex align-items-center">
                        <div class="tp-team-4-icon-main">
                           <i class="flaticon-share"></i>
                        </div>
                        <div class="tp-team-4-content-text">
                           <?php printf( '<%1$s %2$s><a href="%4$s">%3$s</a></%1$s>',
                            tag_escape( $settings['title_tag'] ),
                            $this->get_render_attribute_string( 'title_team' ),
                            $title,
                            $item_url
                        ); ?>
                        <?php if( !empty($item['designation']) ) : ?>
                            <span><?php echo tp_kses( $item['designation'] ); ?></span>
                        <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </section>
      <!-- team-area-end -->
      
<!-- style 2 -->
<?php elseif ( $settings['tp_design_style'] === 'layout-4' ): 
    $this->add_render_attribute( 'title_args', 'class', 'tp-section-title tp-el-title' );
    $this->add_render_attribute( 'title_team', 'class', 'tp-team-3-title tp-el-box-title' );

    // Link
    if ('2' == $settings['tp_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
        }
    }
?>
     <!-- team-area-start -->
<section class="team-area fix pb-60">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="tp-team-3-wrapper text-center">
            <div class="tp-section tp-section-3 mb-50 wow fadeInUp " data-wow-duration="1s" data-wow-delay=".4s">
            <?php if ( !empty($settings['tp_team_sub_title']) ) : ?>
                <span class="tp-section-sub-title tp-el-subtitle"><?php echo tp_kses( $settings['tp_team_sub_title'] ); ?></span>
            <?php endif; ?>
            <?php
                if ( !empty($settings['tp_team_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $settings['tp_team_title_tag'] ),
                    $this->get_render_attribute_string( 'title_args' ),
                    tp_kses( $settings['tp_team_title' ] )
                    );
                endif;
            ?>
        </div>
            </div>
        </div>
    </div>
    <div class="row">
    <?php foreach ( $settings['teams'] as $item ) :
        $title = tp_kses( $item['title' ] );
        $item_url = esc_url($item['item_url']);

        if ( !empty($item['image']['url']) ) {
            $tp_team_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size']) : $item['image']['url'];
            $tp_team_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
        }            
    ?>
        <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="tp-team-3-item mb-15">
            <div class="tp-team-3-thumb">
            <?php if( !empty($tp_team_image_url) ) : ?>
                <div class="tp-team-3-thumb-wrap tp-thumb-common fix">
                    <div class="tp-thumb-common-overlay wow"></div>
                    <img src="<?php echo esc_url($tp_team_image_url); ?>" alt="<?php echo esc_attr($tp_team_image_alt); ?>">
                </div>
                <?php endif; ?>
                        
                    
                <div class="tp-team-3-thumb-social">
                <?php if( !empty($item['web_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['web_title'] ); ?>"><span><i class="fa-regular fa-globe"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['phone_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="tel:<?php echo esc_url( $item['phone_title'] ); ?>"><span><i class="fa-regular fa-phone"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['facebook_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['facebook_title'] ); ?>"><span><i class="fa-brands fa-facebook-f"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['twitter_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['twitter_title'] ); ?>"><span><i class="fa-brands fa-twitter"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['instagram_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['instagram_title'] ); ?>"><span><i class="fa-brands fa-instagram"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['linkedin_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['linkedin_title'] ); ?>"><span><i class="fa-brands fa-linkedin-in"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['youtube_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['youtube_title'] ); ?>"><span><i class="fa-brands fa-youtube"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['googleplus_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['googleplus_title'] ); ?>"><span><i class="fa-brands fa-google-plus-g"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['flickr_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['flickr_title'] ); ?>"><span><i class="fa-brands fa-flickr"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['vimeo_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['vimeo_title'] ); ?>"><span><i class="fa-brands fa-vimeo-v"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['behance_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['behance_title'] ); ?>"><span><i class="fa-brands fa-behance"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['dribble_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['dribble_title'] ); ?>"><span><i class="fa-brands fa-dribbble"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['pinterest_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['pinterest_title'] ); ?>"><span><i class="fa-brands fa-pinterest-p"></i></span></a>
                <?php endif; ?>

                <?php if( !empty($item['gitub_title'] ) ) : ?>
                <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['gitub_title'] ); ?>"><span><i class="fa-brands fa-github"></i></span></a>
                <?php endif; ?>
                </div>
            </div>
            <div class="tp-team-3-content">
            <?php printf( '<%1$s %2$s><a href="%4$s">%3$s</a></%1$s>',
                    tag_escape( $settings['title_tag'] ),
                    $this->get_render_attribute_string( 'title_team' ),
                    $title,
                    $item_url
                ); ?>
            <?php if( !empty($item['designation']) ) : ?>
                <span><?php echo tp_kses( $item['designation'] ); ?></span>
            <?php endif; ?>
            </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</section>
<!-- team-area-end -->



<!-- style default -->
<?php else : 
    $this->add_render_attribute('title_args', 'class', 'tp-section-title tp-el-title');
    $this->add_render_attribute( 'title_team', 'class', 'tp-team-two-title tp-el-box-title' );

    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
   <!-- team-area-star -->
   <section class="team-area tp-team-two-wrap pb-80 tp-el-section">
         <div class="container tp-team-two-width">
            <div class="row">
               <div class="col-lg-12">
                  <div class="tp-section tp-section-two text-center mb-55">
                    <?php if ( !empty($settings['tp_team_sub_title']) ) : ?>
                        <span class="tp-section-sub-title tp-el-subtitle"><?php echo tp_kses( $settings['tp_team_sub_title'] ); ?></span>
                    <?php endif; ?>
                     <?php
                        if ( !empty($settings['tp_team_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_team_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_team_title' ] )
                            );
                        endif;
                    ?>
                  </div>
               </div>
            </div>
            <div class="row">
                <?php foreach ( $settings['teams'] as $item ) :
                    $title = tp_kses( $item['title' ] );
                    $item_url = esc_url($item['item_url']);

                    if ( !empty($item['image']['url']) ) {
                        $tp_team_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size']) : $item['image']['url'];
                        $tp_team_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
                    }            
                ?>
               <div class="col-lg-3 col-md-6">
                  <div class="tp-team-two-item mb-40 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".6s">
                  <?php if( !empty($tp_team_image_url) ) : ?>
                     <div class="tp-team-two-thumb tp-thumb-common fix">
                        <div class="tp-thumb-common-overlay wow"></div>
                        <img src="<?php echo esc_url($tp_team_image_url); ?>" alt="<?php echo esc_attr($tp_team_image_alt); ?>">
                     </div>
                     <?php endif; ?>
                     <div class="tp-team-two-content">
                        <?php printf( '<%1$s %2$s><a href="%4$s">%3$s</a></%1$s>',
                            tag_escape( $settings['title_tag'] ),
                            $this->get_render_attribute_string( 'title_team' ),
                            $title,
                            $item_url
                        ); ?>
                        <?php if( !empty($item['designation']) ) : ?>
                            <span><?php echo tp_kses( $item['designation'] ); ?></span>
                        <?php endif; ?>
                        <div class="tp-team-two-social">
                           <?php if( !empty($item['web_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['web_title'] ); ?>"><span><i class="fa-regular fa-globe"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['phone_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="tel:<?php echo esc_url( $item['phone_title'] ); ?>"><span><i class="fa-regular fa-phone"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['facebook_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['facebook_title'] ); ?>"><span><i class="fa-brands fa-facebook-f"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['twitter_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['twitter_title'] ); ?>"><span><i class="fa-brands fa-twitter"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['instagram_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['instagram_title'] ); ?>"><span><i class="fa-brands fa-instagram"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['linkedin_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['linkedin_title'] ); ?>"><span><i class="fa-brands fa-linkedin-in"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['youtube_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['youtube_title'] ); ?>"><span><i class="fa-brands fa-youtube"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['googleplus_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['googleplus_title'] ); ?>"><span><i class="fa-brands fa-google-plus-g"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['flickr_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['flickr_title'] ); ?>"><span><i class="fa-brands fa-flickr"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['vimeo_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['vimeo_title'] ); ?>"><span><i class="fa-brands fa-vimeo-v"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['behance_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['behance_title'] ); ?>"><span><i class="fa-brands fa-behance"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['dribble_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['dribble_title'] ); ?>"><span><i class="fa-brands fa-dribbble"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['pinterest_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['pinterest_title'] ); ?>"><span><i class="fa-brands fa-pinterest-p"></i></span></a>
                            <?php endif; ?>

                            <?php if( !empty($item['gitub_title'] ) ) : ?>
                            <a class="tp-e-networks-link tp-el-box-social" href="<?php echo esc_url( $item['gitub_title'] ); ?>"><span><i class="fa-brands fa-github"></i></span></a>
                            <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </section>
      <!-- team-area-end -->



<?php endif; 
    }
}

$widgets_manager->register( new TP_Team() );