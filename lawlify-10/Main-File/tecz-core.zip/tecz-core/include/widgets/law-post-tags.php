<?php
class Law_Post_Tags extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'law-post-tags-widget',  // Base ID
			'Law Post Tags'   // Name
		);
		add_action( 'widgets_init', function() {
			register_widget( 'Law_Post_Tags' );
		});
	}

	public $args = array(
		'before_title'  => '<h5 class="sidebar-widget_title">',
		'after_title'   => '</h5>',
		'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div></div>',
	);

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$title = apply_filters( 'widget_title', $instance['title'] );
		?>
		<div class="sidebar-widget popular-tags">
			<div class="widget-content">
				<h5 class="sidebar-widget_title"><?php echo esc_html($title); ?></h5>
					<?php 
							$tags = get_tags();

							foreach ((array)$tags as $key => $tag) {

							 ?>
								<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ) ?>"><?php echo esc_html($tag->name); ?></a>
							<?php }
							?>
						
				</div>
			</div>


			<?php echo $args['after_widget'];
		}

		public function form( $instance ) {
			$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'tpcore' );
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'tpcore' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
			</p>
			<?php
		}

		public function update( $new_instance, $old_instance ) {
			$instance          = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			return $instance;
		}
	}
	$Law_Post_Tags = new Law_Post_Tags();