<?php
class Law_Recent_Post_Thumb extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'law-recent-post-thumb-widget',  // Base ID
			'Law Recent Post Thumb'   // Name
		);
		add_action( 'widgets_init', function() {
			register_widget( 'Law_Recent_Post_Thumb' );
		});
	}

	public $args = array(
		'before_title'  => '<h5 class="sidebar-widget_title">',
		'after_title'   => '</h5>',
		'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div></div>',
	);

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$title = apply_filters( 'widget_title', $instance['title'] );
		$elem = array(
			'post_type' => 'post',
			'posts_per_page' => 3,
			'order' => 'DESC',
		);
		$query = new WP_Query( $elem );
		?>
		<div class="sidebar-widget post-widget">
			<div class="widget-content">
				<h5 class="sidebar-widget_title"><?php echo esc_html($title); ?></h5>
				<?php if( $query->have_posts() ):
					while( $query->have_posts() ): $query->the_post();
						$imgSrc = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
					 ?>
						<div class="post">
							<?php if ( has_post_thumbnail() ) : ?>
							<div class="thumb"><a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo esc_url($imgSrc); ?>" alt="image"></a></div>
							<?php endif; ?>
							<h6><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h6>
							<div class="post-date"><i class="fa-regular fa-calendar fa-fw"></i> <?php echo get_the_date('M j, Y'); ?></div>
						</div>
					<?php endwhile; endif; ?>
				</div>
			</div>


			<?php echo $args['after_widget'];
		}

		public function form( $instance ) {
			$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'tpcore' );
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'tpcore' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
			</p>
			<?php
		}

		public function update( $new_instance, $old_instance ) {
			$instance          = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			return $instance;
		}
	}
	$Law_Recent_Post_Thumb = new Law_Recent_Post_Thumb();