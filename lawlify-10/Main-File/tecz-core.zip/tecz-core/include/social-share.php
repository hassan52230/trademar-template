<?php


// product single social share
function tecz_product_social_share(){

    if(!empty($tecz_singleblog_social)) :
    
    $post_url = get_the_permalink();
    ?>    
    <div class="postbox-social text-lg-end mb-20">
        <span><?php echo esc_html__('Share:', 'tecz'); ?></span>
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
        <a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-pinterest-p"></i></a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://twitter.com/share?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-twitter"></i></a>
    </div>

    <?php
 endif ; 
} 




